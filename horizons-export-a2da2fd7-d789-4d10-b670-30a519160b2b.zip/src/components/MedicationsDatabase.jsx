
import React from 'react';
import { useToast } from '@/components/ui/use-toast';

const MedicationsDatabase = () => {
  const { toast } = useToast();

  React.useEffect(() => {
    toast({
      title: "🚧 Característica No Implementada",
      description: "Esta función no está implementada aún, pero ¡puedes solicitarla en tu próximo prompt! 🚀",
      variant: "destructive", // Using destructive to highlight it's a non-functional part
    });
  }, [toast]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] text-center text-slate-500 p-8 rounded-xl bg-white/60 backdrop-blur-xl shadow-lg border border-white/50">
      <h2 className="text-3xl font-bold mb-4 text-slate-700">Vademécum Deshabilitado</h2>
      <p className="text-lg mb-6">
        La sección de Vademécum ha sido eliminada según lo solicitado.
      </p>
      <p className="text-sm italic">
        Si deseas volver a tenerla o implementarla de otra forma, no dudes en solicitarlo.
      </p>
    </div>
  );
};

export default MedicationsDatabase;
