
import React, { useEffect, useState } from 'react';

const AnalogClock = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const seconds = time.getSeconds();
  const minutes = time.getMinutes();
  const hours = time.getHours();

  const secondDegrees = (seconds / 60) * 360;
  const minuteDegrees = ((minutes + seconds / 60) / 60) * 360;
  const hourDegrees = ((hours % 12 + minutes / 60) / 12) * 360;

  return (
    <div className="flex items-center justify-center w-full h-full min-h-[140px]">
      <div className="relative w-32 h-32 rounded-full border-[3px] border-slate-700/80 shadow-inner bg-white/40 backdrop-blur-sm">
        {/* Face Markers */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className={`absolute w-[2px] origin-bottom left-[61px] top-[4px] ${i % 3 === 0 ? 'h-3 bg-slate-800' : 'h-1.5 bg-slate-400'}`}
            style={{ 
              transform: `rotate(${i * 30}deg) translateY(0px)`,
            }}
          />
        ))}

        {/* Center */}
        <div className="absolute top-1/2 left-1/2 w-2 h-2 -mt-1 -ml-1 rounded-full bg-slate-800 z-50 shadow-sm" />

        {/* Hour Hand */}
        <div
          className="absolute top-1/2 left-1/2 w-1.5 h-8 -ml-[3px] -mt-8 rounded-full origin-bottom z-10 bg-slate-800 shadow-sm"
          style={{
            transform: `rotate(${hourDegrees}deg)`,
            transition: 'transform 0.5s cubic-bezier(0.4, 2.08, 0.55, 0.44)'
          }}
        />

        {/* Minute Hand */}
        <div
          className="absolute top-1/2 left-1/2 w-1 h-12 -ml-0.5 -mt-12 rounded-full origin-bottom z-20 bg-slate-600 shadow-sm"
          style={{
            transform: `rotate(${minuteDegrees}deg)`,
            transition: 'transform 0.5s cubic-bezier(0.4, 2.08, 0.55, 0.44)'
          }}
        />

        {/* Second Hand */}
        <div
          className="absolute top-1/2 left-1/2 w-0.5 h-12 -ml-[0.5px] -mt-12 rounded-full origin-bottom z-30 bg-red-500/90"
          style={{
            transform: `rotate(${secondDegrees}deg)`,
            transition: 'none'
          }}
        />
      </div>
    </div>
  );
};

export default AnalogClock;
