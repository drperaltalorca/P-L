
import React, { useRef, useState, useEffect } from 'react';
import { 
  Bold, Italic, Underline, List, ListOrdered, 
  AlignLeft, AlignCenter, AlignRight, Link as LinkIcon, 
  Image as ImageIcon, Youtube, Type, Heading1, Heading2, 
  Quote, Undo, Redo, Eraser, Upload, FileText, Download 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/customSupabaseClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from 'lucide-react';

const RichTextEditor = ({ initialContent, onChange }) => {
  const editorRef = useRef(null);
  const [activeFormats, setActiveFormats] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState(null); // 'image' | 'video' | 'link' | 'pdf'
  
  // Dialog States
  const [urlInput, setUrlInput] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (editorRef.current && initialContent) {
      if (editorRef.current.innerHTML !== initialContent) {
        editorRef.current.innerHTML = initialContent;
      }
    }
  }, []); // Run once on mount

  const handleInput = () => {
    if (editorRef.current && onChange) {
      onChange(editorRef.current.innerHTML);
    }
    checkActiveFormats();
  };

  const checkActiveFormats = () => {
    const formats = [];
    if (document.queryCommandState('bold')) formats.push('bold');
    if (document.queryCommandState('italic')) formats.push('italic');
    if (document.queryCommandState('underline')) formats.push('underline');
    if (document.queryCommandState('justifyLeft')) formats.push('justifyLeft');
    if (document.queryCommandState('justifyCenter')) formats.push('justifyCenter');
    if (document.queryCommandState('justifyRight')) formats.push('justifyRight');
    if (document.queryCommandState('insertUnorderedList')) formats.push('insertUnorderedList');
    if (document.queryCommandState('insertOrderedList')) formats.push('insertOrderedList');
    setActiveFormats(formats);
  };

  const execCommand = (command, value = null) => {
    document.execCommand(command, false, value);
    editorRef.current.focus();
    checkActiveFormats();
    handleInput();
  };

  const handleFormatBlock = (tag) => {
    execCommand('formatBlock', tag);
  };

  const openDialog = (type) => {
    setDialogType(type);
    setUrlInput('');
    setIsDialogOpen(true);
  };

  const handleFileUpload = async (e, type) => {
    try {
      setUploading(true);
      const file = e.target.files[0];
      if (!file) return;

      const fileExt = file.name.split('.').pop();
      const fileName = `editor_${type}_${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
      const filePath = `${fileName}`;
      const bucket = 'blog-images'; // Reusing existing bucket for simplicity, ensure it allows PDFs

      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(filePath);

      if (type === 'image') {
        execCommand('insertImage', publicUrl);
      } else if (type === 'pdf') {
        insertPdf(publicUrl, file.name);
      }
      
      setIsDialogOpen(false);
    } catch (error) {
      console.error(`Error uploading ${type}:`, error);
      alert(`Error al subir ${type === 'image' ? 'imagen' : 'archivo'}`);
    } finally {
      setUploading(false);
    }
  };

  const insertPdf = (url, fileName) => {
    // Creates an embedded PDF viewer and a download link
    const pdfHtml = `
      <div class="pdf-container my-4 p-4 border border-slate-200 rounded-lg bg-slate-50">
        <div class="flex items-center justify-between mb-2">
          <div class="flex items-center gap-2 font-medium text-slate-700">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-red-600"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="M10 13H8"/><path d="M12 17h-2"/><path d="M12 13h-2"/><path d="M10 9H8"/></svg>
            <span>${fileName || 'Documento PDF'}</span>
          </div>
          <a href="${url}" target="_blank" rel="noopener noreferrer" class="text-xs bg-blue-600 text-white px-3 py-1.5 rounded-md hover:bg-blue-700 no-underline inline-flex items-center gap-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
            Descargar
          </a>
        </div>
        <div class="aspect-[4/3] w-full bg-slate-200 rounded-md overflow-hidden relative">
           <iframe src="${url}#toolbar=0" class="w-full h-full absolute inset-0" style="border:none;">
             <p>Este navegador no soporta PDFs. <a href="${url}">Descarga el PDF aquí</a>.</p>
           </iframe>
        </div>
      </div>
      <p><br></p>
    `;
    execCommand('insertHTML', pdfHtml);
  };

  const handleDialogSubmit = () => {
    if (!urlInput) return;

    if (dialogType === 'link') {
      execCommand('createLink', urlInput);
    } else if (dialogType === 'image') {
      execCommand('insertImage', urlInput);
    } else if (dialogType === 'pdf') {
      insertPdf(urlInput, 'Documento PDF Externo');
    } else if (dialogType === 'video') {
      // Simple YouTube URL parser
      let videoId = '';
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
      const match = urlInput.match(regExp);
      if (match && match[2].length === 11) {
        videoId = match[2];
      }

      if (videoId) {
        const embedHtml = `
          <div class="video-wrapper my-4" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%;">
            <iframe 
              src="https://www.youtube.com/embed/${videoId}" 
              frameborder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowfullscreen 
              style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border-radius: 0.75rem;"
            ></iframe>
          </div><p><br></p>`;
        execCommand('insertHTML', embedHtml);
      } else {
        alert('URL de YouTube inválida');
        return;
      }
    }
    setIsDialogOpen(false);
  };

  const ToolbarButton = ({ icon: Icon, command, value, isActive, onClick, title }) => (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      className={`h-8 w-8 p-0 ${isActive ? 'bg-slate-200 text-slate-900' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}`}
      onClick={onClick ? onClick : () => execCommand(command, value)}
      title={title}
    >
      <Icon className="w-4 h-4" />
    </Button>
  );

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm flex flex-col h-full min-h-[500px]">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-1 p-2 border-b border-slate-200 bg-slate-50">
        <div className="flex items-center gap-0.5 border-r border-slate-300 pr-2 mr-1">
          <ToolbarButton icon={Undo} command="undo" title="Deshacer" />
          <ToolbarButton icon={Redo} command="redo" title="Rehacer" />
        </div>

        <div className="flex items-center gap-0.5 border-r border-slate-300 pr-2 mr-1">
          <ToolbarButton icon={Bold} command="bold" isActive={activeFormats.includes('bold')} title="Negrita" />
          <ToolbarButton icon={Italic} command="italic" isActive={activeFormats.includes('italic')} title="Cursiva" />
          <ToolbarButton icon={Underline} command="underline" isActive={activeFormats.includes('underline')} title="Subrayado" />
        </div>

        <div className="flex items-center gap-0.5 border-r border-slate-300 pr-2 mr-1">
          <ToolbarButton icon={Type} onClick={() => handleFormatBlock('P')} title="Párrafo" />
          <ToolbarButton icon={Heading1} onClick={() => handleFormatBlock('H2')} title="Título 1" />
          <ToolbarButton icon={Heading2} onClick={() => handleFormatBlock('H3')} title="Título 2" />
          <ToolbarButton icon={Quote} onClick={() => handleFormatBlock('BLOCKQUOTE')} title="Cita" />
        </div>

        <div className="flex items-center gap-0.5 border-r border-slate-300 pr-2 mr-1">
          <ToolbarButton icon={AlignLeft} command="justifyLeft" isActive={activeFormats.includes('justifyLeft')} title="Alinear Izquierda" />
          <ToolbarButton icon={AlignCenter} command="justifyCenter" isActive={activeFormats.includes('justifyCenter')} title="Centrar" />
          <ToolbarButton icon={AlignRight} command="justifyRight" isActive={activeFormats.includes('justifyRight')} title="Alinear Derecha" />
        </div>

        <div className="flex items-center gap-0.5 border-r border-slate-300 pr-2 mr-1">
          <ToolbarButton icon={List} command="insertUnorderedList" isActive={activeFormats.includes('insertUnorderedList')} title="Lista con viñetas" />
          <ToolbarButton icon={ListOrdered} command="insertOrderedList" isActive={activeFormats.includes('insertOrderedList')} title="Lista numérica" />
        </div>

        <div className="flex items-center gap-0.5">
          <ToolbarButton icon={LinkIcon} onClick={() => openDialog('link')} title="Insertar Enlace" />
          <ToolbarButton icon={ImageIcon} onClick={() => openDialog('image')} title="Insertar Imagen" />
          <ToolbarButton icon={Youtube} onClick={() => openDialog('video')} title="Insertar Video" />
          <ToolbarButton icon={FileText} onClick={() => openDialog('pdf')} title="Insertar PDF" />
          <ToolbarButton icon={Eraser} command="removeFormat" title="Limpiar Formato" />
        </div>
      </div>

      {/* Editor Area */}
      <div 
        ref={editorRef}
        className="flex-1 p-6 outline-none overflow-y-auto prose prose-slate max-w-none prose-img:rounded-xl prose-img:shadow-md prose-headings:font-bold prose-a:text-blue-600"
        contentEditable
        onInput={handleInput}
        onMouseUp={checkActiveFormats}
        onKeyUp={checkActiveFormats}
        style={{ minHeight: '400px' }}
      />

      {/* Insert Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md bg-white">
          <DialogHeader>
            <DialogTitle>
              {dialogType === 'link' && 'Insertar Enlace'}
              {dialogType === 'image' && 'Insertar Imagen'}
              {dialogType === 'video' && 'Insertar Video de YouTube'}
              {dialogType === 'pdf' && 'Insertar Documento PDF'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {dialogType === 'image' || dialogType === 'pdf' ? (
              <Tabs defaultValue="upload" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="upload">Subir Archivo</TabsTrigger>
                  <TabsTrigger value="url">URL Externa</TabsTrigger>
                </TabsList>
                <TabsContent value="upload" className="space-y-4 pt-4">
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-300 border-dashed rounded-lg cursor-pointer bg-slate-50 hover:bg-slate-100">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        {uploading ? (
                          <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                        ) : (
                          <>
                            <Upload className="w-8 h-8 mb-2 text-slate-500" />
                            <p className="text-sm text-slate-500 font-medium">
                              Click para subir {dialogType === 'image' ? 'imagen' : 'PDF'}
                            </p>
                          </>
                        )}
                      </div>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept={dialogType === 'image' ? "image/*" : "application/pdf"}
                        onChange={(e) => handleFileUpload(e, dialogType)}
                        disabled={uploading}
                      />
                    </label>
                  </div>
                </TabsContent>
                <TabsContent value="url" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>URL {dialogType === 'image' ? 'de la imagen' : 'del PDF'}</Label>
                    <Input 
                      placeholder={dialogType === 'image' ? "https://ejemplo.com/imagen.jpg" : "https://ejemplo.com/documento.pdf"}
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                    />
                  </div>
                  <DialogFooter>
                    <Button onClick={handleDialogSubmit}>Insertar</Button>
                  </DialogFooter>
                </TabsContent>
              </Tabs>
            ) : (
              <div className="space-y-2">
                <Label>
                  {dialogType === 'link' ? 'URL del enlace' : 'URL de YouTube'}
                </Label>
                <Input 
                  placeholder={dialogType === 'video' ? "https://www.youtube.com/watch?v=..." : "https://..."}
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                />
              </div>
            )}
          </div>

          {dialogType !== 'image' && dialogType !== 'pdf' && (
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
              <Button onClick={handleDialogSubmit}>Insertar</Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RichTextEditor;
