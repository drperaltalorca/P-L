import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Bell, 
  Settings, 
  MessageSquare, 
  Mail, 
  Smartphone, 
  Send, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  History,
  Save,
  Play
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import FormField from '@/components/FormField';
import TextAreaField from '@/components/TextAreaField';
import SelectField from '@/components/SelectField';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

const AppointmentReminders = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Data States
  const [settings, setSettings] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [logs, setLogs] = useState([]);
  const [upcomingReminders, setUpcomingReminders] = useState([]);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch Settings
      const { data: settingsData } = await supabase.from('reminders_settings').select('*').order('channel');
      if (settingsData) setSettings(settingsData);

      // Fetch Templates
      const { data: templatesData } = await supabase.from('reminder_templates').select('*').order('channel');
      if (templatesData) setTemplates(templatesData);

      // Fetch Logs
      const { data: logsData } = await supabase
        .from('reminders_log')
        .select(`
          *,
          appointments (
            patient:patients(name),
            appointment_date,
            appointment_time
          )
        `)
        .order('sent_at', { ascending: false })
        .limit(50);
      if (logsData) setLogs(logsData);

      // Fetch Upcoming Appointments for "Scheduler" view
      const today = new Date().toISOString().split('T')[0];
      const { data: appointments } = await supabase
        .from('appointments')
        .select(`
          *,
          patient:patients(name, email, phone)
        `)
        .gte('appointment_date', today)
        .eq('status', 'scheduled')
        .order('appointment_date')
        .limit(10);
        
      if (appointments) setUpcomingReminders(appointments);

    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Error al cargar datos.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const updateSetting = async (id, field, value) => {
    const newSettings = settings.map(s => s.id === id ? { ...s, [field]: value } : s);
    setSettings(newSettings);
  };
  
  const updateCredential = (id, key, value) => {
    const newSettings = settings.map(s => {
      if (s.id === id) {
        return { 
          ...s, 
          credentials: { ...s.credentials, [key]: value } 
        };
      }
      return s;
    });
    setSettings(newSettings);
  };

  const saveSettings = async () => {
    setLoading(true);
    try {
      for (const setting of settings) {
        await supabase
          .from('reminders_settings')
          .update({ 
            enabled: setting.enabled, 
            credentials: setting.credentials,
            provider: setting.provider
          })
          .eq('id', setting.id);
      }
      toast({ title: "Guardado", description: "Configuración actualizada correctamente." });
    } catch (err) {
      toast({ title: "Error", description: "Error al guardar configuración.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const saveTemplates = async () => {
    setLoading(true);
    try {
      for (const t of templates) {
        await supabase
          .from('reminder_templates')
          .update({ 
            template_text: t.template_text,
            time_before_minutes: t.time_before_minutes,
            enabled: t.enabled
          })
          .eq('id', t.id);
      }
      toast({ title: "Guardado", description: "Plantillas actualizadas correctamente." });
    } catch (err) {
      toast({ title: "Error", description: "Error al guardar plantillas.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const sendTestReminder = async (appointment, channel) => {
    // In a real app, this would call an Edge Function.
    // Here we simulate the process and log it.
    
    setLoading(true);
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const success = Math.random() > 0.2; // 80% success rate simulation

      await supabase.from('reminders_log').insert([{
        appointment_id: appointment.id,
        channel: channel,
        status: success ? 'sent' : 'failed',
        error_message: success ? null : 'Simulated API Error: Invalid Token or Network Timeout',
        metadata: { manual_trigger: true }
      }]);

      if (success) {
        toast({ title: "Enviado", description: `Recordatorio por ${channel} enviado con éxito.` });
      } else {
        toast({ title: "Error", description: `Fallo al enviar por ${channel}.`, variant: "destructive" });
      }
      
      fetchData(); // Refresh logs

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getChannelIcon = (channel) => {
    switch(channel) {
      case 'whatsapp': return <MessageSquare className="w-4 h-4" />;
      case 'email': return <Mail className="w-4 h-4" />;
      case 'sms': return <Smartphone className="w-4 h-4" />;
      case 'telegram': return <Send className="w-4 h-4" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/60 backdrop-blur-xl p-6 rounded-2xl shadow-sm border border-white/50 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-gradient-to-br from-orange-500 to-pink-600 rounded-xl shadow-lg shadow-orange-500/20 text-white">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Recordatorios Automáticos</h1>
            <p className="text-slate-500 text-sm">Gestiona notificaciones y alertas para pacientes</p>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-white p-1 rounded-xl border border-slate-100 shadow-sm w-full md:w-auto grid grid-cols-2 md:grid-cols-4 h-auto">
          <TabsTrigger value="dashboard" className="data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700 py-3 rounded-lg">
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 py-3 rounded-lg">
            Configuración API
          </TabsTrigger>
          <TabsTrigger value="templates" className="data-[state=active]:bg-purple-50 data-[state=active]:text-purple-700 py-3 rounded-lg">
            Plantillas
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-slate-100 data-[state=active]:text-slate-700 py-3 rounded-lg">
            Historial Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
            <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-500" />
              Próximos Turnos (Cola de Envío)
            </h3>
            
            {upcomingReminders.length === 0 ? (
              <p className="text-slate-500 text-center py-8">No hay turnos próximos programados.</p>
            ) : (
              <div className="grid gap-4">
                {upcomingReminders.map(apt => (
                  <div key={apt.id} className="flex flex-col md:flex-row items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="flex items-center gap-4 mb-4 md:mb-0">
                      <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-slate-500 font-bold border border-slate-200 shadow-sm">
                        {apt.patient?.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">{apt.patient?.name}</p>
                        <p className="text-sm text-slate-500">
                          {new Date(apt.appointment_date).toLocaleDateString()} • {apt.appointment_time}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 justify-end">
                      {['whatsapp', 'email', 'sms'].map(channel => {
                        const isEnabled = apt.notification_preferences?.[channel];
                        return (
                          isEnabled && (
                            <Button 
                              key={channel}
                              size="sm" 
                              variant="outline" 
                              onClick={() => sendTestReminder(apt, channel)}
                              className="gap-2 bg-white hover:bg-slate-50"
                              disabled={loading}
                            >
                              {getChannelIcon(channel)}
                              Enviar {channel.charAt(0).toUpperCase() + channel.slice(1)}
                            </Button>
                          )
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {settings.map(setting => (
              <div key={setting.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${setting.enabled ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-400'}`}>
                      {getChannelIcon(setting.channel)}
                    </div>
                    <h3 className="font-bold text-slate-900 capitalize">{setting.channel}</h3>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id={`enable-${setting.id}`} 
                      checked={setting.enabled}
                      onCheckedChange={(c) => updateSetting(setting.id, 'enabled', c)}
                    />
                    <Label htmlFor={`enable-${setting.id}`}>Habilitar</Label>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <SelectField
                    label="Proveedor"
                    value={setting.provider || ''}
                    onChange={(v) => updateSetting(setting.id, 'provider', v)}
                    options={[
                      { value: 'twilio', label: 'Twilio' },
                      { value: 'sendgrid', label: 'SendGrid' },
                      { value: 'telegram', label: 'Telegram Bot' },
                      { value: 'aws_sns', label: 'AWS SNS' }
                    ]}
                  />
                  
                  {/* Dynamic Fields based on provider could go here, for now generic inputs */}
                  <FormField 
                    label="API Key / Token" 
                    type="password"
                    placeholder="••••••••••••••"
                    value={setting.credentials?.api_key || ''}
                    onChange={(e) => updateCredential(setting.id, 'api_key', e.target.value)}
                  />
                  <FormField 
                    label="Account SID / ID" 
                    placeholder="Ex. AC1234..."
                    value={setting.credentials?.account_sid || ''}
                    onChange={(e) => updateCredential(setting.id, 'account_sid', e.target.value)}
                  />
                  <FormField 
                    label="Sender Number / Email" 
                    placeholder="+1234567890 or doctor@clinic.com"
                    value={setting.credentials?.from || ''}
                    onChange={(e) => updateCredential(setting.id, 'from', e.target.value)}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-end">
            <Button onClick={saveSettings} className="gap-2 bg-slate-900 hover:bg-slate-800 text-white" disabled={loading}>
              <Save className="w-4 h-4" /> Guardar Cambios
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {templates.map((template) => (
              <div key={template.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-slate-900 capitalize flex items-center gap-2">
                    {getChannelIcon(template.channel)}
                    Plantilla {template.channel}
                  </h3>
                  <Badge variant={template.enabled ? 'success' : 'secondary'}>
                    {template.enabled ? 'Activo' : 'Inactivo'}
                  </Badge>
                </div>

                <div className="space-y-4">
                  <TextAreaField
                    label="Mensaje"
                    rows={4}
                    value={template.template_text}
                    onChange={(v) => {
                      const newTemplates = templates.map(t => t.id === template.id ? { ...t, template_text: v } : t);
                      setTemplates(newTemplates);
                    }}
                  />
                  <div className="flex gap-2 text-xs text-slate-500 bg-slate-50 p-2 rounded-lg">
                    Variables: <code className="bg-white px-1 rounded border">{'{{patient_name}}'}</code> <code className="bg-white px-1 rounded border">{'{{date}}'}</code> <code className="bg-white px-1 rounded border">{'{{time}}'}</code>
                  </div>
                  
                  <div className="flex gap-4">
                     <FormField
                       label="Enviar antes de (minutos)"
                       type="number"
                       value={template.time_before_minutes}
                       onChange={(e) => {
                          const newTemplates = templates.map(t => t.id === template.id ? { ...t, time_before_minutes: parseInt(e.target.value) } : t);
                          setTemplates(newTemplates);
                       }}
                     />
                     <div className="flex items-end pb-3">
                       <Checkbox 
                         id={`templ-enable-${template.id}`}
                         checked={template.enabled}
                         onCheckedChange={(c) => {
                            const newTemplates = templates.map(t => t.id === template.id ? { ...t, enabled: c } : t);
                            setTemplates(newTemplates);
                         }}
                       />
                       <Label htmlFor={`templ-enable-${template.id}`} className="ml-2">Usar esta plantilla</Label>
                     </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-end">
            <Button onClick={saveTemplates} className="gap-2 bg-slate-900 hover:bg-slate-800 text-white" disabled={loading}>
              <Save className="w-4 h-4" /> Guardar Plantillas
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 overflow-hidden">
            <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
              <History className="w-5 h-5 text-slate-500" />
              Historial de Envíos
            </h3>
            
            {logs.length === 0 ? (
              <p className="text-center text-slate-400 py-8">No hay registros de envíos aún.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 text-slate-500 font-medium">
                    <tr>
                      <th className="p-4 rounded-tl-xl">Fecha/Hora</th>
                      <th className="p-4">Paciente</th>
                      <th className="p-4">Canal</th>
                      <th className="p-4">Estado</th>
                      <th className="p-4 rounded-tr-xl">Detalles</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {logs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50/50">
                        <td className="p-4 text-slate-600">
                          {new Date(log.sent_at).toLocaleString()}
                        </td>
                        <td className="p-4 font-medium text-slate-900">
                          {log.appointments?.patient?.name || 'Desconocido'}
                        </td>
                        <td className="p-4 capitalize flex items-center gap-2">
                           {getChannelIcon(log.channel)}
                           {log.channel}
                        </td>
                        <td className="p-4">
                          <Badge variant={log.status === 'sent' ? 'success' : log.status === 'pending' ? 'warning' : 'destructive'}>
                            {log.status === 'sent' ? 'ENVIADO' : log.status === 'pending' ? 'PENDIENTE' : 'FALLIDO'}
                          </Badge>
                        </td>
                        <td className="p-4 text-slate-500 max-w-xs truncate" title={log.error_message || JSON.stringify(log.metadata)}>
                          {log.error_message || (log.metadata ? 'Test manual' : 'Automático')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AppointmentReminders;