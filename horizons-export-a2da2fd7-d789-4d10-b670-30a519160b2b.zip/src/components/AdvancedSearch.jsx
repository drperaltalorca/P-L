import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, User, Calendar, FileText, Pill, Activity, ChevronDown, ChevronUp } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import FormField from '@/components/FormField';
import SelectField from '@/components/SelectField';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

const AdvancedSearch = ({ onSelectPatient }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(true);

  const [filters, setFilters] = useState({
    name: '',
    minAge: '',
    maxAge: '',
    diagnosis: '',
    medication: '',
    visitDateStart: '',
    visitDateEnd: '',
    appointmentStatus: '',
    notesKeyword: ''
  });

  const updateFilter = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      name: '',
      minAge: '',
      maxAge: '',
      diagnosis: '',
      medication: '',
      visitDateStart: '',
      visitDateEnd: '',
      appointmentStatus: '',
      notesKeyword: ''
    });
    setResults([]);
    setHasSearched(false);
    setFiltersOpen(true);
  };

  const handleSearch = async () => {
    setLoading(true);
    setHasSearched(true);
    setFiltersOpen(false);

    try {
      // Base query on patients
      let query = supabase
        .from('patients')
        .select(`
          *,
          appointments (
            appointment_date,
            status
          ),
          prescriptions (
            medication_name
          ),
          clinical_history (
            visit_date,
            diagnosis,
            clinical_notes
          )
        `);

      // 1. Direct Patient Filters
      if (filters.name) {
        query = query.ilike('name', `%${filters.name}%`);
      }
      if (filters.minAge) {
        query = query.gte('age', filters.minAge);
      }
      if (filters.maxAge) {
        query = query.lte('age', filters.maxAge);
      }
      if (filters.diagnosis) {
        // Search in the text array medical_conditions
        query = query.contains('medical_conditions', [filters.diagnosis]);
      }

      const { data: patients, error } = await query;

      if (error) throw error;

      // 2. Client-side filtering for related tables (Simulating complex JOIN/WHERE NOT EXISTS logic)
      // This allows us to handle "Patients who have X" without complex inner joins that might exclude patients erroneously in the initial fetch
      // or duplicate rows.
      const filteredResults = patients.filter(patient => {
        let match = true;

        // Medication Filter
        if (filters.medication) {
          const hasMed = patient.prescriptions?.some(p => 
            p.medication_name.toLowerCase().includes(filters.medication.toLowerCase())
          );
          if (!hasMed) match = false;
        }

        // Appointment Status Filter
        if (match && filters.appointmentStatus) {
          const hasStatus = patient.appointments?.some(a => 
            a.status === filters.appointmentStatus
          );
          if (!hasStatus) match = false;
        }

        // Visit Date Range Filter
        if (match && (filters.visitDateStart || filters.visitDateEnd)) {
          const hasVisitInRange = patient.appointments?.some(a => {
            const d = new Date(a.appointment_date);
            const start = filters.visitDateStart ? new Date(filters.visitDateStart) : new Date('1900-01-01');
            const end = filters.visitDateEnd ? new Date(filters.visitDateEnd) : new Date('2100-01-01');
            return d >= start && d <= end;
          });
          // Also check clinical history dates
          const hasHistoryInRange = patient.clinical_history?.some(h => {
             const d = new Date(h.visit_date);
             const start = filters.visitDateStart ? new Date(filters.visitDateStart) : new Date('1900-01-01');
             const end = filters.visitDateEnd ? new Date(filters.visitDateEnd) : new Date('2100-01-01');
             return d >= start && d <= end;
          });

          if (!hasVisitInRange && !hasHistoryInRange) match = false;
        }

        // Clinical Notes Keyword
        if (match && filters.notesKeyword) {
          const hasKeyword = patient.clinical_history?.some(h => 
            h.clinical_notes?.toLowerCase().includes(filters.notesKeyword.toLowerCase())
          );
          if (!hasKeyword) match = false;
        }

        return match;
      });

      setResults(filteredResults);

      if (filteredResults.length === 0) {
        toast({
          title: "Sin resultados",
          description: "No se encontraron pacientes con esos criterios.",
          variant: "default"
        });
      }

    } catch (err) {
      console.error('Search error:', err);
      toast({
        title: "Error de búsqueda",
        description: "Hubo un problema al realizar la búsqueda.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/60 backdrop-blur-xl p-6 rounded-2xl shadow-sm border border-white/50 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-xl shadow-lg shadow-indigo-500/20 text-white">
            <Search className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700">
              Búsqueda Avanzada
            </h1>
            <p className="text-slate-500 text-sm">
              Filtrado multicriterio de pacientes e historias clínicas
            </p>
          </div>
        </div>
        <Button 
          variant="outline" 
          onClick={() => setFiltersOpen(!filtersOpen)}
          className="gap-2"
        >
          {filtersOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          {filtersOpen ? 'Ocultar Filtros' : 'Mostrar Filtros'}
        </Button>
      </div>

      <motion.div 
        initial={false}
        animate={{ height: filtersOpen ? 'auto' : 0, opacity: filtersOpen ? 1 : 0 }}
        className="overflow-hidden"
      >
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FormField
              label="Nombre del Paciente"
              icon={<User className="w-4 h-4" />}
              placeholder="Buscar por nombre..."
              value={filters.name}
              onChange={v => updateFilter('name', v)}
            />
            
            <div className="flex gap-4">
              <FormField
                label="Edad Mínima"
                type="number"
                placeholder="0"
                value={filters.minAge}
                onChange={v => updateFilter('minAge', v)}
              />
              <FormField
                label="Edad Máxima"
                type="number"
                placeholder="100"
                value={filters.maxAge}
                onChange={v => updateFilter('maxAge', v)}
              />
            </div>

            <FormField
              label="Diagnóstico / Condición"
              icon={<Activity className="w-4 h-4" />}
              placeholder="Ej. Hipertensión"
              value={filters.diagnosis}
              onChange={v => updateFilter('diagnosis', v)}
            />

            <FormField
              label="Medicamento Prescripto"
              icon={<Pill className="w-4 h-4" />}
              placeholder="Ej. Ibuprofeno"
              value={filters.medication}
              onChange={v => updateFilter('medication', v)}
            />

            <SelectField
              label="Estado de Turno"
              value={filters.appointmentStatus}
              onChange={v => updateFilter('appointmentStatus', v)}
              options={[
                { value: '', label: 'Todos' },
                { value: 'scheduled', label: 'Programado' },
                { value: 'completed', label: 'Completado' },
                { value: 'cancelled', label: 'Cancelado' }
              ]}
            />

            <FormField
              label="Palabra clave en Notas"
              icon={<FileText className="w-4 h-4" />}
              placeholder="Ej. dolor, fiebre..."
              value={filters.notesKeyword}
              onChange={v => updateFilter('notesKeyword', v)}
            />

            <div className="flex gap-4 lg:col-span-2">
              <FormField
                label="Visita: Desde"
                type="date"
                value={filters.visitDateStart}
                onChange={v => updateFilter('visitDateStart', v)}
                className="flex-1"
              />
              <FormField
                label="Visita: Hasta"
                type="date"
                value={filters.visitDateEnd}
                onChange={v => updateFilter('visitDateEnd', v)}
                className="flex-1"
              />
            </div>

            <div className="flex items-end gap-2">
              <Button 
                onClick={handleSearch} 
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white h-[46px]"
                disabled={loading}
              >
                {loading ? 'Buscando...' : 'Buscar Pacientes'}
              </Button>
              <Button 
                variant="outline"
                onClick={clearFilters}
                className="h-[46px]"
              >
                Limpiar
              </Button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Results */}
      <div className="space-y-4">
        {hasSearched && (
          <div className="flex items-center gap-2 text-sm text-slate-500 px-2">
            <Filter className="w-4 h-4" />
            Resultados encontrados: <span className="font-bold text-slate-900">{results.length}</span>
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3].map(i => <div key={i} className="h-48 bg-white rounded-3xl shadow-sm animate-pulse" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {results.map((patient, idx) => (
              <motion.div
                key={patient.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-lg transition-all flex flex-col justify-between"
              >
                <div className="flex items-start gap-4 mb-4">
                  {patient.photo_url ? (
                    <img src={patient.photo_url} alt={patient.name} className="w-16 h-16 rounded-2xl object-cover bg-slate-100" />
                  ) : (
                    <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl font-bold">
                      {patient.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h3 className="font-bold text-slate-900 line-clamp-1">{patient.name}</h3>
                    <p className="text-sm text-slate-500">{patient.age} años • {patient.gender}</p>
                    {patient.clinical_history?.[0] && (
                      <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Última: {new Date(patient.clinical_history[0].visit_date || patient.created_at).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  {patient.medical_conditions?.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {patient.medical_conditions.slice(0, 3).map((c, i) => (
                        <Badge key={i} variant="warning" className="text-[10px]">{c}</Badge>
                      ))}
                      {patient.medical_conditions.length > 3 && (
                        <Badge variant="outline" className="text-[10px]">+{patient.medical_conditions.length - 3}</Badge>
                      )}
                    </div>
                  )}
                  
                  {/* Show snippet of matching data if search was deep */}
                  {filters.notesKeyword && patient.clinical_history?.length > 0 && (
                     <div className="bg-yellow-50 p-2 rounded-lg border border-yellow-100 text-xs text-yellow-800 italic truncate">
                        "{filters.notesKeyword}" encontrado en historia
                     </div>
                  )}
                </div>

                <Button 
                  className="w-full" 
                  variant="secondary"
                  onClick={() => onSelectPatient(patient)}
                >
                  Ver Ficha Completa
                </Button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdvancedSearch;