
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Phone, MapPin, Clock, Building, MessageSquare, 
  Send, HelpCircle, ExternalLink, Mail, PhoneCall
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import FormField from '@/components/FormField';
import TextAreaField from '@/components/TextAreaField';

const SupportSection = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.message) {
      toast({
        title: "Campos incompletos",
        description: "Por favor completá tu nombre y el mensaje.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('doctor_questions')
        .insert([{
          patient_name: contactForm.name,
          email: contactForm.email,
          question: contactForm.message,
          status: 'pending'
        }]);

      if (error) throw error;

      toast({
        title: "Mensaje enviado",
        description: "Tu consulta ha sido enviada al médico exitosamente.",
        className: "bg-green-50 border-green-200 text-green-800"
      });
      setContactForm({ name: '', email: '', message: '' });

    } catch (err) {
      console.error('Error sending message:', err);
      toast({
        title: "Error",
        description: "No se pudo enviar el mensaje. Intente nuevamente.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in-50 duration-500">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-sky-600 to-blue-600 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full -translate-y-1/2 translate-x-1/4 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
              <HelpCircle className="w-8 h-8 text-sky-200" />
              Centro de Ayuda y Contacto
            </h1>
            <p className="text-sky-100 max-w-xl">
              Información de contacto, ubicaciones y canal directo de comunicación con el equipo médico.
            </p>
          </div>
          <Button 
            className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm"
            onClick={() => window.open('https://wa.me/5492612193590', '_blank')}
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            WhatsApp Rápido
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Contact Info */}
        <div className="lg:col-span-1 space-y-6">
          {/* Main Office Info */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
              <Building className="w-5 h-5 text-blue-600" />
              Secretaría / Consultorios
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3 text-slate-600 group">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-100 transition-colors">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Dirección</span>
                  <p className="font-medium text-slate-800">Calle Carlos Washington Lencinas 66</p>
                  <p className="text-sm">Primer piso, Complejo IDM</p>
                </div>
              </div>

              <div className="flex items-start gap-3 text-slate-600 group">
                <div className="p-2 bg-green-50 text-green-600 rounded-lg group-hover:bg-green-100 transition-colors">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Teléfono / WhatsApp</span>
                  <a href="tel:+542612193590" className="font-medium text-slate-800 hover:text-blue-600 transition-colors block">
                    +54 (261) 219.3590
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 text-slate-600 group">
                <div className="p-2 bg-amber-50 text-amber-600 rounded-lg group-hover:bg-amber-100 transition-colors">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Horarios de Atención</span>
                  <p className="font-medium text-slate-800">Lunes a Viernes</p>
                  <p className="text-sm">Horario comercial</p>
                  <p className="font-medium text-slate-800 mt-1">Sábados</p>
                  <p className="text-sm">Horario comercial</p>
                </div>
              </div>
            </div>
          </div>

          {/* Policlínica San Rafael */}
          <div className="bg-gradient-to-br from-indigo-50 to-violet-50 rounded-2xl p-6 shadow-sm border border-indigo-100">
             <h3 className="font-bold text-indigo-900 flex items-center gap-2 mb-3">
               <Building className="w-5 h-5 text-indigo-600" />
               Policlínica San Rafael
             </h3>
             <p className="text-sm text-indigo-800/80 mb-4 leading-relaxed">
               Institución asociada de referencia para procedimientos quirúrgicos de alta complejidad e internación. Contamos con equipamiento de última generación para garantizar la seguridad del paciente.
             </p>
             <Button variant="outline" className="w-full border-indigo-200 text-indigo-700 hover:bg-indigo-100 bg-white/50">
               <ExternalLink className="w-3 h-3 mr-2" />
               Ver Ubicación en Mapa
             </Button>
          </div>
        </div>

        {/* Right Column - Direct Message Form */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden h-full">
            <div className="bg-slate-50 border-b border-slate-100 p-6">
              <h3 className="font-bold text-slate-800 text-lg flex items-center gap-2">
                <Mail className="w-5 h-5 text-sky-600" />
                Contacto Directo con el Médico
              </h3>
              <p className="text-slate-500 text-sm mt-1">
                Utilice este formulario para consultas médicas específicas o dudas sobre tratamientos. Su mensaje será recibido directamente por el profesional.
              </p>
            </div>

            <div className="p-6 md:p-8">
              <form onSubmit={handleSendMessage} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    label="Nombre Completo"
                    placeholder="Su nombre"
                    value={contactForm.name}
                    onChange={(v) => setContactForm({...contactForm, name: v})}
                  />
                  <FormField
                    label="Email de Contacto"
                    type="email"
                    placeholder="para recibir respuesta"
                    value={contactForm.email}
                    onChange={(v) => setContactForm({...contactForm, email: v})}
                  />
                </div>
                
                <TextAreaField
                  label="Mensaje o Consulta Médica"
                  placeholder="Describa su consulta con el mayor detalle posible..."
                  value={contactForm.message}
                  onChange={(v) => setContactForm({...contactForm, message: v})}
                  className="min-h-[150px]"
                />

                <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                  <p className="text-xs text-slate-400 italic">
                    * En caso de urgencia, por favor diríjase a la guardia médica más cercana o llame al 911.
                  </p>
                  <Button 
                    type="submit" 
                    disabled={loading}
                    className="bg-sky-600 hover:bg-sky-700 text-white min-w-[150px]"
                  >
                    {loading ? (
                      'Enviando...'
                    ) : (
                      <>
                        Enviar Consulta <Send className="w-4 h-4 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportSection;
