
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Send, MessageSquare, Mail, HelpCircle, CheckCircle, UserPlus } from 'lucide-react';

const DoctorCommunication = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('questions');
  
  // -- Questions State --
  const [questions, setQuestions] = useState([]);
  const [newQuestion, setNewQuestion] = useState({ patient: '', email: '', question: '' });
  
  // -- Chat State --
  const [chatMessages, setChatMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const chatEndRef = useRef(null);

  // -- Realtime & Fetching --
  useEffect(() => {
    fetchQuestions();
    fetchChatHistory();

    // Subscribe to Chat
    const channel = supabase
      .channel('doctor-chat')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'doctor_chat_messages' }, 
        (payload) => {
          setChatMessages((prev) => [...prev, payload.new]);
          scrollToBottom();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const scrollToBottom = () => {
    setTimeout(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  // --- Questions Logic ---
  const fetchQuestions = async () => {
    const { data } = await supabase
      .from('doctor_questions')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setQuestions(data);
  };

  const handleSubmitQuestion = async () => {
    if (!newQuestion.question || !newQuestion.patient) return;
    
    // 1. Insert to DB
    const { error } = await supabase.from('doctor_questions').insert({
       patient_name: newQuestion.patient,
       email: newQuestion.email,
       question: newQuestion.question,
       status: 'pending'
    });

    if (error) {
       toast({ title: "Error", variant: "destructive" });
       return;
    }

    // 2. Trigger Email (Simulated Edge Function)
    await supabase.functions.invoke('send-doctor-email', {
      body: { 
        type: 'new_question', 
        payload: { 
           to: ["drraltalorca@gmail.com", "juaniperlor@gmail.com"],
           subject: `Nueva Consulta de ${newQuestion.patient}`,
           body: newQuestion.question 
        } 
      }
    });

    toast({ title: "Consulta Enviada", description: "Se notificó a los doctores por email." });
    setNewQuestion({ patient: '', email: '', question: '' });
    fetchQuestions();
  };

  const markAnswered = async (id) => {
     await supabase.from('doctor_questions').update({ status: 'answered' }).eq('id', id);
     fetchQuestions();
     toast({ title: "Marcada como respondida" });
  };

  // --- Chat Logic ---
  const fetchChatHistory = async () => {
     const { data } = await supabase
        .from('doctor_chat_messages')
        .select('*')
        .order('created_at', { ascending: true })
        .limit(50);
     if (data) {
        setChatMessages(data);
        scrollToBottom();
     }
  };

  const sendMessage = async () => {
     if (!currentMessage.trim()) return;

     // In a real app, sender_name comes from Auth. For now, random/fixed.
     const sender = "Dr. Usuario"; 

     await supabase.from('doctor_chat_messages').insert({
        sender_name: sender,
        message: currentMessage
     });
     setCurrentMessage('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
       
       {/* Left Column: Q&A Management */}
       <div className="lg:col-span-2 flex flex-col gap-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex-1 flex flex-col">
             <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
                <div className="flex justify-between items-center mb-4">
                   <h2 className="text-xl font-bold flex items-center gap-2">
                      <HelpCircle className="w-5 h-5 text-indigo-600" />
                      Consultas Médicas
                   </h2>
                   <TabsList>
                      <TabsTrigger value="questions">Pendientes ({questions.filter(q => q.status === 'pending').length})</TabsTrigger>
                      <TabsTrigger value="ask">Nueva Consulta</TabsTrigger>
                   </TabsList>
                </div>

                <TabsContent value="questions" className="flex-1 overflow-y-auto pr-2 space-y-3">
                   {questions.length === 0 && <p className="text-slate-400 text-center py-10">No hay consultas pendientes.</p>}
                   {questions.map(q => (
                      <div key={q.id} className={`p-4 rounded-xl border ${q.status === 'answered' ? 'bg-slate-50 border-slate-100 opacity-60' : 'bg-indigo-50/50 border-indigo-100'}`}>
                         <div className="flex justify-between items-start mb-2">
                            <div>
                               <span className="font-bold text-slate-800">{q.patient_name}</span>
                               {q.email && <span className="text-xs text-slate-500 ml-2">&lt;{q.email}&gt;</span>}
                            </div>
                            <Badge variant={q.status === 'pending' ? 'destructive' : 'outline'}>
                               {q.status === 'pending' ? 'Pendiente' : 'Respondida'}
                            </Badge>
                         </div>
                         <p className="text-sm text-slate-700 mb-3 bg-white p-3 rounded-lg border border-slate-100 italic">"{q.question}"</p>
                         
                         <div className="flex justify-between items-center text-xs text-slate-400">
                            <span>{new Date(q.created_at).toLocaleString()}</span>
                            {q.status === 'pending' && (
                               <Button size="sm" variant="outline" className="h-7 bg-white text-green-600 hover:text-green-700 border-green-200" onClick={() => markAnswered(q.id)}>
                                  <CheckCircle className="w-3 h-3 mr-1" /> Marcar Respondida
                               </Button>
                            )}
                         </div>
                      </div>
                   ))}
                </TabsContent>

                <TabsContent value="ask" className="space-y-4 pt-4">
                   <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <h3 className="font-semibold mb-4 text-slate-700">Enviar consulta al equipo médico</h3>
                      <div className="grid gap-4">
                         <div className="grid grid-cols-2 gap-4">
                            <Input 
                               placeholder="Nombre del Paciente" 
                               value={newQuestion.patient} 
                               onChange={e => setNewQuestion({...newQuestion, patient: e.target.value})} 
                            />
                            <Input 
                               placeholder="Email de contacto (Opcional)" 
                               value={newQuestion.email} 
                               onChange={e => setNewQuestion({...newQuestion, email: e.target.value})} 
                            />
                         </div>
                         <textarea 
                            className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm min-h-[100px]"
                            placeholder="Escriba la consulta o duda médica aquí..."
                            value={newQuestion.question}
                            onChange={e => setNewQuestion({...newQuestion, question: e.target.value})}
                         />
                         <div className="flex justify-between items-center">
                            <span className="text-xs text-slate-500">
                               Se enviará copia a: <span className="font-mono">drraltalorca@gmail.com, juaniperlor@gmail.com</span>
                            </span>
                            <Button onClick={handleSubmitQuestion} className="bg-indigo-600 hover:bg-indigo-700 text-white">
                               <Mail className="w-4 h-4 mr-2" /> Enviar Consulta
                            </Button>
                         </div>
                      </div>
                   </div>
                </TabsContent>
             </Tabs>
          </div>
       </div>

       {/* Right Column: Internal Chat */}
       <div className="bg-white rounded-2xl shadow-sm border border-slate-100 flex flex-col overflow-hidden h-full">
          <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
             <div className="bg-green-100 p-2 rounded-lg text-green-600">
                <MessageSquare className="w-5 h-5" />
             </div>
             <div>
                <h3 className="font-bold text-slate-800">Chat Médico Interno</h3>
                <p className="text-xs text-green-600 font-medium flex items-center gap-1">
                   <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" /> En línea
                </p>
             </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/30">
             {chatMessages.map((msg, idx) => (
                <div key={idx} className={`flex flex-col ${msg.sender_name === 'Dr. Usuario' ? 'items-end' : 'items-start'}`}>
                   <div className={`
                      max-w-[85%] px-3 py-2 rounded-xl text-sm shadow-sm
                      ${msg.sender_name === 'Dr. Usuario' 
                         ? 'bg-blue-600 text-white rounded-br-none' 
                         : 'bg-white border border-slate-200 text-slate-700 rounded-bl-none'}
                   `}>
                      <span className="text-[10px] opacity-70 block mb-0.5 font-bold">{msg.sender_name}</span>
                      {msg.message}
                   </div>
                   <span className="text-[9px] text-slate-400 mt-1 px-1">
                      {new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                   </span>
                </div>
             ))}
             <div ref={chatEndRef} />
          </div>

          <div className="p-3 border-t border-slate-100 bg-white">
             <div className="flex gap-2">
                <Input 
                   placeholder="Escribir mensaje..." 
                   className="flex-1"
                   value={currentMessage}
                   onChange={e => setCurrentMessage(e.target.value)}
                   onKeyDown={e => e.key === 'Enter' && sendMessage()}
                />
                <Button size="icon" onClick={sendMessage} className="bg-blue-600 hover:bg-blue-700 text-white">
                   <Send className="w-4 h-4" />
                </Button>
             </div>
          </div>
       </div>
    </div>
  );
};

export default DoctorCommunication;
