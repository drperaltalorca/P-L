
import React from 'react';
import { cn } from '@/lib/utils';

const PatientLink = ({ patientId, name, className, children, showIcon = false }) => {
  const handleClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!patientId) return;

    // Dispatch custom event that App.jsx listens to
    const event = new CustomEvent('open-patient-profile', {
      detail: { patientId }
    });
    window.dispatchEvent(event);
  };

  if (!patientId) {
    return <span className={cn("text-slate-800 font-medium", className)}>{children || name}</span>;
  }

  return (
    <button 
      onClick={handleClick}
      className={cn(
        "text-blue-600 hover:text-blue-800 hover:underline font-bold transition-colors inline-flex items-center gap-1 p-0 bg-transparent border-0 cursor-pointer text-left focus:outline-none focus:ring-2 focus:ring-blue-500/20 rounded-sm", 
        className
      )}
      title="Ver perfil del paciente"
    >
      {showIcon && (
        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-external-link"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
      )}
      {children || name}
    </button>
  );
};

export default PatientLink;
