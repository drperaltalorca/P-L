import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line 
} from 'recharts';
import { FileText, Download, Printer, TrendingUp, Users, Calendar, Activity } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import FormField from '@/components/FormField';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const ReportsAnalytics = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0], // Jan 1st of current year
    end: new Date().toISOString().split('T')[0] // Today
  });
  
  const [stats, setStats] = useState({
    totalPatients: 0,
    appointmentsCount: 0,
    topDiagnoses: [],
    ageDistribution: [],
    appointmentsByStatus: [],
    topMedications: [],
    avgVisits: 0
  });

  useEffect(() => {
    fetchStats();
  }, [dateRange]);

  const fetchStats = async () => {
    setLoading(true);
    try {
      // 1. Fetch Appointments in Range
      const { data: appointments } = await supabase
        .from('appointments')
        .select('*')
        .gte('appointment_date', dateRange.start)
        .lte('appointment_date', dateRange.end);

      // 2. Fetch Patients (All time for total, but need age)
      const { data: patients } = await supabase
        .from('patients')
        .select('*, clinical_history(id)');

      // 3. Fetch Prescriptions (For top meds)
      const { data: prescriptions } = await supabase
        .from('prescriptions')
        .select('medication_name, prescribed_date')
        .gte('prescribed_date', dateRange.start)
        .lte('prescribed_date', dateRange.end);

      // --- Processing Data ---

      // Age Distribution
      const ageGroups = { '0-18': 0, '19-35': 0, '36-50': 0, '51-70': 0, '70+': 0 };
      patients?.forEach(p => {
        if (p.age <= 18) ageGroups['0-18']++;
        else if (p.age <= 35) ageGroups['19-35']++;
        else if (p.age <= 50) ageGroups['36-50']++;
        else if (p.age <= 70) ageGroups['51-70']++;
        else ageGroups['70+']++;
      });
      const ageChartData = Object.entries(ageGroups).map(([name, value]) => ({ name, value }));

      // Appointment Status
      const statusCounts = {};
      appointments?.forEach(a => {
        const status = a.status || 'pending';
        statusCounts[status] = (statusCounts[status] || 0) + 1;
      });
      const statusChartData = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));

      // Top Diagnoses (From patients array)
      const diagnosesCounts = {};
      patients?.forEach(p => {
        p.medical_conditions?.forEach(c => {
          diagnosesCounts[c] = (diagnosesCounts[c] || 0) + 1;
        });
      });
      const diagnosesChartData = Object.entries(diagnosesCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([name, value]) => ({ name, value }));

      // Top Medications
      const medsCounts = {};
      prescriptions?.forEach(p => {
        medsCounts[p.medication_name] = (medsCounts[p.medication_name] || 0) + 1;
      });
      const medsChartData = Object.entries(medsCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([name, value]) => ({ name, value }));

      // Avg Visits
      const totalVisits = patients?.reduce((acc, curr) => acc + (curr.clinical_history?.length || 0), 0) || 0;
      const avg = patients?.length ? (totalVisits / patients.length).toFixed(1) : 0;

      setStats({
        totalPatients: patients?.length || 0,
        appointmentsCount: appointments?.length || 0,
        topDiagnoses: diagnosesChartData,
        ageDistribution: ageChartData,
        appointmentsByStatus: statusChartData,
        topMedications: medsChartData,
        avgVisits: avg
      });

    } catch (err) {
      console.error("Error fetching stats:", err);
      toast({ title: "Error", description: "No se pudieron cargar las estadísticas", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const exportCSV = () => {
    const csvRows = [];
    
    // Summary
    csvRows.push(['Métrica', 'Valor']);
    csvRows.push(['Total Pacientes', stats.totalPatients]);
    csvRows.push(['Turnos (Periodo)', stats.appointmentsCount]);
    csvRows.push(['Promedio Visitas', stats.avgVisits]);
    csvRows.push([]); // Empty line

    // Diagnoses
    csvRows.push(['Diagnóstico', 'Cantidad']);
    stats.topDiagnoses.forEach(d => csvRows.push([d.name, d.value]));
    csvRows.push([]);

    // Medications
    csvRows.push(['Medicamento', 'Prescripciones']);
    stats.topMedications.forEach(m => csvRows.push([m.name, m.value]));

    const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `reporte_medico_${dateRange.end}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8">
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-white/60 backdrop-blur-xl p-6 rounded-2xl shadow-sm border border-white/50 no-print">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Reportes y Estadísticas</h1>
          <p className="text-slate-500">Análisis detallado de la actividad clínica</p>
        </div>
        
        <div className="flex flex-wrap gap-4 items-end">
          <div className="flex gap-2">
            <FormField 
              label="Desde" 
              type="date" 
              value={dateRange.start} 
              onChange={v => setDateRange(prev => ({...prev, start: v}))}
              className="w-40"
            />
            <FormField 
              label="Hasta" 
              type="date" 
              value={dateRange.end} 
              onChange={v => setDateRange(prev => ({...prev, end: v}))}
              className="w-40"
            />
          </div>
          <div className="flex gap-2">
             <Button variant="outline" onClick={handlePrint}>
               <Printer className="w-4 h-4 mr-2" /> Imprimir / PDF
             </Button>
             <Button variant="default" onClick={exportCSV} className="bg-emerald-600 hover:bg-emerald-700 text-white">
               <Download className="w-4 h-4 mr-2" /> Exportar CSV
             </Button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="h-96 flex items-center justify-center text-slate-400">Cargando datos...</div>
      ) : (
        <>
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatsCard 
              title="Total Pacientes" 
              value={stats.totalPatients} 
              icon={<Users className="w-5 h-5 text-blue-600" />}
              color="bg-blue-50 border-blue-100"
            />
            <StatsCard 
              title="Turnos (Periodo)" 
              value={stats.appointmentsCount} 
              icon={<Calendar className="w-5 h-5 text-violet-600" />}
              color="bg-violet-50 border-violet-100"
            />
            <StatsCard 
              title="Promedio Visitas/Pac." 
              value={stats.avgVisits} 
              icon={<Activity className="w-5 h-5 text-emerald-600" />}
              color="bg-emerald-50 border-emerald-100"
            />
            <StatsCard 
              title="Diagnósticos Activos" 
              value={stats.topDiagnoses.length} 
              icon={<TrendingUp className="w-5 h-5 text-amber-600" />}
              color="bg-amber-50 border-amber-100"
            />
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Age Distribution */}
            <ChartBox title="Distribución por Edad del Paciente">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={stats.ageDistribution}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip cursor={{ fill: '#f1f5f9' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Bar dataKey="value" fill="#8884d8" radius={[4, 4, 0, 0]}>
                    {stats.ageDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </ChartBox>

            {/* Appointment Status */}
            <ChartBox title="Estado de Turnos">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={stats.appointmentsByStatus}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {stats.appointmentsByStatus.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36} />
                </PieChart>
              </ResponsiveContainer>
            </ChartBox>

            {/* Top Diagnoses */}
            <ChartBox title="Diagnósticos Más Frecuentes">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart layout="vertical" data={stats.topDiagnoses} margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" fontSize={12} />
                  <YAxis dataKey="name" type="category" width={100} fontSize={11} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#FF8042" radius={[0, 4, 4, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </ChartBox>

            {/* Top Medications */}
            <ChartBox title="Medicamentos Más Recetados">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart layout="vertical" data={stats.topMedications} margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" fontSize={12} />
                  <YAxis dataKey="name" type="category" width={100} fontSize={11} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#00C49F" radius={[0, 4, 4, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </ChartBox>

          </div>
        </>
      )}

      {/* Print CSS */}
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white; }
          .recharts-wrapper { margin: 0 auto; }
        }
      `}</style>
    </div>
  );
};

const StatsCard = ({ title, value, icon, color }) => (
  <div className={`p-6 rounded-2xl border ${color} flex flex-col justify-between`}>
    <div className="flex justify-between items-start mb-4">
      <span className="text-slate-500 font-medium text-sm">{title}</span>
      <div className="p-2 bg-white rounded-lg shadow-sm">
        {icon}
      </div>
    </div>
    <span className="text-3xl font-bold text-slate-800">{value}</span>
  </div>
);

const ChartBox = ({ title, children }) => (
  <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 break-inside-avoid">
    <h3 className="text-lg font-semibold text-slate-800 mb-6">{title}</h3>
    {children}
  </div>
);

export default ReportsAnalytics;