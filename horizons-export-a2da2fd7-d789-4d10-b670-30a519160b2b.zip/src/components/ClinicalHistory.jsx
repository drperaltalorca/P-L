
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  Calendar, 
  Stethoscope, 
  Activity, 
  Pill, 
  FileText, 
  Thermometer,
  Heart,
  Scale,
  BookOpen, 
  Brain,
  Search,
  FlaskConical,
  Upload,
  Image as ImageIcon,
  FileBarChart,
  Trash2,
  ExternalLink,
  Eye,
  Microscope,
  FileCheck
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from '@/components/ui/input';
import FormField from '@/components/FormField';
import SelectField from '@/components/SelectField';
import TextAreaField from '@/components/TextAreaField';
import { useToast } from '@/components/ui/use-toast';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';

const ClinicalHistory = ({ patientId }) => {
  const { toast } = useToast();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [patientData, setPatientData] = useState(null);
  const [activeTab, setActiveTab] = useState("timeline");

  // Modal State
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Vademecum Lookup
  const [medSearch, setMedSearch] = useState('');
  const [medSearchResults, setMedSearchResults] = useState([]);
  const [isSearchingMeds, setIsSearchingMeds] = useState(false);

  // File Upload State
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileDescription, setFileDescription] = useState('');

  // Diagnosis specific state
  const [diagnosisTab, setDiagnosisTab] = useState("general");
  const [diagnosisData, setDiagnosisData] = useState({
    general: '',
    cie11_code: '',
    cie11_name: '',
    dsm5_code: '',
    dsm5_name: ''
  });

  // Form State
  const [newVisit, setNewVisit] = useState({
    visit_date: new Date().toISOString().split('T')[0],
    visit_type: 'Rutina',
    clinical_notes: '',
    treatment_plan: '',
    vital_signs: {
      blood_pressure: '',
      heart_rate: '',
      temperature: '',
      weight: ''
    }
  });

  useEffect(() => {
    fetchData();
  }, [patientId]);

  const fetchData = async () => {
    setLoading(true);
    await Promise.all([fetchHistory(), fetchPatientData()]);
    setLoading(false);
  };

  const fetchHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('clinical_history')
        .select('*')
        .eq('patient_id', patientId)
        .order('visit_date', { ascending: false });

      if (error) throw error;
      setHistory(data);
    } catch (err) {
      console.error('Error fetching history:', err);
    }
  };

  const fetchPatientData = async () => {
    try {
      const { data, error } = await supabase
        .from('patients')
        .select('*')
        .eq('id', patientId)
        .single();
      
      if (error) throw error;
      setPatientData(data);
    } catch (err) {
      console.error('Error fetching patient data:', err);
    }
  };

  const searchMedications = async (term) => {
    if (term.length < 2) {
      setMedSearchResults([]);
      return;
    }
    setIsSearchingMeds(true);
    const { data } = await supabase
      .from('medications')
      .select('name, presentation')
      .ilike('name', `%${term}%`)
      .limit(5);
    
    setMedSearchResults(data || []);
    setIsSearchingMeds(false);
  };

  const addMedicationToPlan = (med) => {
    const textToAdd = `${med.name} (${med.presentation}) - Indicar dosis y frecuencia.\n`;
    setNewVisit(prev => ({
      ...prev,
      treatment_plan: prev.treatment_plan ? prev.treatment_plan + '\n' + textToAdd : textToAdd
    }));
  };

  const handleCreateVisit = async () => {
    try {
      setIsSubmitting(true);

      const diagnosisParts = [];
      if (diagnosisData.general) diagnosisParts.push(diagnosisData.general);
      if (diagnosisData.cie11_code || diagnosisData.cie11_name) {
        diagnosisParts.push(`[CIE-11] ${diagnosisData.cie11_code ? diagnosisData.cie11_code + ' - ' : ''}${diagnosisData.cie11_name}`);
      }
      if (diagnosisData.dsm5_code || diagnosisData.dsm5_name) {
        diagnosisParts.push(`[DSM-5] ${diagnosisData.dsm5_code ? diagnosisData.dsm5_code + ' - ' : ''}${diagnosisData.dsm5_name}`);
      }
      
      const finalDiagnosis = diagnosisParts.join('\n\n');

      const { error } = await supabase.from('clinical_history').insert([
        {
          patient_id: patientId,
          ...newVisit,
          diagnosis: finalDiagnosis,
          visit_date: new Date(newVisit.visit_date).toISOString()
        }
      ]);

      if (error) throw error;

      toast({
        title: "Visita Registrada",
        description: "La nueva visita clínica ha sido agregada exitosamente.",
        className: "bg-green-50 border-green-200 text-green-800"
      });
      
      setIsDialogOpen(false);
      fetchHistory();
      
      // Reset form
      setNewVisit({
        visit_date: new Date().toISOString().split('T')[0],
        visit_type: 'Rutina',
        clinical_notes: '',
        treatment_plan: '',
        vital_signs: { blood_pressure: '', heart_rate: '', temperature: '', weight: '' }
      });
      setDiagnosisData({ general: '', cie11_code: '', cie11_name: '', dsm5_code: '', dsm5_name: '' });
      setDiagnosisTab("general");

    } catch (err) {
      console.error('Error creating visit:', err);
      toast({ title: "Error", description: "No se pudo registrar la visita.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateVitals = (field, value) => {
    setNewVisit(prev => ({
      ...prev,
      vital_signs: { ...prev.vital_signs, [field]: value }
    }));
  };

  const getTypeVariant = (type) => {
    switch(type) {
      case 'Urgencia': return 'destructive';
      case 'Especialista': return 'info';
      case 'Seguimiento': return 'warning';
      default: return 'success';
    }
  };

  // --- FILE MANAGEMENT LOGIC ---
  const handleFileUpload = async (category) => {
    if (!selectedFile) {
       toast({ title: "Sin archivo", description: "Seleccione un archivo primero.", variant: "destructive" });
       return;
    }
    
    setUploading(true);
    try {
       const fileExt = selectedFile.name.split('.').pop();
       const fileName = `${category}_${Math.random().toString(36).substring(2)}.${fileExt}`;
       const filePath = `${patientId}/${fileName}`;
       const bucket = category === 'gallery' ? 'patient-photos' : 'patient-documents';

       const { error: uploadError } = await supabase.storage
         .from(bucket)
         .upload(filePath, selectedFile);

       if (uploadError) throw uploadError;

       const { data: urlData } = supabase.storage
         .from(bucket)
         .getPublicUrl(filePath);

       // Update patient extended_data with new file reference
       const currentExtended = patientData.extended_data || {};
       const categoryKey = category === 'lab' ? 'lab_results' : category === 'imaging' ? 'imaging_studies' : category === 'gallery' ? 'gallery' : 'documents';
       
       const currentFiles = currentExtended[categoryKey] || [];
       const newFileEntry = {
          url: urlData.publicUrl,
          description: fileDescription || selectedFile.name,
          date: new Date().toISOString(),
          type: selectedFile.type
       };

       const { error: updateError } = await supabase
         .from('patients')
         .update({
            extended_data: {
               ...currentExtended,
               [categoryKey]: [newFileEntry, ...currentFiles]
            }
         })
         .eq('id', patientId);

       if (updateError) throw updateError;

       toast({ title: "Archivo Subido", description: "El documento se guardó correctamente.", className: "bg-green-50 text-green-800" });
       fetchPatientData();
       setSelectedFile(null);
       setFileDescription('');

    } catch (error) {
       console.error("Upload error:", error);
       toast({ title: "Error", description: "Fallo la subida del archivo.", variant: "destructive" });
    } finally {
       setUploading(false);
    }
  };

  const FileUploader = ({ category, label, icon }) => (
    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-6">
       <h4 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
         {icon} Subir {label}
       </h4>
       <div className="flex gap-3 items-end">
          <div className="flex-1 space-y-2">
             <Input 
               type="file" 
               onChange={(e) => setSelectedFile(e.target.files[0])} 
               className="bg-white"
             />
             <Input 
               placeholder="Descripción breve (opcional)..." 
               value={fileDescription}
               onChange={(e) => setFileDescription(e.target.value)}
               className="bg-white"
             />
          </div>
          <Button 
            onClick={() => handleFileUpload(category)} 
            disabled={uploading || !selectedFile}
            className="bg-slate-800 text-white"
          >
             {uploading ? 'Subiendo...' : 'Guardar'}
          </Button>
       </div>
    </div>
  );

  const FileList = ({ files, category }) => {
    if (!files || files.length === 0) return (
      <div className="text-center py-8 text-slate-400 border border-dashed border-slate-200 rounded-xl">
         No hay archivos cargados en esta sección.
      </div>
    );

    return (
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {files.map((file, idx) => (
             <div key={idx} className="group relative bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-md transition-all">
                {category === 'gallery' || (file.type && file.type.startsWith('image/')) ? (
                   <div className="h-40 overflow-hidden bg-slate-100 relative">
                      <img src={file.url} alt={file.description} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                         <a href={file.url} target="_blank" rel="noopener noreferrer" className="p-2 bg-white/20 backdrop-blur rounded-full text-white hover:bg-white/40">
                            <Eye className="w-5 h-5" />
                         </a>
                      </div>
                   </div>
                ) : (
                   <div className="h-40 flex items-center justify-center bg-slate-50 text-slate-400">
                      <FileText className="w-12 h-12" />
                   </div>
                )}
                
                <div className="p-3">
                   <p className="text-sm font-bold text-slate-800 truncate mb-1">{file.description}</p>
                   <p className="text-xs text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(file.date).toLocaleDateString()}
                   </p>
                </div>
                
                <a 
                   href={file.url} 
                   target="_blank" 
                   rel="noopener noreferrer" 
                   className="absolute top-2 right-2 p-1.5 bg-white rounded-lg shadow-sm border border-slate-200 text-slate-500 hover:text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                   <ExternalLink className="w-3.5 h-3.5" />
                </a>
             </div>
          ))}
       </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h3 className="text-2xl font-bold text-slate-800">Historia Clínica Digital</h3>
          <p className="text-slate-500 text-sm">Gestión integral de la información médica del paciente.</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-lg shadow-blue-500/20">
              <Plus className="w-4 h-4 mr-2" />
              Nueva Visita
            </Button>
          </DialogTrigger>
          {/* Create Visit Modal */}
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-white border-2 border-blue-600 rounded-2xl shadow-2xl">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold text-slate-900">Registrar Nueva Visita</DialogTitle>
            </DialogHeader>
            <div className="grid gap-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  label="Fecha de Visita"
                  type="date"
                  value={newVisit.visit_date}
                  onChange={v => setNewVisit({...newVisit, visit_date: v})}
                />
                <SelectField
                  label="Tipo de Visita"
                  value={newVisit.visit_type}
                  onChange={v => setNewVisit({...newVisit, visit_type: v})}
                  options={[
                    { value: 'Rutina', label: 'Consulta de Rutina' },
                    { value: 'Urgencia', label: 'Urgencia' },
                    { value: 'Seguimiento', label: 'Seguimiento' },
                    { value: 'Especialista', label: 'Interconsulta Especialista' }
                  ]}
                />
              </div>

              {/* Diagnosis Tabs Section */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                   Diagnóstico Clínico
                </label>
                <Tabs defaultValue="general" value={diagnosisTab} onValueChange={setDiagnosisTab} className="w-full">
                  <TabsList className="w-full grid grid-cols-3 mb-2 bg-slate-100/80 p-1 rounded-xl">
                    <TabsTrigger value="general" className="text-xs data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg flex items-center justify-center gap-2">
                      <FileText className="w-3.5 h-3.5" /> General
                    </TabsTrigger>
                    <TabsTrigger value="cie11" className="text-xs data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg flex items-center justify-center gap-2">
                      <BookOpen className="w-3.5 h-3.5" /> CIE-11
                    </TabsTrigger>
                    <TabsTrigger value="dsm5" className="text-xs data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg flex items-center justify-center gap-2">
                      <Brain className="w-3.5 h-3.5" /> DSM-V
                    </TabsTrigger>
                  </TabsList>
                  
                  <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                      <TabsContent value="general" className="mt-0">
                           <TextAreaField
                              placeholder="Diagnóstico en texto libre..."
                              value={diagnosisData.general}
                              onChange={v => setDiagnosisData({...diagnosisData, general: v})}
                              rows={3}
                              className="bg-white"
                           />
                      </TabsContent>
                      
                      <TabsContent value="cie11" className="mt-0 space-y-3">
                           <div className="flex gap-3">
                              <div className="w-1/3">
                                  <FormField 
                                    label="Código CIE-11" 
                                    placeholder="Ej. 6A00" 
                                    value={diagnosisData.cie11_code}
                                    onChange={v => setDiagnosisData({...diagnosisData, cie11_code: v})}
                                    className="bg-white"
                                  />
                              </div>
                              <div className="flex-1">
                                  <FormField 
                                    label="Descripción" 
                                    placeholder="Ej. Trastorno del espectro autista" 
                                    value={diagnosisData.cie11_name}
                                    onChange={v => setDiagnosisData({...diagnosisData, cie11_name: v})}
                                    className="bg-white"
                                  />
                              </div>
                           </div>
                           <p className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                             <Search className="w-3 h-3" /> Clasificación Internacional de Enfermedades (11.ª rev.)
                           </p>
                      </TabsContent>
                      
                      <TabsContent value="dsm5" className="mt-0 space-y-3">
                           <div className="flex gap-3">
                              <div className="w-1/3">
                                  <FormField 
                                    label="Código DSM-5" 
                                    placeholder="Ej. 296.33" 
                                    value={diagnosisData.dsm5_code}
                                    onChange={v => setDiagnosisData({...diagnosisData, dsm5_code: v})}
                                    className="bg-white"
                                  />
                              </div>
                              <div className="flex-1">
                                  <FormField 
                                    label="Descripción" 
                                    placeholder="Ej. Trastorno depresivo mayor" 
                                    value={diagnosisData.dsm5_name}
                                    onChange={v => setDiagnosisData({...diagnosisData, dsm5_name: v})}
                                    className="bg-white"
                                  />
                              </div>
                           </div>
                           <p className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                             <Brain className="w-3 h-3" /> Manual Diagnóstico y Estadístico de Trastornos Mentales (5ª ed.)
                           </p>
                      </TabsContent>
                  </div>
                </Tabs>
              </div>

              <div className="space-y-4 border-t border-slate-100 pt-4">
                <h4 className="text-sm font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Signos Vitales
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <FormField
                    label="P. Arterial"
                    placeholder="120/80"
                    value={newVisit.vital_signs.blood_pressure}
                    onChange={v => updateVitals('blood_pressure', v)}
                    className="text-xs"
                  />
                  <FormField
                    label="F. Cardíaca"
                    placeholder="80 bpm"
                    value={newVisit.vital_signs.heart_rate}
                    onChange={v => updateVitals('heart_rate', v)}
                  />
                  <FormField
                    label="Temp. (°C)"
                    placeholder="36.5"
                    value={newVisit.vital_signs.temperature}
                    onChange={v => updateVitals('temperature', v)}
                  />
                  <FormField
                    label="Peso (kg)"
                    placeholder="70.5"
                    value={newVisit.vital_signs.weight}
                    onChange={v => updateVitals('weight', v)}
                  />
                </div>
              </div>

              <div className="space-y-4 border-t border-slate-100 pt-4">
                <TextAreaField
                  label="Notas Clínicas / Evolución"
                  placeholder="Observaciones detalladas, evolución del paciente..."
                  value={newVisit.clinical_notes}
                  onChange={v => setNewVisit({...newVisit, clinical_notes: v})}
                  rows={4}
                />
                
                <div className="relative">
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-sm font-medium text-slate-700">Plan de Tratamiento</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-6 text-xs text-blue-600 hover:text-blue-700 px-2">
                           <Search className="w-3 h-3 mr-1" /> Vademécum
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-80 p-3 bg-white border border-slate-200 shadow-xl" align="end">
                         <div className="space-y-3">
                           <h4 className="font-semibold text-sm text-slate-800">Buscar en Vademécum OSPSA</h4>
                           <input 
                             className="w-full text-sm p-2 border border-slate-200 rounded-md bg-slate-50"
                             placeholder="Escribe para buscar..."
                             onChange={(e) => searchMedications(e.target.value)}
                           />
                           <div className="max-h-40 overflow-y-auto space-y-1">
                             {medSearchResults.length > 0 ? (
                               medSearchResults.map((med, i) => (
                                 <button
                                  key={i}
                                  onClick={() => addMedicationToPlan(med)}
                                  className="w-full text-left text-xs p-2 hover:bg-blue-50 rounded flex items-center justify-between group"
                                 >
                                   <span>{med.name}</span>
                                   <Plus className="w-3 h-3 text-blue-500 opacity-0 group-hover:opacity-100" />
                                 </button>
                               ))
                             ) : (
                               <p className="text-xs text-slate-400 text-center py-2">Sin resultados</p>
                             )}
                           </div>
                         </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <TextAreaField
                    placeholder="Medicamentos recetados, estudios solicitados, indicaciones..."
                    value={newVisit.treatment_plan}
                    onChange={v => setNewVisit({...newVisit, treatment_plan: v})}
                    className="mt-0"
                  />
                </div>
              </div>
            </div>
            <DialogFooter className="border-t border-slate-100 pt-4">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
              <Button onClick={handleCreateVisit} disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700 text-white">
                {isSubmitting ? 'Guardando...' : 'Guardar Visita'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="timeline" value={activeTab} onValueChange={setActiveTab} className="w-full">
         <TabsList className="w-full grid grid-cols-5 p-1 bg-slate-100/50 rounded-xl mb-6">
            <TabsTrigger value="timeline" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
               <Activity className="w-4 h-4 mr-2" /> Evolución
            </TabsTrigger>
            <TabsTrigger value="labs" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
               <FlaskConical className="w-4 h-4 mr-2" /> Laboratorios
            </TabsTrigger>
            <TabsTrigger value="imaging" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
               <FileBarChart className="w-4 h-4 mr-2" /> Imágenes/ECG
            </TabsTrigger>
            <TabsTrigger value="reports" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
               <FileCheck className="w-4 h-4 mr-2" /> Informes
            </TabsTrigger>
            <TabsTrigger value="gallery" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
               <ImageIcon className="w-4 h-4 mr-2" /> Galería
            </TabsTrigger>
         </TabsList>

         <div className="min-h-[400px]">
            {/* TIMELINE TAB */}
            <TabsContent value="timeline">
               {loading ? (
                 <div className="space-y-4">
                   {[1,2,3].map(i => (
                     <div key={i} className="h-40 bg-white rounded-2xl animate-pulse shadow-sm border border-slate-100" />
                   ))}
                 </div>
               ) : (
                 <div className="relative pl-8 border-l-2 border-slate-100 space-y-8">
                   {history.length === 0 ? (
                     <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200 ml-[-20px]">
                       <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                         <FileText className="w-8 h-8" />
                       </div>
                       <h3 className="text-slate-600 font-medium">No hay historial registrado</h3>
                       <p className="text-slate-400 text-sm mt-1">Comenzá registrando la primera visita de este paciente.</p>
                     </div>
                   ) : (
                     history.map((visit, idx) => (
                       <motion.div 
                         key={visit.id}
                         initial={{ opacity: 0, x: -20 }}
                         animate={{ opacity: 1, x: 0 }}
                         transition={{ delay: idx * 0.1 }}
                         className="relative bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow group"
                       >
                         {/* Timeline dot */}
                         <div className="absolute -left-[41px] top-6 w-5 h-5 rounded-full bg-white border-4 border-blue-500 shadow-sm z-10 group-hover:scale-110 transition-transform" />

                         <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4 border-b border-slate-50 pb-4">
                           <div>
                             <div className="flex items-center gap-3 mb-1">
                               <h4 className="text-lg font-bold text-slate-800">
                                 {new Date(visit.visit_date).toLocaleDateString('es-AR', { year: 'numeric', month: 'long', day: 'numeric' })}
                               </h4>
                               <Badge variant={getTypeVariant(visit.visit_type)}>
                                 {visit.visit_type}
                               </Badge>
                             </div>
                             {/* Diagnosis Display */}
                             <div className="mt-2 text-sm text-slate-600 font-medium bg-slate-50 p-2.5 rounded-lg border border-slate-100 whitespace-pre-line">
                               <span className="text-xs uppercase text-slate-400 font-bold block mb-1">Diagnóstico:</span>
                               {visit.diagnosis || 'Sin diagnóstico especificado'}
                             </div>
                           </div>
                           {/* Vitals Summary */}
                           {visit.vital_signs && (
                             <div className="flex flex-wrap gap-3 text-xs text-slate-500 bg-slate-50 px-3 py-2 rounded-lg h-fit">
                               {visit.vital_signs.blood_pressure && (
                                 <div className="flex items-center gap-1" title="Presión Arterial">
                                   <Activity className="w-3 h-3 text-rose-400" />
                                   {visit.vital_signs.blood_pressure}
                                 </div>
                               )}
                               {visit.vital_signs.heart_rate && (
                                 <div className="flex items-center gap-1" title="Frecuencia Cardíaca">
                                   <Heart className="w-3 h-3 text-rose-400" />
                                   {visit.vital_signs.heart_rate}
                                 </div>
                               )}
                               {visit.vital_signs.temperature && (
                                 <div className="flex items-center gap-1" title="Temperatura">
                                   <Thermometer className="w-3 h-3 text-orange-400" />
                                   {visit.vital_signs.temperature}°
                                 </div>
                               )}
                               {visit.vital_signs.weight && (
                                 <div className="flex items-center gap-1" title="Peso">
                                   <Scale className="w-3 h-3 text-blue-400" />
                                   {visit.vital_signs.weight}kg
                                 </div>
                               )}
                             </div>
                           )}
                         </div>

                         <div className="grid md:grid-cols-2 gap-6 text-sm">
                           <div className="space-y-1">
                             <span className="font-semibold text-slate-400 text-xs uppercase tracking-wider flex items-center gap-1">
                               <Stethoscope className="w-3 h-3" /> Notas Clínicas / Evolución
                             </span>
                             <p className="text-slate-700 leading-relaxed whitespace-pre-line bg-slate-50/50 p-3 rounded-lg border border-slate-100">
                               {visit.clinical_notes || "Sin notas registradas."}
                             </p>
                           </div>
                           
                           <div className="space-y-1">
                             <span className="font-semibold text-slate-400 text-xs uppercase tracking-wider flex items-center gap-1">
                               <Pill className="w-3 h-3" /> Plan de Tratamiento
                             </span>
                             <div className="p-3 bg-blue-50/50 rounded-lg border border-blue-100 text-blue-900 leading-relaxed whitespace-pre-line">
                               {visit.treatment_plan || "No se ha definido un plan de tratamiento."}
                             </div>
                           </div>
                         </div>
                       </motion.div>
                     ))
                   )}
                 </div>
               )}
            </TabsContent>

            {/* LABORATORIES TAB */}
            <TabsContent value="labs">
               <FileUploader 
                 category="lab" 
                 label="Resultados de Laboratorio" 
                 icon={<FlaskConical className="w-4 h-4 text-purple-600" />} 
               />
               <FileList files={patientData?.extended_data?.lab_results} category="lab" />
            </TabsContent>

            {/* IMAGING/ECG TAB */}
            <TabsContent value="imaging">
               <FileUploader 
                 category="imaging" 
                 label="Imágenes / Electrogramas" 
                 icon={<Activity className="w-4 h-4 text-rose-600" />} 
               />
               <FileList files={patientData?.extended_data?.imaging_studies} category="imaging" />
            </TabsContent>

            {/* REPORTS TAB */}
            <TabsContent value="reports">
               <FileUploader 
                 category="document" 
                 label="Informes Médicos" 
                 icon={<FileCheck className="w-4 h-4 text-blue-600" />} 
               />
               <FileList files={patientData?.extended_data?.documents} category="document" />
            </TabsContent>

            {/* GALLERY TAB */}
            <TabsContent value="gallery">
               <FileUploader 
                 category="gallery" 
                 label="Foto a la Galería" 
                 icon={<ImageIcon className="w-4 h-4 text-orange-600" />} 
               />
               <FileList files={patientData?.extended_data?.gallery} category="gallery" />
            </TabsContent>
         </div>
      </Tabs>
    </div>
  );
};

export default ClinicalHistory;
