
import React, { useState, useEffect, useRef } from 'react';
import { Save, FileText, X, AlertCircle, CheckCircle2, Search, Loader2, Pill } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import FormField from '@/components/FormField';
import TextAreaField from '@/components/TextAreaField';

const PrescriptionForm = ({ patientId, onSuccess, onCancel, className }) => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Search State
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const searchTimeoutRef = useRef(null);
  const wrapperRef = useRef(null);

  const [formData, setFormData] = useState({
    medication_name: '',
    active_ingredients: '',
    dosage: '',
    frequency: '',
    duration: '',
    instructions: '',
    laboratory: '',
    medical_provider: '',
    medical_provider_number: ''
  });

  // Fetch patient data to autofill medical provider info if available
  useEffect(() => {
    const fetchPatientData = async () => {
      if (!patientId) return;
      try {
        const { data, error } = await supabase
          .from('patients')
          .select('extended_data')
          .eq('id', patientId)
          .single();
          
        if (data && data.extended_data) {
          // Here we map "healthInsurance" from patient data to "medical_provider" in prescription
          // and "affiliateNumber" to "medical_provider_number"
          setFormData(prev => ({
            ...prev,
            medical_provider: data.extended_data.healthInsurance || data.extended_data.medicalProvider || '', 
            medical_provider_number: data.extended_data.affiliateNumber || ''
          }));
        }
      } catch (err) {
        console.error("Error fetching patient insurance data:", err);
      }
    };
    
    fetchPatientData();
  }, [patientId]);

  // Handle click outside to close suggestions
  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [wrapperRef]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleMedicationSearch = (value) => {
    handleChange('medication_name', value);
    
    // Clear previous timeout
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    if (value.length < 2) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    setIsSearching(true);
    setShowSuggestions(true);

    // Debounce search
    searchTimeoutRef.current = setTimeout(async () => {
      try {
        const { data, error } = await supabase
          .from('medications')
          .select('*')
          .ilike('name', `%${value}%`)
          .limit(5);
        
        if (error) throw error;
        setSuggestions(data || []);
      } catch (err) {
        console.error("Error searching medications:", err);
      } finally {
        setIsSearching(false);
      }
    }, 300);
  };

  const selectMedication = (med) => {
    setFormData(prev => ({
      ...prev,
      medication_name: med.name,
      active_ingredients: med.active_ingredients || '',
      laboratory: med.laboratory || '',
      dosage: med.presentation || '', // Auto-fill dosage/presentation if available
    }));
    setShowSuggestions(false);
  };

  const handleSubmit = async () => {
    // Basic validation
    if (!formData.medication_name || !formData.frequency || !formData.duration) {
      toast({
        title: "Campos incompletos",
        description: "Por favor completá al menos el nombre del medicamento, frecuencia y duración.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('prescriptions')
        .insert([{
          patient_id: patientId,
          medication_name: formData.medication_name,
          active_ingredients: formData.active_ingredients,
          dosage: formData.dosage,
          frequency: formData.frequency,
          duration: formData.duration,
          instructions: formData.instructions,
          laboratory: formData.laboratory,
          medical_provider: formData.medical_provider,
          medical_provider_number: formData.medical_provider_number,
          status: 'active',
          prescribed_date: new Date().toISOString()
        }]);

      if (error) throw error;

      toast({
        title: "Receta Generada",
        description: `Se ha creado la receta de ${formData.medication_name} correctamente.`,
        className: "bg-green-50 border-green-200 text-green-800"
      });

      // Reset form (keeping insurance info might be useful, but reseting medication fields)
      setFormData(prev => ({
        ...prev,
        medication_name: '',
        active_ingredients: '',
        dosage: '',
        frequency: '',
        duration: '',
        instructions: '',
        laboratory: ''
      }));

      if (onSuccess) onSuccess();

    } catch (error) {
      console.error('Error saving prescription:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar la receta.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={`bg-white rounded-xl p-6 shadow-sm border border-slate-100 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          Nueva Prescripción
        </h3>
        {onCancel && (
          <Button variant="ghost" size="sm" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>

      <div className="space-y-4">
        {/* Insurance Information Section */}
        <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 mb-2">
           <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Datos de Cobertura</h4>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <FormField
                label="Obra Social / Prepaga"
                placeholder="Ej. OSDE, Swiss Medical"
                value={formData.medical_provider}
                onChange={(v) => handleChange('medical_provider', v)}
             />
             <FormField
                label="N° de Afiliado"
                placeholder="Ej. 123456789"
                value={formData.medical_provider_number}
                onChange={(v) => handleChange('medical_provider_number', v)}
             />
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Medication Search Field */}
          <div className="relative" ref={wrapperRef}>
            <div className="relative">
              <FormField
                label="Nombre Comercial del Medicamento *"
                placeholder="Escribe para buscar..."
                value={formData.medication_name}
                onChange={handleMedicationSearch}
                onFocus={() => formData.medication_name.length >= 2 && setShowSuggestions(true)}
                autoComplete="off"
              />
              {isSearching && (
                <div className="absolute right-3 top-[34px]">
                  <Loader2 className="w-4 h-4 text-slate-400 animate-spin" />
                </div>
              )}
            </div>

            {/* Suggestions Dropdown */}
            {showSuggestions && (
              <div className="absolute z-50 w-full mt-1 bg-white rounded-lg shadow-xl border border-slate-200 max-h-60 overflow-y-auto">
                {suggestions.length > 0 ? (
                  <ul className="py-1">
                    {suggestions.map((med) => (
                      <li 
                        key={med.id}
                        onClick={() => selectMedication(med)}
                        className="px-4 py-2 hover:bg-blue-50 cursor-pointer flex flex-col border-b border-slate-50 last:border-0 transition-colors"
                      >
                        <span className="font-semibold text-slate-800 flex items-center justify-between">
                          {med.name}
                          <span className="text-[10px] text-slate-400 font-normal uppercase">{med.laboratory}</span>
                        </span>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                           <Pill className="w-3 h-3 text-blue-400" />
                           <span>{med.presentation}</span>
                           <span className="text-slate-300">|</span>
                           <span className="italic truncate">{med.active_ingredients}</span>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  !isSearching && (
                    <div className="p-3 text-sm text-slate-500 text-center italic">
                      No se encontraron resultados en el vademécum.
                    </div>
                  )
                )}
              </div>
            )}
          </div>

          <FormField
            label="Droga / Principio Activo"
            placeholder="Ej. Ibuprofeno"
            value={formData.active_ingredients}
            onChange={(v) => handleChange('active_ingredients', v)}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FormField
            label="Dosis / Potencia"
            placeholder="Ej. 600mg"
            value={formData.dosage}
            onChange={(v) => handleChange('dosage', v)}
          />
          <FormField
            label="Frecuencia *"
            placeholder="Ej. Cada 8 horas"
            value={formData.frequency}
            onChange={(v) => handleChange('frequency', v)}
          />
          <FormField
            label="Duración *"
            placeholder="Ej. 5 días"
            value={formData.duration}
            onChange={(v) => handleChange('duration', v)}
          />
        </div>

        <FormField
           label="Laboratorio (Opcional)"
           placeholder="Ej. Bayer"
           value={formData.laboratory}
           onChange={(v) => handleChange('laboratory', v)}
        />

        <TextAreaField
          label="Indicaciones Adicionales"
          placeholder="Instrucciones detalladas para el paciente (ej. tomar con las comidas)..."
          value={formData.instructions}
          onChange={(v) => handleChange('instructions', v)}
          rows={3}
        />

        <div className="pt-4 flex justify-end gap-3">
          {onCancel && (
            <Button variant="outline" onClick={onCancel} disabled={isSubmitting}>
              Cancelar
            </Button>
          )}
          <Button 
            onClick={handleSubmit} 
            disabled={isSubmitting}
            className="bg-blue-600 hover:bg-blue-700 text-white min-w-[150px]"
          >
            {isSubmitting ? (
              'Guardando...'
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" /> Guardar Receta
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PrescriptionForm;
