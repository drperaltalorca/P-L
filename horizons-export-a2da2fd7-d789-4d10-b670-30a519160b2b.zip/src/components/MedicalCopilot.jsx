
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, Send, X, Bot, User, Sparkles, Loader2, 
  Minimize2, Stethoscope, Pill, FileHeart 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

// --- Mock AI Logic (Simulation) ---
// In a real production app, this would call an API like OpenAI
const simulateAIResponse = async (query) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const q = query.toLowerCase();
      
      if (q.includes('hola') || q.includes('buenos')) {
        resolve("¡Hola, Doctor! Soy su asistente clínico virtual. ¿En qué puedo ayudarle hoy? Puedo asistirle con dosis, interacciones medicamentosas o protocolos de tratamiento.");
      } else if (q.includes('dosis') || q.includes('posologia')) {
        resolve("Para consultas de dosificación, por favor especifique el medicamento y la edad/peso del paciente. Recuerde que puede consultar el Vademécum integrado en la pestaña 'Registro' para ver las presentaciones disponibles.");
      } else if (q.includes('dolor') || q.includes('ibuprofeno') || q.includes('paracetamol')) {
        resolve("Protocolo de manejo del dolor sugerido (OMS): \n1. Paracetamol 500mg - 1g cada 6-8hs.\n2. Si persiste, considerar AINEs (Ibuprofeno 400mg).\n3. Opioides débiles para dolor moderado-severo.\n\n¿Desea que busque interacciones específicas?");
      } else if (q.includes('paciente') || q.includes('historia')) {
        resolve("Para ver la historia clínica de un paciente, puede usar la barra de búsqueda superior o ir a la sección 'Pacientes'. Si necesita ayuda para interpretar un estudio, puedo intentar analizar los valores de referencia.");
      } else if (q.includes('zonda') || q.includes('clima')) {
        resolve("He detectado una alerta de Zonda en el dashboard. Se recomienda aconsejar a los pacientes asmáticos o hipertensos que eviten la exposición al aire libre y mantengan la hidratación.");
      } else {
        resolve("Entendido. Estoy procesando su consulta sobre '" + query + "'. Como soy una versión demo, mi conocimiento médico clínico es limitado en este momento, pero estoy diseñado para conectarme con bases de datos como PubMed o guías clínicas actualizadas.");
      }
    }, 1500); // Simulate "thinking" time
  });
};

const MedicalCopilot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState([
    { 
      id: 'welcome', 
      role: 'bot', 
      text: 'Bienvenido, Dr. Peralta. Soy su copiloto médico con IA. ¿En qué puedo asistirle hoy?',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userMsg = {
      id: Date.now(),
      role: 'user',
      text: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    try {
      const responseText = await simulateAIResponse(userMsg.text);
      
      const botMsg = {
        id: Date.now() + 1,
        role: 'bot',
        text: responseText,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      console.error("AI Error", error);
    } finally {
      setIsTyping(false);
    }
  };

  const suggestions = [
    { icon: Pill, label: "Dosis Pediátrica" },
    { icon: FileHeart, label: "Protocolo HTA" },
    { icon: Stethoscope, label: "Interacciones" },
  ];

  const handleSuggestionClick = (label) => {
    setInputValue(`Consultar sobre ${label}...`);
  };

  return (
    <>
      {/* --- Floating Action Button (FAB) --- */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, rotate: 180 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: -180 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full bg-blue-600 text-white shadow-xl shadow-blue-600/30 flex items-center justify-center group overflow-hidden border-2 border-white/20"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-600 to-indigo-500" />
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
            
            <Plus className="w-8 h-8 relative z-10 group-hover:rotate-90 transition-transform duration-300" />
            
            {/* Ping animation to draw attention */}
            <span className="absolute top-0 right-0 -mt-1 -mr-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-sky-500 border-2 border-white"></span>
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* --- Chat Interface Window --- */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? 'auto' : '600px',
              width: isMinimized ? '320px' : '384px' // w-96 is 384px
            }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed bottom-6 right-6 z-50 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 flex items-center justify-between shrink-0 relative">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none" />
              
              <div className="flex items-center gap-3 relative z-10">
                <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Copiloto Médico IA</h3>
                  <p className="text-blue-100 text-[10px] flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                    En línea
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1 relative z-10">
                <button 
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="p-1.5 text-blue-100 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <Minimize2 className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 text-blue-100 hover:bg-white/10 rounded-lg transition-colors hover:text-red-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Chat Body - Hidden if minimized */}
            {!isMinimized && (
              <>
                <div className="flex-1 bg-slate-50 p-4 overflow-y-auto min-h-0 flex flex-col gap-4">
                  {messages.map((msg) => (
                    <motion.div 
                      key={msg.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={cn(
                        "flex gap-3 max-w-[90%]",
                        msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
                      )}
                    >
                      {/* Avatar */}
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm border",
                        msg.role === 'user' 
                          ? "bg-indigo-100 border-indigo-200 text-indigo-700" 
                          : "bg-blue-600 border-blue-700 text-white"
                      )}>
                        {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                      </div>

                      {/* Bubble */}
                      <div className={cn(
                        "p-3 rounded-2xl text-sm shadow-sm",
                        msg.role === 'user'
                          ? "bg-white text-slate-700 rounded-tr-none border border-slate-100"
                          : "bg-blue-600 text-white rounded-tl-none"
                      )}>
                        <p className="whitespace-pre-line leading-relaxed">{msg.text}</p>
                        <span className={cn(
                          "text-[10px] mt-1 block opacity-70",
                          msg.role === 'user' ? "text-right" : "text-left"
                        )}>
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                  
                  {isTyping && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex gap-3 mr-auto"
                    >
                       <div className="w-8 h-8 rounded-full bg-blue-600 border border-blue-700 text-white flex items-center justify-center shrink-0">
                         <Bot className="w-4 h-4" />
                       </div>
                       <div className="bg-white border border-slate-200 px-4 py-3 rounded-2xl rounded-tl-none shadow-sm flex gap-1 items-center">
                         <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                         <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                         <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                       </div>
                    </motion.div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Suggestions (Horizontal Scroll) */}
                <div className="bg-slate-50 px-4 py-2 border-t border-slate-200 flex gap-2 overflow-x-auto scrollbar-hide">
                  {suggestions.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => handleSuggestionClick(s.label)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-full text-xs font-medium text-slate-600 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition-colors whitespace-nowrap shadow-sm"
                    >
                      <s.icon className="w-3 h-3" />
                      {s.label}
                    </button>
                  ))}
                </div>

                {/* Input Area */}
                <form 
                  onSubmit={handleSendMessage}
                  className="p-3 bg-white border-t border-slate-200 shrink-0"
                >
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      placeholder="Escriba su consulta médica..."
                      className="w-full pl-4 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none text-sm transition-all"
                    />
                    <Button 
                      size="icon" 
                      type="submit"
                      disabled={!inputValue.trim() || isTyping}
                      className="absolute right-1.5 w-9 h-9 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm"
                    >
                      {isTyping ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    </Button>
                  </div>
                  <div className="text-[10px] text-center text-slate-400 mt-2 flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>IA de asistencia clínica. Verificar resultados críticos.</span>
                  </div>
                </form>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

// Helper for the disclaimer icon since it wasn't imported in the list initially but used in JSX
const ShieldCheck = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    <path d="m9 12 2 2 4-4"/>
  </svg>
);

export default MedicalCopilot;
