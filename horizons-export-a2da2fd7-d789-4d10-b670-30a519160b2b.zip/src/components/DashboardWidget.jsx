
import React from 'react';
import { Reorder, useDragControls } from 'framer-motion';
import { GripHorizontal, Maximize2, Palette, Trash2, Check, Loader2, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { motion } from 'framer-motion';

// Pastel palette for the "Plastic" body effect
const THEMES = [
  { name: 'Azul Médico', header: '#2563eb', body: 'rgba(239, 246, 255, 0.6)', text: '#1e3a8a', id: 'blue' }, 
  { name: 'Verde Clínico', header: '#059669', body: 'rgba(236, 253, 245, 0.6)', text: '#064e3b', id: 'emerald' }, 
  { name: 'Alerta', header: '#e11d48', body: 'rgba(255, 241, 242, 0.6)', text: '#881337', id: 'rose' }, 
  { name: 'Neutro', header: '#475569', body: 'rgba(248, 250, 252, 0.6)', text: '#334155', id: 'slate' }, 
  { name: 'Violeta', header: '#7c3aed', body: 'rgba(245, 243, 255, 0.6)', text: '#4c1d95', id: 'violet' }, 
  { name: 'Naranja', header: '#ea580c', body: 'rgba(255, 247, 237, 0.6)', text: '#7c2d12', id: 'orange' },
];

const SIZES = [
  { label: 'Pequeño', value: 'col-span-1' },
  { label: 'Mediano', value: 'col-span-2' },
  { label: 'Grande', value: 'col-span-3' },
];

export const DashboardWidget = ({ 
  widget, 
  title,
  icon: Icon,
  value,
  trend,
  color, // 'blue', 'emerald', etc. from simple usage
  loading,
  onUpdate, 
  onRemove, 
  isEditMode, 
  children 
}) => {
  const dragControls = useDragControls();

  // 1. Resolve Configuration (Handle both complex 'widget' prop and simple 'color' prop)
  let config = {
    headerColor: THEMES[0].header,
    bodyColor: THEMES[0].body,
    textColor: THEMES[0].text,
    width: 'col-span-1',
    id: 'default'
  };

  if (widget) {
    // Advanced Mode: Use widget object
    const theme = THEMES.find(t => t.header === widget.headerColor) || THEMES[0];
    config = {
      ...widget,
      headerColor: theme.header,
      bodyColor: theme.body,
      textColor: theme.text,
    };
  } else if (color) {
    // Simple Mode: Map color string to theme
    const theme = THEMES.find(t => t.id === color) || THEMES.find(t => t.id === 'blue');
    config = {
      headerColor: theme.header,
      bodyColor: theme.body,
      textColor: theme.text,
      width: 'col-span-1',
      id: `simple-${title}`
    };
  }

  const handleThemeChange = (theme) => {
    if (onUpdate && widget) {
      onUpdate(widget.id, { 
        ...widget, 
        headerColor: theme.header 
      });
    }
  };

  const cycleSize = () => {
    if (onUpdate && widget) {
      const currentIndex = SIZES.findIndex(s => s.value === widget.width);
      const nextIndex = (currentIndex + 1) % SIZES.length;
      onUpdate(widget.id, { ...widget, width: SIZES[nextIndex].value });
    }
  };

  // 2. Decide Wrapper (Reorder.Item for drag mode, or motion.div for simple mode)
  const Wrapper = widget ? Reorder.Item : motion.div;
  
  const wrapperProps = widget ? {
    value: widget,
    id: widget.id,
    dragListener: isEditMode,
    dragControls: dragControls,
    style: { backgroundColor: config.bodyColor, backdropFilter: 'blur(8px)' }
  } : {
    style: { backgroundColor: config.bodyColor, backdropFilter: 'blur(8px)' }
  };

  return (
    <Wrapper
      {...wrapperProps}
      className={cn(
        "group relative rounded-2xl overflow-hidden transition-all duration-300 flex flex-col shadow-sm hover:shadow-md border border-slate-200/60 min-h-[140px]",
        config.width || 'col-span-1',
        isEditMode ? 'scale-[0.99] ring-2 ring-offset-2 ring-blue-400 cursor-move' : ''
      )}
    >
      {/* Widget Header */}
      <div 
        className="px-4 py-2.5 flex items-center justify-between select-none relative z-20"
        style={{ backgroundColor: config.headerColor }}
        onPointerDown={(e) => isEditMode && dragControls.start(e)}
      >
        <div className="flex items-center gap-2 text-white">
          {Icon && <Icon className="w-4 h-4 opacity-90" />}
          <span className="text-xs font-bold uppercase tracking-wider">{title || 'Widget'}</span>
        </div>

        {/* Controls */}
        <div className={cn(
          "flex items-center gap-1 transition-opacity duration-200",
          isEditMode ? "opacity-100" : "opacity-0 group-hover:opacity-100"
        )}>
          {isEditMode && <GripHorizontal className="w-4 h-4 text-white/50 mr-2" />}
          
          {/* Only show interactive controls if in 'widget' mode */}
          {widget && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-white hover:bg-white/20 rounded-full"
                onClick={cycleSize}
                title="Cambiar tamaño"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </Button>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-white hover:bg-white/20 rounded-full">
                    <Palette className="w-3.5 h-3.5" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-40 p-2" align="end">
                  <div className="grid grid-cols-3 gap-2">
                    {THEMES.map((t) => (
                      <button
                        key={t.name}
                        onClick={() => handleThemeChange(t)}
                        className="w-full aspect-square rounded-full border border-slate-100 shadow-sm flex items-center justify-center hover:scale-110 transition-transform"
                        style={{ backgroundColor: t.header }}
                        title={t.name}
                      >
                         {/* Checkmark logic is simplified here */}
                         <div className="w-2 h-2 rounded-full bg-white/50" />
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>

              {onRemove && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-white hover:bg-red-500/50 rounded-full"
                  onClick={() => onRemove(widget.id)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Widget Body Content */}
      <div className="flex-1 p-4 relative overflow-hidden flex flex-col justify-center" style={{ color: config.textColor }}>
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-6 h-6 animate-spin opacity-50" />
          </div>
        ) : children ? (
          children
        ) : (
          // Default "Stat Card" View
          <div className="space-y-1">
             <div className="text-3xl font-bold tracking-tight">
               {value !== undefined ? value : '-'}
             </div>
             {trend && (
               <div className="flex items-center gap-1.5 text-xs font-medium opacity-80">
                  {trend.includes('+') ? (
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  ) : trend.includes('-') ? (
                    <ArrowDownRight className="w-3.5 h-3.5" />
                  ) : (
                    <Minus className="w-3.5 h-3.5" />
                  )}
                  {trend}
               </div>
             )}
          </div>
        )}
      </div>
    </Wrapper>
  );
};

export default DashboardWidget;
