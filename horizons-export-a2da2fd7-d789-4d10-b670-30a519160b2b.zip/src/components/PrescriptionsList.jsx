import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Pill, Clock, Calendar, FileText, Eye } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import PrescriptionDocument from './PrescriptionDocument';

const PrescriptionsList = ({ patientId, patient }) => {
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPrescription, setSelectedPrescription] = useState(null);
  const [isDocumentOpen, setIsDocumentOpen] = useState(false);

  useEffect(() => {
    if (patientId) {
      fetchPrescriptions();
    }
  }, [patientId]);

  const fetchPrescriptions = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('prescriptions')
        .select('*')
        .eq('patient_id', patientId)
        .order('prescribed_date', { ascending: false });

      if (error) throw error;
      setPrescriptions(data);
    } catch (err) {
      console.error('Error fetching prescriptions:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDocument = (prescription) => {
    setSelectedPrescription(prescription);
    setIsDocumentOpen(true);
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2].map(i => (
          <div key={i} className="h-24 bg-slate-50 rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  if (prescriptions.length === 0) {
    return (
      <div className="text-center py-8 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
        <Pill className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-slate-500 font-medium">No hay recetas registradas</p>
        <p className="text-xs text-slate-400 mt-1">Las recetas generadas aparecerán aquí</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-4">
        {prescriptions.map((prescription, idx) => (
          <motion.div
            key={prescription.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-5 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-slate-800 text-lg group-hover:text-blue-600 transition-colors">
                    {prescription.medication_name}
                  </h3>
                  <Badge variant={prescription.status === 'active' ? 'success' : 'secondary'} className="text-[10px] px-2 h-5">
                    {prescription.status === 'active' ? 'ACTIVA' : 'FINALIZADA'}
                  </Badge>
                </div>
                {prescription.active_ingredients && (
                  <p className="text-sm text-slate-500 italic">
                    {prescription.active_ingredients}
                  </p>
                )}
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="gap-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                onClick={() => handleViewDocument(prescription)}
              >
                <Eye className="w-3 h-3" />
                Ver Receta
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm bg-slate-50/50 p-3 rounded-lg border border-slate-100">
              <div className="flex items-center gap-2 text-slate-600">
                <Clock className="w-4 h-4 text-blue-400" />
                <span className="font-medium">{prescription.frequency}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Calendar className="w-4 h-4 text-purple-400" />
                <span className="font-medium">{prescription.duration}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600 col-span-2 md:col-span-1">
                <FileText className="w-4 h-4 text-slate-400" />
                <span>{new Date(prescription.prescribed_date).toLocaleDateString()}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <PrescriptionDocument
        open={isDocumentOpen}
        onOpenChange={setIsDocumentOpen}
        prescription={selectedPrescription}
        patient={patient}
      />
    </>
  );
};

export default PrescriptionsList;