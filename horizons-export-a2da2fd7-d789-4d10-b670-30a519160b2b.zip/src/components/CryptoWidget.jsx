
import React, { useState, useEffect } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  LineChart, Line, ReferenceLine, CartesianGrid 
} from 'recharts';
import { 
  TrendingUp, TrendingDown, RefreshCw, Loader2, 
  Activity, Sparkles, BrainCircuit
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/customSupabaseClient'; // Ensure you have this client available

const COINS = [
  { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin', color: '#f59e0b' },
  { id: 'ethereum', symbol: 'ETH', name: 'Ethereum', color: '#6366f1' },
  { id: 'solana', symbol: 'SOL', name: 'Solana', color: '#14b8a6' }
];

const INTERVALS = [
  { label: '1H', value: '1h', days: 1, granularity: 'hourly' }, 
  { label: '24H', value: '24h', days: 1, granularity: 'hourly' },
  { label: '7D', value: '7d', days: 7, granularity: 'daily' },
  { label: '30D', value: '30d', days: 30, granularity: 'daily' },
];

const CryptoWidget = () => {
  const [selectedCoin, setSelectedCoin] = useState(COINS[0]);
  const [selectedInterval, setSelectedInterval] = useState(INTERVALS[1]); 
  const [activeIndicator, setActiveIndicator] = useState('none'); // 'none', 'rsi', 'stoch'
  
  const [rawData, setRawData] = useState([]);
  const [currentPrice, setCurrentPrice] = useState(null);
  const [priceChange, setPriceChange] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // AI Analysis State
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // --- Technical Indicators Logic ---

  const calculateRSI = (prices, period = 14) => {
    const results = new Array(prices.length).fill(null);
    let avgGain = 0;
    let avgLoss = 0;

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      const gain = change > 0 ? change : 0;
      const loss = change < 0 ? Math.abs(change) : 0;

      if (i === period) {
        let sumGain = 0;
        let sumLoss = 0;
        for (let j = 1; j <= period; j++) {
          const chg = prices[j] - prices[j-1];
          if (chg > 0) sumGain += chg;
          else sumLoss += Math.abs(chg);
        }
        avgGain = sumGain / period;
        avgLoss = sumLoss / period;
        
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        results[i] = 100 - (100 / (1 + rs));
      } else if (i > period) {
        avgGain = ((avgGain * (period - 1)) + gain) / period;
        avgLoss = ((avgLoss * (period - 1)) + loss) / period;
        
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        results[i] = 100 - (100 / (1 + rs));
      }
    }
    return results;
  };

  const calculateStochastic = (prices, period = 14, smoothK = 3) => {
    const kValues = new Array(prices.length).fill(null);
    const dValues = new Array(prices.length).fill(null);

    for (let i = period - 1; i < prices.length; i++) {
      const windowSlice = prices.slice(i - period + 1, i + 1);
      const lowest = Math.min(...windowSlice);
      const highest = Math.max(...windowSlice);
      const current = prices[i];
      
      if (highest !== lowest) {
        kValues[i] = ((current - lowest) / (highest - lowest)) * 100;
      } else {
        kValues[i] = 50; 
      }
    }

    for (let i = period - 1 + smoothK - 1; i < prices.length; i++) {
      let sum = 0;
      let validCount = 0;
      for (let j = 0; j < smoothK; j++) {
        if (kValues[i - j] !== null) {
          sum += kValues[i - j];
          validCount++;
        }
      }
      if (validCount > 0) dValues[i] = sum / validCount;
    }

    return { k: kValues, d: dValues };
  };

  // --- Data Fetching ---

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    setAiAnalysis(null); // Reset AI analysis on new data fetch
    try {
      const chartRes = await fetch(
        `https://api.coingecko.com/api/v3/coins/${selectedCoin.id}/market_chart?vs_currency=usd&days=${selectedInterval.days}&interval=${selectedInterval.days > 1 ? 'daily' : 'hourly'}`
      );
      
      if (!chartRes.ok) throw new Error('Rate limit or API error');
      
      const chartJson = await chartRes.json();
      const pricesOnly = chartJson.prices.map(p => p[1]);
      
      const rsiData = calculateRSI(pricesOnly);
      const stochData = calculateStochastic(pricesOnly);

      const formattedData = chartJson.prices.map(([timestamp, price], index) => ({
        time: timestamp,
        price: price,
        date: new Date(timestamp).toLocaleDateString(),
        hour: new Date(timestamp).getHours() + ':00',
        rsi: rsiData[index],
        stochK: stochData.k[index],
        stochD: stochData.d[index],
      }));

      setRawData(formattedData);

      if (formattedData.length > 0) {
        const latest = formattedData[formattedData.length - 1].price;
        const first = formattedData[0].price;
        setCurrentPrice(latest);
        const change = ((latest - first) / first) * 100;
        setPriceChange(change);
      }

    } catch (err) {
      console.error("Crypto fetch error:", err);
      setError("Datos no disponibles (API Limit)");
    } finally {
      setLoading(false);
    }
  };

  // --- AI Analysis Handler ---
  const handleAnalyze = async () => {
    if (!rawData.length) return;
    
    setIsAnalyzing(true);
    try {
      const lastPoint = rawData[rawData.length - 1];
      
      const payload = {
        coin: selectedCoin.name,
        price: currentPrice,
        change24h: priceChange.toFixed(2),
        rsi: lastPoint.rsi || 50,
        stochK: lastPoint.stochK || 50,
        stochD: lastPoint.stochD || 50,
        interval: selectedInterval.label
      };

      const { data, error } = await supabase.functions.invoke('analyze-crypto', {
        body: payload
      });

      if (error) throw error;
      setAiAnalysis(data.analysis);

    } catch (err) {
      console.error('AI Analysis failed:', err);
      setAiAnalysis("No se pudo generar el análisis en este momento.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, [selectedCoin, selectedInterval]);

  const formatCurrency = (val) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: val < 10 ? 4 : 2,
      maximumFractionDigits: val < 10 ? 4 : 2
    }).format(val);
  };

  // --- Render ---

  const mainHeight = activeIndicator === 'none' ? "100%" : "65%";
  const indicatorHeight = activeIndicator === 'none' ? "0%" : "35%";

  return (
    <div className="flex flex-col h-full bg-white/50 p-4 relative overflow-hidden">
      {/* Header Controls */}
      <div className="flex flex-col gap-3 mb-2 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex gap-1 bg-slate-100 p-1 rounded-lg">
            {COINS.map(coin => (
              <button
                key={coin.id}
                onClick={() => setSelectedCoin(coin)}
                className={cn(
                  "px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1",
                  selectedCoin.id === coin.id 
                    ? "bg-white text-slate-900 shadow-sm" 
                    : "text-slate-500 hover:text-slate-700"
                )}
              >
                {coin.symbol}
              </button>
            ))}
          </div>
          
          <div className="flex items-center gap-1">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleAnalyze} 
              disabled={isAnalyzing || loading}
              className="h-8 text-xs gap-1.5 bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100"
            >
              {isAnalyzing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <BrainCircuit className="w-3.5 h-3.5" />
              )}
              {isAnalyzing ? "Analizando..." : "AI Insight"}
            </Button>
            <Button variant="ghost" size="icon" onClick={fetchData} className="h-8 w-8 text-slate-400 hover:text-blue-600">
              <RefreshCw className={cn("w-3.5 h-3.5", loading ? "animate-spin" : "")} />
            </Button>
          </div>
        </div>

        {/* AI Analysis Result Overlay/Box */}
        {aiAnalysis && (
          <div className="bg-indigo-50/90 backdrop-blur-sm border border-indigo-100 p-3 rounded-lg animate-in fade-in slide-in-from-top-2 text-xs text-indigo-900 leading-relaxed shadow-sm relative group">
             <div className="flex items-center gap-2 mb-1 font-bold text-indigo-700">
                <Sparkles className="w-3 h-3" />
                <span>Análisis de Gemini AI</span>
             </div>
             <p>{aiAnalysis}</p>
             <button 
               onClick={() => setAiAnalysis(null)} 
               className="absolute top-1 right-2 text-indigo-400 hover:text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity"
             >
               ×
             </button>
          </div>
        )}

        <div className="flex items-end justify-between px-1">
          <div>
            <h3 className="text-2xl font-black text-slate-800 tracking-tight">
              {currentPrice ? formatCurrency(currentPrice) : '---'}
            </h3>
            <div className={cn(
              "flex items-center text-xs font-bold mt-1",
              priceChange >= 0 ? "text-emerald-600" : "text-rose-600"
            )}>
              {priceChange >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
              {Math.abs(priceChange).toFixed(2)}%
            </div>
          </div>
          
          <div className="flex gap-1">
            {INTERVALS.map(int => (
              <button
                key={int.value}
                onClick={() => setSelectedInterval(int)}
                className={cn(
                  "px-2 py-1 rounded text-[10px] font-bold transition-colors uppercase",
                  selectedInterval.value === int.value
                    ? "bg-slate-800 text-white"
                    : "text-slate-400 hover:bg-slate-100"
                )}
              >
                {int.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 border-t border-slate-200/50 pt-2 mt-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mr-1">Indicadores:</span>
            <button
                onClick={() => setActiveIndicator(activeIndicator === 'rsi' ? 'none' : 'rsi')}
                className={cn(
                  "px-2 py-0.5 rounded text-[10px] font-bold transition-colors border",
                  activeIndicator === 'rsi'
                    ? "bg-purple-100 text-purple-700 border-purple-200"
                    : "bg-transparent text-slate-400 border-transparent hover:bg-slate-100"
                )}
            >
                RSI
            </button>
            <button
                onClick={() => setActiveIndicator(activeIndicator === 'stoch' ? 'none' : 'stoch')}
                className={cn(
                  "px-2 py-0.5 rounded text-[10px] font-bold transition-colors border",
                  activeIndicator === 'stoch'
                    ? "bg-blue-100 text-blue-700 border-blue-200"
                    : "bg-transparent text-slate-400 border-transparent hover:bg-slate-100"
                )}
            >
                STOCH
            </button>
        </div>
      </div>

      <div className="flex-1 w-full flex flex-col min-h-[160px] relative">
        {loading && !rawData.length ? (
          <div className="absolute inset-0 flex items-center justify-center bg-white/50 backdrop-blur-sm z-10">
            <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
          </div>
        ) : error ? (
          <div className="absolute inset-0 flex items-center justify-center text-xs text-rose-500 font-medium">
            {error}
          </div>
        ) : (
            <>
                <div style={{ height: mainHeight, transition: 'height 0.3s ease' }}>
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={rawData} syncId="cryptoSync">
                            <defs>
                                <linearGradient id={`gradient-${selectedCoin.id}`} x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={selectedCoin.color} stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor={selectedCoin.color} stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <Tooltip 
                                contentStyle={{ 
                                    backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                                    borderRadius: '8px', 
                                    border: '1px solid #e2e8f0', 
                                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                                    fontSize: '12px'
                                }}
                                formatter={(value) => [formatCurrency(value), 'Precio']}
                                labelFormatter={(label) => {
                                    const date = new Date(label);
                                    return selectedInterval.days > 1 
                                        ? date.toLocaleDateString() 
                                        : date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                                }}
                            />
                            <Area 
                                type="monotone" 
                                dataKey="price" 
                                stroke={selectedCoin.color} 
                                strokeWidth={2}
                                fillOpacity={1} 
                                fill={`url(#gradient-${selectedCoin.id})`} 
                                animationDuration={500}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>

                {activeIndicator !== 'none' && (
                    <div style={{ height: indicatorHeight, transition: 'height 0.3s ease' }} className="pt-2 border-t border-slate-100">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={rawData} syncId="cryptoSync">
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                <XAxis dataKey="time" hide />
                                <YAxis domain={[0, 100]} hide />
                                <Tooltip 
                                    contentStyle={{ 
                                        backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                                        borderRadius: '8px', 
                                        border: '1px solid #e2e8f0',
                                        fontSize: '12px'
                                    }}
                                    labelFormatter={() => ''}
                                />
                                {activeIndicator === 'rsi' && (
                                    <>
                                        <ReferenceLine y={70} stroke="#94a3b8" strokeDasharray="3 3" strokeWidth={1} />
                                        <ReferenceLine y={30} stroke="#94a3b8" strokeDasharray="3 3" strokeWidth={1} />
                                        <Line type="monotone" dataKey="rsi" stroke="#8b5cf6" dot={false} strokeWidth={1.5} name="RSI" />
                                    </>
                                )}
                                {activeIndicator === 'stoch' && (
                                    <>
                                        <ReferenceLine y={80} stroke="#94a3b8" strokeDasharray="3 3" strokeWidth={1} />
                                        <ReferenceLine y={20} stroke="#94a3b8" strokeDasharray="3 3" strokeWidth={1} />
                                        <Line type="monotone" dataKey="stochK" stroke="#3b82f6" dot={false} strokeWidth={1.5} name="%K" />
                                        <Line type="monotone" dataKey="stochD" stroke="#f97316" dot={false} strokeWidth={1.5} name="%D" />
                                    </>
                                )}
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                )}
            </>
        )}
      </div>
    </div>
  );
};

export default CryptoWidget;
