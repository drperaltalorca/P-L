import React from 'react';
import { motion } from 'framer-motion';
import { Activity, Cigarette, AlertCircle, ClipboardList, Scissors, Syringe, Pill } from 'lucide-react';
import TextAreaField from '@/components/TextAreaField';

const ClinicalHistorySection = ({ formData, updateFormData }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.2 }}
      className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow duration-300"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 bg-rose-50 text-rose-600 rounded-xl">
          <Activity className="w-5 h-5" />
        </div>
        <h2 className="text-lg font-semibold text-slate-800">Historia Clínica</h2>
      </div>
      
      <div className="grid md:grid-cols-2 gap-5">
        <TextAreaField
          label="Factores de Riesgo"
          icon={<AlertCircle className="w-4 h-4" />}
          value={formData.riskFactors}
          onChange={(value) => updateFormData('riskFactors', value)}
          placeholder="Antecedentes familiares, riesgos de estilo de vida..."
        />
        <TextAreaField
          label="Hábitos Tóxicos"
          icon={<Cigarette className="w-4 h-4" />}
          value={formData.toxicHabits}
          onChange={(value) => updateFormData('toxicHabits', value)}
          placeholder="Alcohol, tabaco, uso de drogas..."
        />
        <TextAreaField
          label="Alergias a Medicamentos"
          icon={<AlertCircle className="w-4 h-4" />}
          value={formData.drugAllergies}
          onChange={(value) => updateFormData('drugAllergies', value)}
          placeholder="Penicilina, Sulfas, etc."
          highlight
        />
        <TextAreaField
          label="Antecedentes Personales"
          icon={<ClipboardList className="w-4 h-4" />}
          value={formData.personalHistory}
          onChange={(value) => updateFormData('personalHistory', value)}
          placeholder="Condiciones médicas previas"
        />
        <TextAreaField
          label="Intervenciones Quirúrgicas"
          icon={<Scissors className="w-4 h-4" />}
          value={formData.surgicalInterventions}
          onChange={(value) => updateFormData('surgicalInterventions', value)}
          placeholder="Fechas y tipos de cirugías"
        />
        <TextAreaField
          label="Estado de Inmunización"
          icon={<Syringe className="w-4 h-4" />}
          value={formData.immunizationStatus}
          onChange={(value) => updateFormData('immunizationStatus', value)}
          placeholder="Vacunas recibidas"
        />
        <TextAreaField
          label="Medicamentos Crónicos"
          icon={<Pill className="w-4 h-4" />}
          value={formData.chronicMedications}
          onChange={(value) => updateFormData('chronicMedications', value)}
          placeholder="Medicaciones actuales y continuas"
          className="md:col-span-2"
        />
      </div>
    </motion.div>
  );
};

export default ClinicalHistorySection;