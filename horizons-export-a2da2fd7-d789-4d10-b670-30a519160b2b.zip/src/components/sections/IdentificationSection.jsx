
import React from 'react';
import { motion } from 'framer-motion';
import { User, CreditCard, Calendar, Stethoscope, ShieldPlus, Hash } from 'lucide-react';
import FormField from '@/components/FormField';
import SelectField from '@/components/SelectField';

const IdentificationSection = ({ formData, updateFormData }) => {
  const medicalProviderOptions = [
    { value: '', label: 'Seleccioná el médico responsable' },
    { value: 'Dr. Pablo María PERALTA LORCA', label: 'Dr. Pablo María PERALTA LORCA' },
    { value: 'Juan Ignacio PERALTA LORCA', label: 'Juan Ignacio PERALTA LORCA' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow duration-300"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
          <User className="w-5 h-5" />
        </div>
        <h2 className="text-lg font-semibold text-slate-800">Identificación y Cobertura</h2>
      </div>
      
      <div className="grid md:grid-cols-2 gap-5">
        <FormField
          label="Nombre Completo"
          icon={<User className="w-4 h-4" />}
          value={formData.name}
          onChange={(value) => updateFormData('name', value)}
          placeholder="Ingresá el nombre completo del paciente"
          className="md:col-span-2"
        />
        <FormField
          label="Número de Documento"
          icon={<CreditCard className="w-4 h-4" />}
          value={formData.socialSecurityNumber}
          onChange={(value) => updateFormData('socialSecurityNumber', value)}
          placeholder="DNI, LE, LC, etc."
        />
        <FormField
          label="Número de Historia Clínica"
          icon={<Hash className="w-4 h-4" />}
          value={formData.historyNumber}
          onChange={(value) => updateFormData('historyNumber', value)}
          placeholder="Ej. HC-2024-001"
        />
        
        {/* New Insurance Fields */}
        <div className="md:col-span-2 grid md:grid-cols-2 gap-5 pt-2 border-t border-slate-50">
           <FormField
            label="Obra Social"
            icon={<ShieldPlus className="w-4 h-4" />}
            value={formData.healthInsurance}
            onChange={(value) => updateFormData('healthInsurance', value)}
            placeholder="Ej. OSDE, PAMI, Swiss Medical"
          />
           <FormField
            label="Número de Obra Social"
            icon={<CreditCard className="w-4 h-4" />}
            value={formData.affiliateNumber}
            onChange={(value) => updateFormData('affiliateNumber', value)}
            placeholder="N° de credencial"
          />
        </div>

        <FormField
          label="Fecha de Apertura"
          type="date"
          icon={<Calendar className="w-4 h-4" />}
          value={formData.openingDate}
          onChange={(value) => updateFormData('openingDate', value)}
        />
        <SelectField
          label="Médico Responsable"
          icon={<Stethoscope className="w-4 h-4" />}
          value={formData.medicalProvider}
          onChange={(value) => updateFormData('medicalProvider', value)}
          options={medicalProviderOptions}
        />
      </div>
    </motion.div>
  );
};

export default IdentificationSection;
