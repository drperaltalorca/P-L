import React from 'react';
import { motion } from 'framer-motion';
import { Users, MapPin, Phone, Heart, GraduationCap, Briefcase, AlertTriangle } from 'lucide-react';
import FormField from '@/components/FormField';
import SelectField from '@/components/SelectField';

const DemographicsSection = ({ formData, updateFormData }) => {
  const sexOptions = [
    { value: '', label: 'Seleccioná el sexo' },
    { value: 'male', label: 'Masculino' },
    { value: 'female', label: 'Femenino' },
    { value: 'other', label: 'Otro' }
  ];

  const maritalStatusOptions = [
    { value: '', label: 'Seleccioná el estado' },
    { value: 'single', label: 'Soltero/a' },
    { value: 'married', label: 'Casado/a' },
    { value: 'divorced', label: 'Divorciado/a' },
    { value: 'widowed', label: 'Viudo/a' }
  ];

  const employmentStatusOptions = [
    { value: '', label: 'Seleccioná el estado' },
    { value: 'employed', label: 'Empleado/a' },
    { value: 'unemployed', label: 'Desempleado/a' },
    { value: 'retired', label: 'Jubilado/a' },
    { value: 'student', label: 'Estudiante' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 }}
      className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow duration-300"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
          <Users className="w-5 h-5" />
        </div>
        <h2 className="text-lg font-semibold text-slate-800">Demografía</h2>
      </div>
      
      <div className="grid md:grid-cols-2 gap-5">
        <FormField
          label="Fecha de Nacimiento"
          type="date"
          value={formData.birthDate}
          onChange={(value) => updateFormData('birthDate', value)}
        />
        <SelectField
          label="Sexo"
          value={formData.sex}
          onChange={(value) => updateFormData('sex', value)}
          options={sexOptions}
        />
        <FormField
          label="Domicilio"
          icon={<MapPin className="w-4 h-4" />}
          value={formData.address}
          onChange={(value) => updateFormData('address', value)}
          placeholder="Calle, Número, Localidad, Código Postal"
          className="md:col-span-2"
        />
        <FormField
          label="Teléfono"
          icon={<Phone className="w-4 h-4" />}
          value={formData.phone}
          onChange={(value) => updateFormData('phone', value)}
          placeholder="Ej. (11) 4000-0000"
        />
        <SelectField
          label="Estado Civil"
          icon={<Heart className="w-4 h-4" />}
          value={formData.maritalStatus}
          onChange={(value) => updateFormData('maritalStatus', value)}
          options={maritalStatusOptions}
        />
        <FormField
          label="Nivel Educativo"
          icon={<GraduationCap className="w-4 h-4" />}
          value={formData.education}
          onChange={(value) => updateFormData('education', value)}
          placeholder="Máximo nivel de estudios"
        />
        <FormField
          label="Profesión"
          icon={<Briefcase className="w-4 h-4" />}
          value={formData.profession}
          onChange={(value) => updateFormData('profession', value)}
          placeholder="Ocupación actual"
        />
        <SelectField
          label="Situación Laboral"
          value={formData.employmentStatus}
          onChange={(value) => updateFormData('employmentStatus', value)}
          options={employmentStatusOptions}
        />
        <FormField
          label="Riesgos Laborales"
          icon={<AlertTriangle className="w-4 h-4" />}
          value={formData.laborRisks}
          onChange={(value) => updateFormData('laborRisks', value)}
          placeholder="Riesgos en el ámbito laboral"
        />
      </div>
    </motion.div>
  );
};

export default DemographicsSection;