import React from 'react';
import { motion } from 'framer-motion';
import { Ruler, Gauge, Scale, Scan, CalendarCheck } from 'lucide-react'; // Added CalendarCheck icon
import FormField from '@/components/FormField';

const MeasurementsSection = ({ formData, updateFormData }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.3 }}
      className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow duration-300"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 bg-teal-50 text-teal-600 rounded-xl">
          <Ruler className="w-5 h-5" />
        </div>
        <h2 className="text-lg font-semibold text-slate-800">Mediciones</h2>
      </div>
      
      <div className="grid md:grid-cols-2 gap-5">
        <FormField
          label="Presión Arterial"
          icon={<Gauge className="w-4 h-4" />}
          value={formData.bloodPressure}
          onChange={(value) => updateFormData('bloodPressure', value)}
          placeholder="120/80"
          suffix="mmHg"
        />
        <FormField
          label="Peso"
          icon={<Scale className="w-4 h-4" />}
          value={formData.weight}
          onChange={(value) => updateFormData('weight', value)}
          placeholder="0.00"
          suffix="kg"
        />
        <FormField
          label="Altura"
          icon={<Ruler className="w-4 h-4" />}
          value={formData.height}
          onChange={(value) => updateFormData('height', value)}
          placeholder="0"
          suffix="cm"
        />
        <FormField
          label="Control Ginecológico"
          icon={<Scan className="w-4 h-4" />}
          value={formData.gynecologicalControl}
          onChange={(value) => updateFormData('gynecologicalControl', value)}
          placeholder="Fecha de último control o notas"
        />
        {/* New field: Último control mamario eco + mamo */}
        <FormField
          label="Último control mamario eco + mamo"
          icon={<CalendarCheck className="w-4 h-4" />}
          value={formData.lastBreastControl} // Assuming a new state field for this
          onChange={(value) => updateFormData('lastBreastControl', value)} // Update state with new field
          placeholder="Fecha o detalles del control"
          className="bg-pink-50 border-pink-200 focus-within:ring-pink-500/20 focus-within:border-pink-500" // Pink styling
        />
      </div>
    </motion.div>
  );
};

export default MeasurementsSection;