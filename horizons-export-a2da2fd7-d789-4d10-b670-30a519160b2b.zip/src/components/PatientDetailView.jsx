
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, User, Clock, ShieldCheck, FileSpreadsheet, Pill, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ClinicalHistory from '@/components/ClinicalHistory';
import PrescriptionForm from '@/components/PrescriptionForm';
import PrescriptionsList from '@/components/PrescriptionsList';

const PatientDetailView = ({ patient, onBack }) => {
  const [activeTab, setActiveTab] = useState('history');

  if (!patient) return null;
  
  // Try to extract extra info if available from extended_data
  const extraInfo = patient.extended_data || {};

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-6"
    >
      {/* Header Actions */}
      <div className="flex items-center justify-between mb-2">
        <Button 
          variant="ghost" 
          onClick={onBack} 
          className="hover:bg-white/50 gap-2 text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4" /> Volver al Listado
        </Button>
      </div>

      {/* Patient Profile Header */}
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-blue-50 to-purple-50 rounded-full blur-3xl opacity-60 -translate-y-1/2 translate-x-1/4 pointer-events-none" />
        
        <div className="relative flex flex-col md:flex-row gap-8 items-start">
          <div className="flex-shrink-0">
            {patient.photo_url ? (
              <div className="w-32 h-32 rounded-3xl bg-slate-100 overflow-hidden shadow-lg border-4 border-white">
                <img src={patient.photo_url} alt={patient.name} className="w-full h-full object-cover" />
              </div>
            ) : (
              <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center text-4xl font-bold text-slate-400 shadow-inner border-4 border-white">
                {patient.name.charAt(0)}
              </div>
            )}
          </div>
          
          <div className="flex-grow space-y-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-800">{patient.name}</h1>
              {extraInfo.socialSecurityNumber && (
                 <p className="text-slate-500 font-medium">DNI: {extraInfo.socialSecurityNumber}</p>
              )}
              <div className="flex flex-wrap gap-4 mt-2 text-sm text-slate-500">
                <span className="flex items-center gap-1.5">
                  <User className="w-4 h-4 text-slate-400" /> {patient.age} años • {patient.gender}
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-slate-400" /> Registrado: {new Date(patient.created_at).toLocaleDateString()}
                </span>
                {extraInfo.medicalProvider && (
                  <span className="flex items-center gap-1.5 text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                    <ShieldCheck className="w-3.5 h-3.5" /> {extraInfo.medicalProvider}
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-slate-100">
              <div className="space-y-1">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Condiciones</span>
                <div className="flex flex-wrap gap-2">
                  {patient.medical_conditions?.map((c, i) => (
                    <span key={i} className="px-2 py-0.5 bg-rose-50 text-rose-600 text-xs rounded-md font-medium border border-rose-100">
                      {c}
                    </span>
                  ))}
                  {!patient.medical_conditions?.length && <span className="text-sm text-slate-500">-</span>}
                </div>
              </div>
              
              <div className="space-y-1">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Historia Clínica</span>
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-slate-400" />
                  <span className="text-sm text-slate-700">N° {extraInfo.historyNumber || 'Sin Asignar'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs for different modules */}
      <Tabs defaultValue="history" className="w-full" onValueChange={setActiveTab} value={activeTab}>
        <TabsList className="grid w-full grid-cols-3 bg-white/50 backdrop-blur-sm p-1 rounded-2xl mb-6 border border-white/50">
          <TabsTrigger value="history" className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-sm">
            <FileSpreadsheet className="w-4 h-4 mr-2" /> Historial Clínico
          </TabsTrigger>
          <TabsTrigger value="prescriptions" className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-purple-600 data-[state=active]:shadow-sm">
            <Pill className="w-4 h-4 mr-2" /> Recetas Activas
          </TabsTrigger>
          <TabsTrigger value="new-prescription" className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-emerald-600 data-[state=active]:shadow-sm">
            <Plus className="w-4 h-4 mr-2" /> Nueva Receta
          </TabsTrigger>
        </TabsList>

        <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-sm border border-white/50 min-h-[500px]">
          <TabsContent value="history" className="mt-0">
            <ClinicalHistory patientId={patient.id} />
          </TabsContent>
          
          <TabsContent value="prescriptions" className="mt-0">
            <div className="mb-6">
               <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2 mb-2">
                <Pill className="w-5 h-5 text-slate-500" />
                Historial de Recetas
              </h3>
              <p className="text-slate-500 text-sm">Registro completo de medicamentos prescritos al paciente.</p>
            </div>
            <PrescriptionsList patientId={patient.id} patient={patient} />
          </TabsContent>

          <TabsContent value="new-prescription" className="mt-0">
            <div className="mb-6">
               <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2 mb-2">
                <Plus className="w-5 h-5 text-slate-500" />
                Generar Nueva Receta
              </h3>
              <p className="text-slate-500 text-sm">Creá una nueva prescripción digital para este paciente.</p>
            </div>
            <PrescriptionForm 
              patientId={patient.id} 
              onSuccess={() => setActiveTab('prescriptions')} 
            />
          </TabsContent>
        </div>
      </Tabs>
    </motion.div>
  );
};

export default PatientDetailView;
