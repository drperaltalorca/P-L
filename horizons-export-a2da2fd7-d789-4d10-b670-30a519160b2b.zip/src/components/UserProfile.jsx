
import React, { useState } from 'react';
import { LogOut, User, Settings, Lock, Mail, UserPlus, Palette, Sun, Moon, Monitor } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuPortal,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const UserProfile = () => {
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  
  // Dialog States
  const [activeDialog, setActiveDialog] = useState(null); // 'profile', 'email', 'password', 'new-user', 'theme'
  const [loading, setLoading] = useState(false);

  // Form States
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');

  if (!user) return null;

  // Get user initials for fallback
  const getInitials = (name) => {
    if (!name) return 'DR';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const displayName = user.user_metadata?.full_name || user.email?.split('@')[0] || 'Doctor';
  const avatarUrl = user.user_metadata?.avatar_url;

  // Handlers
  const handleUpdateEmail = async () => {
    if (!newEmail) return;
    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ email: newEmail });
      if (error) throw error;
      toast({
        title: "Correo actualizado",
        description: "Revisa tu nuevo correo para confirmar el cambio.",
        className: "bg-green-50 border-green-200 text-green-800",
      });
      setActiveDialog(null);
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePassword = async () => {
    if (newPassword !== confirmPassword) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden.",
        variant: "destructive",
      });
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      toast({
        title: "Contraseña actualizada",
        description: "Tu contraseña ha sido modificada exitosamente.",
        className: "bg-green-50 border-green-200 text-green-800",
      });
      setActiveDialog(null);
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async () => {
    // Note: Creating a user usually requires service_role key on backend or specific permissions. 
    // Using supabase.auth.signUp creates a user but logs them in immediately in some contexts, 
    // or requires email confirmation. For an admin creating another user, it's best done via Edge Function 
    // to avoid logging out the current admin. Here we'll try a basic invite or simulate the request.
    
    setLoading(true);
    try {
       // Using the existing edge function pattern if available, or just standard signup which might replace session
       // For safety in this frontend-only context without specialized edge function for "admin create user":
       toast({
         title: "Funcionalidad Restringida",
         description: "Para crear nuevos usuarios administradores, utilice la función 'create-admin-user' desde el backend o solicite una Edge Function específica.",
         variant: "warning"
       });
       // In a real scenario: await supabase.functions.invoke('create-user', { body: { email: newUserEmail, password: newUserPassword } })
       setActiveDialog(null);
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="fixed top-4 right-4 z-50">
        <DropdownMenu>
          <DropdownMenuTrigger className="outline-none">
            <div className="flex items-center gap-3 bg-white/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-200 shadow-sm hover:bg-white transition-colors cursor-pointer group">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-700 leading-none group-hover:text-blue-600 transition-colors">{displayName}</p>
                <p className="text-[10px] text-slate-500 leading-none mt-1">{user.email}</p>
              </div>
              <Avatar className="h-9 w-9 border-2 border-white shadow-sm ring-2 ring-transparent group-hover:ring-blue-100 transition-all">
                <AvatarImage src={avatarUrl} alt={displayName} />
                <AvatarFallback className="bg-blue-100 text-blue-700 font-bold">
                  {getInitials(displayName)}
                </AvatarFallback>
              </Avatar>
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-64">
            <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
            <DropdownMenuSeparator />
            
            <DropdownMenuGroup>
              <DropdownMenuItem onClick={() => setActiveDialog('profile')} className="cursor-pointer">
                <User className="mr-2 h-4 w-4 text-slate-500" />
                <span>Perfil de Usuario</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveDialog('email')} className="cursor-pointer">
                <Mail className="mr-2 h-4 w-4 text-slate-500" />
                <span>Cambiar Email</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveDialog('password')} className="cursor-pointer">
                <Lock className="mr-2 h-4 w-4 text-slate-500" />
                <span>Cambiar Contraseña</span>
              </DropdownMenuItem>
            </DropdownMenuGroup>
            
            <DropdownMenuSeparator />
            
            <DropdownMenuGroup>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger>
                  <Palette className="mr-2 h-4 w-4 text-slate-500" />
                  <span>Apariencia</span>
                </DropdownMenuSubTrigger>
                <DropdownMenuPortal>
                  <DropdownMenuSubContent>
                    <DropdownMenuItem onClick={() => toast({ description: "Tema Claro activado" })}>
                      <Sun className="mr-2 h-4 w-4" />
                      <span>Claro</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => toast({ description: "Tema Oscuro (Próximamente)" })}>
                      <Moon className="mr-2 h-4 w-4" />
                      <span>Oscuro</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => toast({ description: "Tema del Sistema activado" })}>
                      <Monitor className="mr-2 h-4 w-4" />
                      <span>Sistema</span>
                    </DropdownMenuItem>
                  </DropdownMenuSubContent>
                </DropdownMenuPortal>
              </DropdownMenuSub>
              
              <DropdownMenuItem onClick={() => setActiveDialog('new-user')} className="cursor-pointer">
                <UserPlus className="mr-2 h-4 w-4 text-slate-500" />
                <span>Crear Usuario</span>
              </DropdownMenuItem>
            </DropdownMenuGroup>

            <DropdownMenuSeparator />
            
            <DropdownMenuItem 
              className="text-red-600 focus:text-red-600 focus:bg-red-50 cursor-pointer"
              onClick={signOut}
            >
              <LogOut className="mr-2 h-4 w-4" />
              <span>Cerrar Sesión</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* --- DIALOGS --- */}

      {/* Profile Dialog */}
      <Dialog open={activeDialog === 'profile'} onOpenChange={() => setActiveDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Perfil de Usuario</DialogTitle>
            <DialogDescription>Información de tu cuenta actual.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
             <div className="flex flex-col items-center gap-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={avatarUrl} />
                  <AvatarFallback className="text-lg bg-blue-100 text-blue-700">{getInitials(displayName)}</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h3 className="font-bold text-lg">{displayName}</h3>
                  <p className="text-slate-500">{user.email}</p>
                  <span className="text-xs bg-slate-100 text-slate-500 px-2 py-1 rounded-full mt-2 inline-block">ID: {user.id.slice(0, 8)}...</span>
                </div>
             </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Change Email Dialog */}
      <Dialog open={activeDialog === 'email'} onOpenChange={() => setActiveDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cambiar Correo Electrónico</DialogTitle>
            <DialogDescription>Ingresa tu nuevo correo. Se enviará una confirmación.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="current-email">Correo Actual</Label>
              <Input id="current-email" value={user.email} disabled className="bg-slate-50" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="new-email">Nuevo Correo</Label>
              <Input 
                id="new-email" 
                type="email" 
                value={newEmail} 
                onChange={(e) => setNewEmail(e.target.value)} 
                placeholder="ejemplo@nuevo.com"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setActiveDialog(null)}>Cancelar</Button>
            <Button onClick={handleUpdateEmail} disabled={loading}>
              {loading ? "Actualizando..." : "Actualizar Correo"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change Password Dialog */}
      <Dialog open={activeDialog === 'password'} onOpenChange={() => setActiveDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cambiar Contraseña</DialogTitle>
            <DialogDescription>Asegúrate de usar una contraseña segura.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="new-pass">Nueva Contraseña</Label>
              <Input 
                id="new-pass" 
                type="password" 
                value={newPassword} 
                onChange={(e) => setNewPassword(e.target.value)} 
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="confirm-pass">Confirmar Contraseña</Label>
              <Input 
                id="confirm-pass" 
                type="password" 
                value={confirmPassword} 
                onChange={(e) => setConfirmPassword(e.target.value)} 
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setActiveDialog(null)}>Cancelar</Button>
            <Button onClick={handleUpdatePassword} disabled={loading}>
              {loading ? "Actualizando..." : "Cambiar Contraseña"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create User Dialog */}
      <Dialog open={activeDialog === 'new-user'} onOpenChange={() => setActiveDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Crear Nuevo Usuario</DialogTitle>
            <DialogDescription>Agrega un nuevo miembro al equipo médico.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="user-email">Correo Electrónico</Label>
              <Input 
                id="user-email" 
                type="email"
                value={newUserEmail}
                onChange={(e) => setNewUserEmail(e.target.value)}
                placeholder="colega@hospital.com"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="user-pass">Contraseña Temporal</Label>
              <Input 
                id="user-pass" 
                type="password"
                value={newUserPassword}
                onChange={(e) => setNewUserPassword(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setActiveDialog(null)}>Cancelar</Button>
            <Button onClick={handleCreateUser} disabled={loading}>
              {loading ? "Creando..." : "Crear Usuario"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default UserProfile;
