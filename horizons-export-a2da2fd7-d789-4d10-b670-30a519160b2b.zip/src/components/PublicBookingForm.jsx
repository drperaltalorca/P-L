
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, User, Mail, Phone, MessageSquare, Send, CheckCircle2, History } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import FormField from '@/components/FormField';
import TextAreaField from '@/components/TextAreaField';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const PublicBookingForm = () => {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // New state for self-management
  const [existingPatientMode, setExistingPatientMode] = useState(false);
  const [lookupEmail, setLookupEmail] = useState('');
  const [patientFound, setPatientFound] = useState(null);

  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    whatsapp_number: '',
    preferred_date_time: '',
    reason_for_visit: ''
  });

  useEffect(() => {
    document.title = "Reservar Turno Online - Clínica Médica";
  }, []);

  const handleLookupPatient = async () => {
    if (!lookupEmail) {
      toast({ title: "Email requerido", description: "Ingrese su email para buscar su historial.", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('patients')
        .select('*')
        .ilike('extended_data->contact_info->>email', lookupEmail)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setPatientFound(data);
        setFormData(prev => ({
          ...prev,
          full_name: data.name,
          email: data.extended_data?.contact_info?.email || lookupEmail,
          whatsapp_number: data.extended_data?.contact_info?.phone || ''
        }));
        toast({ title: "¡Bienvenido de nuevo!", description: `Hola ${data.name}, completamos tus datos automáticamente.` });
      } else {
        toast({ title: "No encontrado", description: "No encontramos un paciente con ese email. Puede registrarse como nuevo paciente." });
        setPatientFound(null);
      }
    } catch (err) {
      console.error("Lookup error:", err);
      toast({ title: "Error", description: "Hubo un problema al buscar sus datos.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Basic validation
    if (!formData.full_name || !formData.email || !formData.whatsapp_number || !formData.preferred_date_time) {
      setError('Por favor completá todos los campos obligatorios.');
      setLoading(false);
      return;
    }

    try {
      // If synced with an existing patient, include the ID in notes or extended field logic (here simulated via name match)
      const { error: dbError } = await supabase
        .from('appointment_requests')
        .insert([{
          ...formData,
          preferred_date_time: new Date(formData.preferred_date_time).toISOString(),
          status: 'pending'
        }]);

      if (dbError) throw dbError;
      setSubmitted(true);
    } catch (err) {
      console.error('Booking error:', err);
      setError('Hubo un error al enviar tu solicitud. Por favor intentá nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white max-w-md w-full p-8 rounded-3xl shadow-xl text-center border border-slate-100"
        >
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">¡Solicitud Recibida!</h1>
          <p className="text-slate-600 mb-8">
            Gracias por contactarnos. Hemos recibido tu solicitud de turno correctamente. Te contactaremos a la brevedad por WhatsApp o Email para confirmar el horario.
          </p>
          <Button 
            onClick={() => window.location.reload()} 
            variant="outline"
            className="w-full"
          >
            Nueva Solicitud
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-violet-50 py-12 px-4 font-sans">
      <div className="max-w-xl mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center p-3 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-500/20 mb-6">
            <Calendar className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Solicitar Turno</h1>
          <p className="text-slate-500 text-lg">
            Completá el formulario y coordinaremos tu visita.
          </p>
        </div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-white rounded-3xl p-8 shadow-xl shadow-slate-200/50 border border-white/50 backdrop-blur-xl"
        >
          {error && (
            <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium flex items-center gap-2">
              <span className="block w-1.5 h-1.5 rounded-full bg-red-500" />
              {error}
            </div>
          )}

          <div className="mb-6 flex justify-end">
             <Button 
               variant="ghost" 
               size="sm" 
               onClick={() => setExistingPatientMode(!existingPatientMode)}
               className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
             >
               {existingPatientMode ? 'Soy paciente nuevo' : '¿Ya sos paciente?'}
             </Button>
          </div>

          {existingPatientMode && (
            <div className="mb-6 p-4 bg-indigo-50 rounded-xl border border-indigo-100 animate-in slide-in-from-top-2">
              <h3 className="text-sm font-bold text-indigo-900 mb-2 flex items-center gap-2">
                <History className="w-4 h-4" /> Autogestión de Pacientes
              </h3>
              <div className="flex gap-2">
                <input 
                  type="email" 
                  placeholder="Tu email registrado..." 
                  className="flex-1 px-3 py-2 rounded-lg border border-indigo-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={lookupEmail}
                  onChange={(e) => setLookupEmail(e.target.value)}
                />
                <Button size="sm" onClick={handleLookupPatient} disabled={loading} className="bg-indigo-600 text-white">
                  Buscar
                </Button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <FormField
              label="Nombre Completo"
              icon={<User className="w-4 h-4" />}
              placeholder="Tu nombre y apellido"
              value={formData.full_name}
              onChange={(v) => setFormData({...formData, full_name: v})}
              required
              readOnly={!!patientFound}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                label="Email"
                type="email"
                icon={<Mail className="w-4 h-4" />}
                placeholder="nombre@ejemplo.com"
                value={formData.email}
                onChange={(v) => setFormData({...formData, email: v})}
                required
                readOnly={!!patientFound}
              />
              <FormField
                label="WhatsApp"
                type="tel"
                icon={<Phone className="w-4 h-4" />}
                placeholder="Cod. Área + Número"
                value={formData.whatsapp_number}
                onChange={(v) => setFormData({...formData, whatsapp_number: v})}
                required
                readOnly={!!patientFound}
              />
            </div>

            <FormField
              label="Fecha y Hora Preferida"
              type="datetime-local"
              value={formData.preferred_date_time}
              onChange={(v) => setFormData({...formData, preferred_date_time: v})}
              required
            />

            <TextAreaField
              label="Motivo de la Visita"
              icon={<MessageSquare className="w-4 h-4" />}
              placeholder="Breve descripción de tus síntomas o razón de la consulta..."
              value={formData.reason_for_visit}
              onChange={(v) => setFormData({...formData, reason_for_visit: v})}
              required
            />

            <Button 
              type="submit" 
              disabled={loading}
              className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-base font-medium shadow-lg shadow-indigo-500/25 transition-all hover:scale-[1.02]"
            >
              {loading ? (
                'Enviando...'
              ) : (
                <>
                  Enviar Solicitud
                  <Send className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
            
            <p className="text-center text-xs text-slate-400 mt-4">
              Tus datos están protegidos. Al enviar aceptás ser contactado para confirmar el turno.
            </p>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default PublicBookingForm;
