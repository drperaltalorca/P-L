
import React, { useState, useEffect } from 'react';
import { Cloud, CloudRain, Sun, CloudLightning, CloudSnow, Thermometer, MapPin, Quote, Loader2, Calendar, Radar } from 'lucide-react';

// --- WEATHER WIDGET ---
const WeatherWidget = () => {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);

  // Coordinates for San Rafael, Mendoza
  const LAT = -34.6177;
  const LON = -68.3301;

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        // Using Open-Meteo (Free, no API key required)
        const response = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current_weather=true&daily=temperature_2m_max,temperature_2m_min&timezone=America%2FSao_Paulo`
        );
        const data = await response.json();
        setWeather(data);
      } catch (error) {
        console.error("Error fetching weather:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchWeather();
    // Refresh every 30 mins
    const interval = setInterval(fetchWeather, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const getWeatherIcon = (code) => {
    // WMO Weather interpretation codes (WW)
    if (code <= 1) return <Sun className="w-8 h-8 text-amber-500" />;
    if (code <= 3) return <Cloud className="w-8 h-8 text-slate-400" />;
    if (code <= 48) return <Cloud className="w-8 h-8 text-slate-500" />;
    if (code <= 67) return <CloudRain className="w-8 h-8 text-blue-400" />;
    if (code <= 77) return <CloudSnow className="w-8 h-8 text-cyan-200" />;
    if (code <= 82) return <CloudRain className="w-8 h-8 text-blue-500" />;
    if (code <= 86) return <CloudSnow className="w-8 h-8 text-cyan-100" />;
    if (code <= 99) return <CloudLightning className="w-8 h-8 text-purple-500" />;
    return <Sun className="w-8 h-8 text-amber-500" />;
  };

  if (loading) return (
    <div className="h-full flex items-center justify-center p-6 bg-white/50 rounded-3xl border border-white/60 shadow-sm animate-pulse">
      <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
    </div>
  );

  if (!weather) return null;

  const current = weather.current_weather;
  const daily = weather.daily;

  return (
    <div className="h-full relative overflow-hidden bg-gradient-to-br from-blue-500 to-cyan-400 rounded-3xl shadow-lg shadow-blue-500/20 text-white p-5 flex flex-col justify-between">
       {/* Background decoration */}
       <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl pointer-events-none" />
       
       <div className="flex justify-between items-start z-10">
         <div>
            <div className="flex items-center gap-1.5 text-blue-50 text-xs font-medium mb-1">
              <MapPin className="w-3 h-3" /> San Rafael, Mza
            </div>
            <div className="text-4xl font-bold tracking-tighter">
              {Math.round(current.temperature)}°
            </div>
         </div>
         <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md border border-white/20 shadow-inner">
            {getWeatherIcon(current.weathercode)}
         </div>
       </div>

       <div className="z-10 space-y-1">
          <div className="flex items-center gap-2 text-sm font-medium text-blue-50">
            <Thermometer className="w-4 h-4" />
            <span>H: {Math.round(daily.temperature_2m_max[0])}° L: {Math.round(daily.temperature_2m_min[0])}°</span>
          </div>
       </div>
    </div>
  );
};

// --- CLOCK WIDGET ---
const ClockWidget = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeString = time.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', hour12: false });
  const dateString = time.toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <div className="h-full bg-white rounded-3xl p-5 shadow-sm border border-slate-100 flex flex-col justify-center items-center relative overflow-hidden group hover:shadow-md transition-all">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-400 to-orange-400" />
      
      <div className="text-center space-y-1 z-10">
        <div className="text-5xl font-bold text-slate-800 tracking-tight font-mono tabular-nums">
          {timeString}
        </div>
        <div className="text-sm font-medium text-slate-500 capitalize flex items-center justify-center gap-2">
          <Calendar className="w-3.5 h-3.5" />
          {dateString}
        </div>
      </div>

      {/* Subtle seconds indicator or decoration */}
      <div className="absolute bottom-2 right-4 text-[10px] text-slate-300 font-mono">
        {time.getSeconds()}s
      </div>
    </div>
  );
};

// --- QUOTE WIDGET ---
const QuoteWidget = () => {
  const [quote, setQuote] = useState({ 
    text: "La medicina es la más humana de las artes, la más artística de las ciencias y la más científica de las humanidades.", 
    author: "Edmund Pellegrino" 
  });
  
  const quotes = [
    { text: "Dondequiera que se ama el arte de la medicina, se ama también a la humanidad.", author: "Hipócrates" },
    { text: "El buen médico trata la enfermedad; el gran médico trata al paciente que tiene la enfermedad.", author: "William Osler" },
    { text: "La primera riqueza es la salud.", author: "Ralph Waldo Emerson" },
    { text: "Que la comida sea tu medicina y la medicina sea tu comida.", author: "Hipócrates" },
    { text: "Curar a veces, tratar a menudo, consolar siempre.", author: "Hipócrates" }
  ];

  useEffect(() => {
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    setQuote(randomQuote);
  }, []);

  return (
    <div className="h-full bg-slate-900 rounded-3xl p-6 shadow-lg shadow-slate-900/10 text-white relative overflow-hidden flex flex-col justify-center">
       {/* Background Pattern */}
       <Quote className="absolute -bottom-4 -right-4 w-24 h-24 text-slate-800/50 rotate-12" />
       
       <div className="relative z-10">
         <Quote className="w-6 h-6 text-emerald-400 mb-3 opacity-80" />
         <p className="text-lg font-serif italic leading-relaxed text-slate-100 mb-4 opacity-90">
           "{quote.text}"
         </p>
         <div className="flex items-center gap-2">
            <div className="h-px w-8 bg-emerald-500/50" />
            <p className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
              {quote.author}
            </p>
         </div>
       </div>
    </div>
  );
};

// --- CONTINGENCY RADAR WIDGET ---
const ContingencyRadarWidget = () => {
  return (
    <div className="h-full bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 relative group flex flex-col">
       <div className="bg-white/90 backdrop-blur px-4 py-2.5 flex justify-between items-center border-b border-slate-100 z-10">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
             <Radar className="w-4 h-4 text-red-500" />
             Radar Contingencias
          </div>
          <a 
            href="https://www.mendoza.gov.ar/contingencias/radar/radar-sur/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[10px] bg-red-50 text-red-600 px-2 py-1 rounded-full hover:bg-red-100 transition-colors font-medium border border-red-100"
          >
             Abrir Web
          </a>
       </div>
       <div className="flex-1 relative bg-slate-50">
          <iframe 
             src="https://www.mendoza.gov.ar/contingencias/radar/radar-sur/" 
             className="w-full h-full border-0"
             title="Radar Mendoza"
             loading="lazy"
          />
          {/* Transparent overlay for edge grabbing if needed, but we want interaction mostly */}
       </div>
    </div>
  );
};

export { WeatherWidget, ClockWidget, QuoteWidget, ContingencyRadarWidget };
