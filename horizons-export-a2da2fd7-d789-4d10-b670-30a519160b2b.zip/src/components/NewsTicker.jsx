
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Activity, Gauge, ChevronRight, AlertCircle } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const NewsTicker = () => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [duration, setDuration] = useState(60); // Default speed

  // RSS Feed URL requested by user
  const RSS_URL = 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml';
  const PROXY_URL = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(RSS_URL)}`;

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await fetch(PROXY_URL);
        const data = await response.json();
        
        if (data.status === 'ok') {
          setNews(data.items);
        } else {
          throw new Error('Feed load failed');
        }
      } catch (err) {
        console.error("Failed to load news feed", err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
    
    // Refresh every 30 minutes
    const interval = setInterval(fetchNews, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return null;
  
  if (error || news.length === 0) {
    return null; // Gracefully hide if error
  }

  return (
    <div className="w-full bg-slate-900 text-white overflow-hidden shadow-md rounded-xl mb-6 border border-slate-700 relative flex items-center h-10 group select-none">
      {/* Label with Speed Control */}
      <div className="bg-blue-600 h-full flex items-center z-20 shrink-0 shadow-lg relative cursor-default">
        <div className="flex items-center gap-2 px-4 h-full">
           <Activity className="w-4 h-4 animate-pulse" />
           <span className="text-xs font-bold uppercase tracking-wider hidden sm:inline">BBC Science</span>
        </div>

        {/* Speed Control Trigger */}
        <Popover>
          <PopoverTrigger asChild>
            <button className="h-full px-2 hover:bg-blue-700 transition-colors border-l border-blue-500/50 flex items-center justify-center focus:outline-none" title="Ajustar Velocidad">
              <Gauge className="w-3.5 h-3.5 text-blue-100" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-72 p-4 bg-slate-900 border-slate-700 text-white shadow-xl" side="right" align="start">
             <div className="space-y-4">
               <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                 <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Control de Velocidad</span>
                 <span className="text-xs font-mono text-blue-400">{duration}s</span>
               </div>
               
               <div className="space-y-3">
                 <div className="flex justify-between text-[10px] font-medium text-slate-400 uppercase tracking-wide">
                   <span>Más Rápido (30s)</span>
                   <span>Más Lento (180s)</span>
                 </div>
                 <input 
                   type="range" 
                   min="30" 
                   max="180" 
                   step="5"
                   value={duration} 
                   onChange={(e) => setDuration(Number(e.target.value))}
                   className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-colors"
                 />
               </div>
               
               <p className="text-[10px] text-slate-500 italic">
                 Ajusta el tiempo que tarda la marquesina en completar un ciclo.
               </p>
             </div>
          </PopoverContent>
        </Popover>

        <div className="absolute right-0 top-0 bottom-0 w-6 bg-gradient-to-r from-blue-600 to-transparent translate-x-full pointer-events-none" />
      </div>

      {/* Marquee Content */}
      <div className="flex-1 overflow-hidden relative h-full flex items-center">
        <motion.div
          // Forces component remount/reset when duration changes to apply new animation duration immediately
          key={duration} 
          className="flex items-center gap-16 whitespace-nowrap pl-4"
          animate={{ x: ["0%", "-50%"] }} 
          transition={{ 
            repeat: Infinity, 
            ease: "linear", 
            duration: duration, 
            repeatType: "loop"
          }}
          style={{ width: "max-content" }}
        >
          {/* Double the list to create seamless loop illusion */}
          {[...news, ...news].map((item, index) => (
            <a 
              key={`${item.guid || item.link}-${index}`}
              href={item.link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-xs font-medium text-slate-300 hover:text-white transition-colors group/link relative"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500/50 group-hover/link:bg-blue-400 transition-colors"></span>
              {item.title}
              <ExternalLink className="w-3 h-3 opacity-0 -ml-1 group-hover/link:opacity-100 group-hover/link:ml-0 transition-all duration-300 text-blue-400" />
            </a>
          ))}
        </motion.div>
      </div>

      {/* Fade Overlay Right */}
      <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-slate-900 via-slate-900/50 to-transparent z-10 pointer-events-none" />
    </div>
  );
};

export default NewsTicker;
