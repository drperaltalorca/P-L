
import React, { useState, useEffect } from 'react';
import { CloudRain, RefreshCw, Maximize2, Minimize2, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const WeatherRadarFooter = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [key, setKey] = useState(0); // Used to force iframe reload if needed

  // Coordinates for Mendoza, Argentina
  const LAT = -32.8895;
  const LON = -68.8458;
  const ZOOM = 9;

  useEffect(() => {
    // Update timestamp every minute to simulate "live" status checks
    // The iframe itself handles the real-time data stream
    const interval = setInterval(() => {
      setLastUpdated(new Date());
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  const toggleExpand = () => setIsExpanded(!isExpanded);

  const refreshRadar = () => {
    setKey(prev => prev + 1);
    setLastUpdated(new Date());
  };

  return (
    <motion.div 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 1, type: "spring", stiffness: 100 }}
      className={`
        fixed bottom-0 right-0 left-0 z-50 
        bg-white/90 backdrop-blur-md border-t border-slate-200 shadow-[0_-4px_20px_rgba(0,0,0,0.1)]
        transition-all duration-500 ease-in-out
        ${isExpanded ? 'h-[400px]' : 'h-12'}
      `}
    >
      {/* Header / Toggle Bar */}
      <div 
        className="h-12 flex items-center justify-between px-4 cursor-pointer bg-slate-50/80 hover:bg-slate-100 transition-colors"
        onClick={toggleExpand}
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-indigo-600 font-bold text-sm">
            <CloudRain className="w-5 h-5" />
            <span className="hidden md:inline">Radar Meteorológico en Vivo</span>
            <span className="md:hidden">Radar</span>
          </div>
          
          <div className="h-4 w-px bg-slate-300 mx-2" />
          
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <MapPin className="w-3.5 h-3.5" />
            <span className="font-medium">Mendoza</span>
            <span className="hidden sm:inline text-slate-400">•</span>
            <span className="hidden sm:inline text-slate-400">
              Actualizado: {lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={(e) => { e.stopPropagation(); refreshRadar(); }}
            className="p-1.5 hover:bg-white rounded-full text-slate-500 hover:text-indigo-600 transition-colors"
            title="Actualizar Radar"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button 
            className="p-1.5 hover:bg-white rounded-full text-slate-500 hover:text-indigo-600 transition-colors"
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Radar Content */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-[calc(100%-48px)] bg-slate-100 relative overflow-hidden"
          >
            <iframe 
              key={key}
              title="Windy Weather Radar"
              width="100%" 
              height="100%" 
              src={`https://embed.windy.com/embed2.html?lat=${LAT}&lon=${LON}&detailLat=${LAT}&detailLon=${LON}&width=650&height=450&zoom=${ZOOM}&level=surface&overlay=rain&product=ecmwf&menu=&message=&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=&metricWind=km%2Fh&metricTemp=%C2%B0C&radarRange=-1`}
              frameBorder="0"
              className="w-full h-full"
            ></iframe>
            
            {/* Overlay Gradient for smoother look */}
            <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_20px_rgba(0,0,0,0.1)]" />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default WeatherRadarFooter;
