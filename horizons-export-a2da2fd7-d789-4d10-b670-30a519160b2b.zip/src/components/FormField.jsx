import React from 'react';

const FormField = ({ label, value, onChange, type = 'text', placeholder = '', className = '', icon, suffix }) => {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <label className="block text-sm font-medium text-slate-600 ml-1">
        {label}
      </label>
      <div className="relative group">
        {icon && (
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">
            {icon}
          </div>
        )}
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`
            w-full bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl 
            focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 block p-3
            transition-all duration-200 ease-in-out
            placeholder:text-slate-400
            ${icon ? 'pl-10' : 'pl-4'}
            ${suffix ? 'pr-12' : 'pr-4'}
            ${className.includes('bg-pink-50') ? 'bg-pink-50 border-pink-200 focus:ring-pink-500/20 focus:border-pink-500' : ''}
          `}
        />
        {suffix && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-medium text-slate-400">
            {suffix}
          </div>
        )}
      </div>
    </div>
  );
};

export default FormField;