
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ClipboardList, 
  Syringe, 
  ChevronRight, 
  CheckCircle2, 
  Search,
  Plus,
  BookOpen,
  ArrowRight,
  ShieldAlert,
  Printer,
  FileDown,
  User,
  Stethoscope,
  MapPin,
  PenTool,
  Save,
  Loader2,
  Users
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import FormField from '@/components/FormField';
import TextAreaField from '@/components/TextAreaField';
import SelectField from '@/components/SelectField';
import { useToast } from '@/components/ui/use-toast';
import SignaturePad from '@/components/SignaturePad';

const SurgeryProtocols = () => {
  const { toast } = useToast();
  const [protocols, setProtocols] = useState([]);
  const [patients, setPatients] = useState([]); 
  const [loading, setLoading] = useState(true);
  
  // Navigation & Selection
  const [selectedProtocol, setSelectedProtocol] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Create New Protocol State
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newProtocol, setNewProtocol] = useState({
    title: '', category: 'Mamaria', description: '', steps: []
  });
  const [stepsText, setStepsText] = useState('');

  // Execution/Consent Mode State
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionData, setExecutionData] = useState({
    patient_id: '',
    patient_name: '', // Added for print display
    patient_doc: '', // Added for print display
    surgery_date: '',
    surgery_time: '',
    location: '',
    surgeon_principal: '',
    surgeon_principal_signature: null,
    surgeon_assistant: '',
    surgeon_assistant_signature: null,
    anesthetist: '',
    consent_signer_name: '',
    consent_signer_doc: '',
    consent_signature: null
  });

  useEffect(() => {
    fetchProtocols();
    fetchPatients();
  }, []);

  const fetchProtocols = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('surgery_protocols')
        .select('*')
        .order('category', { ascending: true });

      if (error) throw error;
      setProtocols(data || []);
    } catch (err) {
      console.error('Error fetching protocols:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchPatients = async () => {
    const { data } = await supabase.from('patients').select('id, name, extended_data');
    setPatients(data || []);
  };

  const handleSaveProtocol = async () => {
    try {
      const parsedSteps = stepsText.split('\n').filter(s => s.trim()).map((s, i) => ({
        step: i + 1,
        title: `Paso ${i + 1}`,
        description: s.trim()
      }));

      const { error } = await supabase
        .from('surgery_protocols')
        .insert([{ ...newProtocol, steps: parsedSteps }]);

      if (error) throw error;

      toast({ title: "Protocolo Creado", description: "Guardado exitosamente." });
      setIsAddOpen(false);
      setNewProtocol({ title: '', category: 'Mamaria', description: '', steps: [] });
      setStepsText('');
      fetchProtocols();
    } catch (err) {
      toast({ title: "Error", description: "No se pudo guardar.", variant: "destructive" });
    }
  };

  const handleStartExecution = () => {
    setIsExecuting(true);
    const now = new Date();
    setExecutionData(prev => ({
       ...prev,
       surgery_date: now.toISOString().split('T')[0],
       surgery_time: now.toTimeString().slice(0,5),
       surgeon_principal: '',
       surgeon_principal_signature: null,
       surgeon_assistant: '',
       surgeon_assistant_signature: null,
       anesthetist: '',
       consent_signature: null
    }));
  };

  const handlePatientSelect = (patientId) => {
    const patient = patients.find(p => p.id === patientId);
    if (patient) {
      setExecutionData(prev => ({
        ...prev,
        patient_id: patientId,
        patient_name: patient.name,
        patient_doc: patient.extended_data?.socialSecurityNumber || '',
        consent_signer_name: patient.name,
        consent_signer_doc: patient.extended_data?.socialSecurityNumber || ''
      }));
    }
  };

  const handleSaveExecution = async () => {
    if (!executionData.patient_id || !executionData.consent_signature) {
      toast({ 
        title: "Datos Incompletos", 
        description: "El consentimiento del paciente es obligatorio.", 
        variant: "destructive" 
      });
      return;
    }

    try {
      setLoading(true);
      const fullDateTime = `${executionData.surgery_date}T${executionData.surgery_time}:00`;

      // 1. Save specific surgical record
      const { error: surgeryError } = await supabase.from('surgical_procedures').insert([{
        patient_id: executionData.patient_id,
        protocol_id: selectedProtocol.id,
        procedure_title: selectedProtocol.title,
        surgery_date: new Date(fullDateTime).toISOString(),
        location: executionData.location,
        surgeons: executionData.surgeon_principal, // Legacy support
        surgeon_principal: executionData.surgeon_principal,
        surgeon_assistant: executionData.surgeon_assistant,
        surgeon_principal_signature: executionData.surgeon_principal_signature,
        surgeon_assistant_signature: executionData.surgeon_assistant_signature,
        anesthetist: executionData.anesthetist,
        consent_signature: executionData.consent_signature,
        consent_signer_name: executionData.consent_signer_name,
        consent_signer_doc: executionData.consent_signer_doc
      }]);

      if (surgeryError) throw surgeryError;

      // 2. Add entry to Clinical History timeline
      const { error: historyError } = await supabase.from('clinical_history').insert([{
        patient_id: executionData.patient_id,
        visit_date: new Date(fullDateTime).toISOString(),
        visit_type: 'Cirugía',
        clinical_notes: `PROCEDIMIENTO: ${selectedProtocol.title}\nUBICACIÓN: ${executionData.location}\nCIRUJANO PRINCIPAL: ${executionData.surgeon_principal}\nAYUDANTE: ${executionData.surgeon_assistant}\nANESTESISTA: ${executionData.anesthetist}`,
        treatment_plan: 'Ver registro quirúrgico detallado para consentimiento y pasos del protocolo.',
        diagnosis: `Intervención Quirúrgica Programada: ${selectedProtocol.title}`
      }]);

      if (historyError) throw historyError;

      toast({ 
        title: "Cirugía Registrada", 
        description: "El procedimiento y consentimiento se guardaron en el historial.",
        className: "bg-green-50 border-green-200 text-green-800"
      });

      setIsExecuting(false);
      setExecutionData({
        patient_id: '',
        surgery_date: '',
        surgery_time: '',
        location: '',
        surgeon_principal: '',
        surgeon_principal_signature: null,
        surgeon_assistant: '',
        surgeon_assistant_signature: null,
        anesthetist: '',
        consent_signer_name: '',
        consent_signer_doc: '',
        consent_signature: null
      });

    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Falló el guardado del procedimiento.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const filteredProtocols = protocols.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex h-[calc(100vh-8rem)] gap-6 print:h-auto print:block print:bg-white print:p-0">
      
      {/* PRINT-ONLY HEADER AND STRUCTURE */}
      <div className="hidden print:block mb-8 border-b-2 border-slate-900 pb-4">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-black mb-1">Registro Quirúrgico</h1>
            <h2 className="text-xl text-slate-800">{selectedProtocol?.title}</h2>
            <p className="text-sm text-slate-600 mt-1 uppercase tracking-wider">{selectedProtocol?.category}</p>
          </div>
          <div className="text-right">
             <div className="text-sm font-bold">Fecha: {new Date().toLocaleDateString()}</div>
             <div className="text-xs text-slate-500">ID Protocolo: {selectedProtocol?.id?.slice(0,8)}</div>
          </div>
        </div>
      </div>

      {/* Sidebar List - Hidden when printing */}
      <div className="w-full md:w-1/3 flex flex-col gap-4 print:hidden">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              Protocolos
            </h2>
            <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700 h-8">
                  <Plus className="w-4 h-4 mr-1" /> Nuevo
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>Crear Nuevo Protocolo</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <FormField 
                    label="Título del Procedimiento" 
                    value={newProtocol.title}
                    onChange={v => setNewProtocol({...newProtocol, title: v})}
                  />
                  <SelectField
                    label="Categoría"
                    value={newProtocol.category}
                    onChange={v => setNewProtocol({...newProtocol, category: v})}
                    options={[
                      { value: 'Mamaria', label: 'Cirugía Mamaria' },
                      { value: 'Oncológica', label: 'Cirugía Oncológica' },
                      { value: 'Reconstructiva', label: 'Reconstructiva' },
                      { value: 'General', label: 'General' }
                    ]}
                  />
                  <TextAreaField
                    label="Descripción Breve"
                    value={newProtocol.description}
                    onChange={v => setNewProtocol({...newProtocol, description: v})}
                    rows={2}
                  />
                  <TextAreaField
                    label="Pasos (Uno por línea)"
                    value={stepsText}
                    onChange={setStepsText}
                    rows={6}
                  />
                  <Button onClick={handleSaveProtocol} className="w-full bg-blue-600">
                    Guardar Protocolo
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar protocolos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
            />
          </div>
        </div>

        <ScrollArea className="flex-1 bg-white rounded-2xl shadow-sm border border-slate-100 p-2">
          <div className="space-y-2">
            {loading ? (
              <div className="p-4 text-center text-slate-400 text-sm">Cargando protocolos...</div>
            ) : filteredProtocols.length > 0 ? (
              filteredProtocols.map((protocol) => (
                <button
                  key={protocol.id}
                  onClick={() => {
                    setSelectedProtocol(protocol);
                    setIsExecuting(false);
                  }}
                  className={`w-full text-left p-3 rounded-xl transition-all duration-200 border flex items-center justify-between group ${
                    selectedProtocol?.id === protocol.id
                      ? 'bg-blue-50 border-blue-200 shadow-sm'
                      : 'bg-white border-transparent hover:bg-slate-50 hover:border-slate-100'
                  }`}
                >
                  <div>
                    <h3 className={`font-semibold text-sm ${selectedProtocol?.id === protocol.id ? 'text-blue-700' : 'text-slate-700'}`}>
                      {protocol.title}
                    </h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={protocol.category === 'Mamaria' ? 'info' : 'warning'} className="text-[10px] px-1.5 py-0">
                        {protocol.category}
                      </Badge>
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 transition-transform ${selectedProtocol?.id === protocol.id ? 'text-blue-500 rotate-90' : 'text-slate-300 group-hover:text-slate-400'}`} />
                </button>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400 text-sm">
                No se encontraron protocolos.
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 bg-white rounded-2xl shadow-sm border border-slate-100 p-6 md:p-8 overflow-y-auto print:border-none print:shadow-none print:p-0 print:overflow-visible print:h-auto">
        <AnimatePresence mode="wait">
          {selectedProtocol ? (
            <motion.div
              key={selectedProtocol.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-8"
            >
              {/* Screen-only Header */}
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-slate-100 pb-6 print:hidden">
                <div>
                  <Badge className="mb-2 bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-100">
                    {selectedProtocol.category}
                  </Badge>
                  <h1 className="text-3xl font-bold text-slate-900 mb-2">{selectedProtocol.title}</h1>
                  <p className="text-slate-500 text-lg leading-relaxed max-w-2xl">{selectedProtocol.description}</p>
                </div>
                
                <div className="flex items-center gap-2">
                   <Button variant="outline" size="sm" onClick={handlePrint}>
                      <Printer className="w-4 h-4 mr-2" />
                      Imprimir / PDF
                   </Button>
                   {!isExecuting ? (
                     <Button onClick={handleStartExecution} className="bg-blue-600 hover:bg-blue-700 text-white">
                        Iniciar Procedimiento
                        <ArrowRight className="w-4 h-4 ml-2" />
                     </Button>
                   ) : (
                     <Button variant="ghost" onClick={() => setIsExecuting(false)} className="text-slate-500">
                        Cancelar
                     </Button>
                   )}
                </div>
              </div>

              {isExecuting ? (
                 <motion.div 
                   initial={{ opacity: 0, scale: 0.98 }}
                   animate={{ opacity: 1, scale: 1 }}
                   className="space-y-8 print:space-y-6"
                 >
                    {/* Execution Form & Print View */}
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-6 print:bg-white print:border-2 print:border-black print:p-4 print:rounded-none">
                       <h3 className="font-bold text-slate-800 flex items-center gap-2 text-lg border-b border-slate-200 pb-4 print:border-black">
                          <Stethoscope className="w-5 h-5 text-blue-600 print:hidden" />
                          Detalles Operativos
                       </h3>
                       
                       <div className="grid md:grid-cols-2 gap-6 print:grid-cols-2 print:gap-4">
                          <div className="space-y-1.5 print:col-span-2">
                             <label className="text-sm font-medium text-slate-700 ml-1 print:font-bold print:text-black">Paciente</label>
                             <div className="relative print:hidden">
                               <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                               <select 
                                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 outline-none"
                                  value={executionData.patient_id}
                                  onChange={(e) => handlePatientSelect(e.target.value)}
                               >
                                  <option value="">Seleccionar paciente...</option>
                                  {patients.map(p => (
                                    <option key={p.id} value={p.id}>{p.name} - DNI: {p.extended_data?.socialSecurityNumber}</option>
                                  ))}
                               </select>
                             </div>
                             {/* Print View Only for Patient */}
                             <div className="hidden print:block p-2 border border-black text-sm">
                                {executionData.patient_name || '__________________________'} (DNI: {executionData.patient_doc || '__________'})
                             </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                             <FormField 
                               label="Fecha" 
                               type="date"
                               value={executionData.surgery_date}
                               onChange={(v) => setExecutionData(p => ({...p, surgery_date: v}))}
                               className="bg-white print:border-black"
                             />
                             <FormField 
                               label="Hora" 
                               type="time"
                               value={executionData.surgery_time}
                               onChange={(v) => setExecutionData(p => ({...p, surgery_time: v}))}
                               className="bg-white print:border-black"
                             />
                          </div>

                          <SelectField
                            label="Lugar de Operación"
                            icon={<MapPin className="w-4 h-4" />}
                            value={executionData.location}
                            onChange={(v) => setExecutionData(p => ({...p, location: v}))}
                            options={[
                              { value: '', label: 'Seleccionar institución...' },
                              { value: 'Policlínica San Rafael', label: 'Policlínica San Rafael' },
                              { value: 'Hospital Español del Sur Mendocino', label: 'Hospital Español del Sur Mendocino' },
                              { value: 'Clínica Ciudad', label: 'Clínica Ciudad' }
                            ]}
                          />

                          {/* Surgeon Principal */}
                          <div className="space-y-2">
                              <FormField 
                                label="Cirujano Principal" 
                                icon={<User className="w-4 h-4" />}
                                placeholder="Dr. Nombre Apellido"
                                value={executionData.surgeon_principal}
                                onChange={(v) => setExecutionData(p => ({...p, surgeon_principal: v}))}
                                className="bg-white"
                              />
                              <div className="border border-slate-200 rounded-xl overflow-hidden print:border-black">
                                <div className="bg-slate-100 px-3 py-1 text-xs text-slate-500 print:bg-white print:text-black print:font-bold">Firma Cirujano Principal</div>
                                <SignaturePad 
                                    onSave={(sig) => setExecutionData(p => ({...p, surgeon_principal_signature: sig}))}
                                    onClear={() => setExecutionData(p => ({...p, surgeon_principal_signature: null}))}
                                />
                              </div>
                          </div>

                          {/* Surgeon Assistant */}
                          <div className="space-y-2">
                              <FormField 
                                label="Cirujano Ayudante" 
                                icon={<Users className="w-4 h-4" />}
                                placeholder="Dr. Nombre Apellido"
                                value={executionData.surgeon_assistant}
                                onChange={(v) => setExecutionData(p => ({...p, surgeon_assistant: v}))}
                                className="bg-white"
                              />
                              <div className="border border-slate-200 rounded-xl overflow-hidden print:border-black">
                                <div className="bg-slate-100 px-3 py-1 text-xs text-slate-500 print:bg-white print:text-black print:font-bold">Firma Cirujano Ayudante</div>
                                <SignaturePad 
                                    onSave={(sig) => setExecutionData(p => ({...p, surgeon_assistant_signature: sig}))}
                                    onClear={() => setExecutionData(p => ({...p, surgeon_assistant_signature: null}))}
                                />
                              </div>
                          </div>

                          <FormField 
                             label="Anestesista" 
                             icon={<Syringe className="w-4 h-4" />}
                             placeholder="Nombre del anestesista"
                             value={executionData.anesthetist}
                             onChange={(v) => setExecutionData(p => ({...p, anesthetist: v}))}
                             className="bg-white"
                          />
                       </div>
                    </div>

                    {/* Protocol Steps Display for Print (Always visible in Print Mode) */}
                    <div className="hidden print:block border-2 border-black p-4 mt-4">
                        <h3 className="font-bold border-b border-black mb-2 pb-1">Pasos del Protocolo</h3>
                        <ul className="list-decimal pl-5 space-y-1">
                           {selectedProtocol.steps?.map((step, idx) => (
                              <li key={idx} className="text-sm">
                                 <span className="font-bold">{step.title}: </span>
                                 {step.description}
                              </li>
                           ))}
                        </ul>
                    </div>

                    {/* Digital Consent */}
                    <div className="bg-white p-6 rounded-2xl border border-blue-100 shadow-sm space-y-6 print:border-2 print:border-black print:rounded-none print:shadow-none print:break-inside-avoid">
                       <h3 className="font-bold text-slate-800 flex items-center gap-2 text-lg border-b border-slate-100 pb-4 print:border-black">
                          <PenTool className="w-5 h-5 text-blue-600 print:hidden" />
                          Consentimiento Informado
                       </h3>
                       
                       <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200 text-justify print:bg-white print:border-none print:p-0 print:text-black">
                          Yo, <strong>{executionData.consent_signer_name || '________________'}</strong>, con documento N° <strong>{executionData.consent_signer_doc || '________________'}</strong>, 
                          por la presente presto mi consentimiento para la realización del procedimiento <strong>{selectedProtocol.title}</strong> en la institución <strong>{executionData.location || '________________'}</strong>. 
                          Declaro haber sido informado/a detalladamente sobre la naturaleza de la intervención, sus beneficios, riesgos, complicaciones y alternativas. 
                          He tenido la oportunidad de realizar preguntas y he comprendido las explicaciones brindadas por el equipo médico compuesto por el Dr./Dra. <strong>{executionData.surgeon_principal || '________________'}</strong> y equipo.
                       </p>

                       <div className="grid md:grid-cols-2 gap-8 print:grid-cols-2 print:gap-4 print:mt-8">
                          <div className="space-y-4 print:hidden">
                             <FormField 
                                label="Nombre del Firmante" 
                                value={executionData.consent_signer_name}
                                onChange={(v) => setExecutionData(p => ({...p, consent_signer_name: v}))}
                             />
                             <FormField 
                                label="Documento (DNI/Pasaporte)" 
                                value={executionData.consent_signer_doc}
                                onChange={(v) => setExecutionData(p => ({...p, consent_signer_doc: v}))}
                             />
                          </div>
                          
                          <div className="space-y-2 col-span-2 md:col-span-1 print:col-span-2">
                             <label className="text-sm font-medium text-slate-700 print:font-bold print:text-black">Firma Digital Paciente/Tutor</label>
                             <div className="print:border print:border-black print:h-24 print:flex print:items-end print:justify-center">
                                <SignaturePad 
                                    onSave={(sig) => setExecutionData(p => ({...p, consent_signature: sig}))}
                                    onClear={() => setExecutionData(p => ({...p, consent_signature: null}))}
                                />
                             </div>
                             {executionData.consent_signature && (
                               <div className="hidden print:block text-center text-xs mt-1">Firma Digital Capturada</div>
                             )}
                          </div>
                       </div>
                    </div>

                    <div className="flex justify-end pt-4 print:hidden">
                       <Button 
                          onClick={handleSaveExecution} 
                          disabled={loading}
                          className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 rounded-xl text-lg shadow-lg shadow-green-600/20"
                       >
                          {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Save className="w-5 h-5 mr-2" />}
                          Guardar en Historial
                       </Button>
                    </div>
                 </motion.div>
              ) : (
                <div className="print:block">
                  {/* Protocol Steps Display (Read Only) */}
                  <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 print:bg-white print:border-none print:p-0">
                    <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2 print:text-black print:border-b print:border-black print:pb-2">
                      <ClipboardList className="w-5 h-5 text-blue-600 print:hidden" />
                      Pasos Quirúrgicos
                    </h3>
                    
                    <div className="relative pl-4 space-y-8 before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 print:pl-0 print:space-y-2 print:before:hidden">
                      {selectedProtocol.steps && Array.isArray(selectedProtocol.steps) ? (
                        selectedProtocol.steps.map((step, idx) => (
                          <div key={idx} className="relative flex gap-4 print:block">
                            <div className="relative z-10 flex-shrink-0 w-10 h-10 rounded-full bg-white border-2 border-blue-500 text-blue-600 font-bold flex items-center justify-center shadow-sm print:hidden">
                              {idx + 1}
                            </div>
                            <div className="flex-1 pt-1.5 print:pt-0">
                              <h4 className="font-bold text-slate-800 text-base mb-1 print:text-black print:mb-0">
                                <span className="hidden print:inline mr-2">{idx + 1}.</span>
                                {step.title}
                              </h4>
                              <p className="text-slate-600 leading-relaxed text-sm print:text-black">{step.description}</p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-slate-400 italic">No hay pasos definidos para este protocolo.</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 print:grid-cols-1 print:gap-2 print:mt-6">
                     <div className="p-4 bg-orange-50 border border-orange-100 rounded-xl print:bg-white print:border-black print:border">
                        <h4 className="font-bold text-orange-800 flex items-center gap-2 mb-2 print:text-black">
                          <ShieldAlert className="w-4 h-4 print:hidden" /> Puntos Críticos
                        </h4>
                        <ul className="list-disc list-inside text-sm text-orange-700 space-y-1 print:text-black">
                          <li>Verificar lateralidad antes de la incisión.</li>
                          <li>Controlar hemostasia rigurosa en lecho.</li>
                          <li>Recuento de gasas y compresas.</li>
                        </ul>
                     </div>
                     <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl print:bg-white print:border-black print:border">
                        <h4 className="font-bold text-emerald-800 flex items-center gap-2 mb-2 print:text-black">
                          <CheckCircle2 className="w-4 h-4 print:hidden" /> Checklist Final
                        </h4>
                        <ul className="list-disc list-inside text-sm text-emerald-700 space-y-1 print:text-black">
                          <li>Muestra enviada a anatomía patológica.</li>
                          <li>Drenajes fijados y permeables.</li>
                          <li>Curación plana compresiva.</li>
                        </ul>
                     </div>
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-60 print:hidden">
              <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                <Syringe className="w-10 h-10 text-slate-300" />
              </div>
              <h3 className="text-xl font-bold text-slate-700 mb-2">Selecciona un Protocolo</h3>
              <p className="text-slate-500 max-w-sm">
                Elige un protocolo quirúrgico del menú lateral para ver detalles o iniciar el procedimiento.
              </p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default SurgeryProtocols;
