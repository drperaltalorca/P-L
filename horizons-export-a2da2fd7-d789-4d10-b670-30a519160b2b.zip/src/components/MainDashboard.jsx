
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Calendar as CalendarIcon, Activity, AlertCircle, Clock, BookOpen, ArrowRight, ClipboardList, BarChart3, Pill } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import WelcomeMessage from '@/components/WelcomeMessage';
import DashboardWidget from '@/components/DashboardWidget';
import HeroImage from '@/components/HeroImage';
import { supabase } from '@/lib/customSupabaseClient';
import { WeatherWidget, ClockWidget, QuoteWidget, ContingencyRadarWidget } from '@/components/DashboardWidgets';
import NewsTicker from '@/components/NewsTicker';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import PatientLink from '@/components/PatientLink';

// Helper for relative time
const timeAgo = (dateString) => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInSeconds = Math.floor((now - date) / 1000);
  
  if (diffInSeconds < 60) return 'Hace un momento';
  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) return `Hace ${diffInMinutes} min`;
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) return `Hace ${diffInHours} horas`;
  const diffInDays = Math.floor(diffInHours / 24);
  return `Hace ${diffInDays} días`;
};

// Custom 3D Bar Component for Recharts
const CustomBar = (props) => {
  const { fill, x, y, width, height } = props;
  const depth = 8; // Depth of the 3D effect

  // Don't render if height is 0 or invalid
  if (!height || height < 0) return null;

  return (
    <g>
      {/* Side face (creates depth) */}
      <path
        d={`M${x + width},${y} L${x + width + depth},${y - depth} L${x + width + depth},${y + height - depth} L${x + width},${y + height} Z`}
        fill={fill}
        fillOpacity={0.7}
      />
      {/* Top face (creates depth) */}
      <path
        d={`M${x},${y} L${x + depth},${y - depth} L${x + width + depth},${y - depth} L${x + width},${y} Z`}
        fill={fill}
        fillOpacity={0.5}
      />
      {/* Front face */}
      <rect x={x} y={y} width={width} height={height} fill={fill} />
    </g>
  );
};

const MainDashboard = () => {
  const [stats, setStats] = useState({
    totalPatients: 0,
    appointmentsToday: 0,
    activeAlerts: 0,
    reportsGenerated: 0
  });
  const [loading, setLoading] = useState(true);
  
  // Activity History State
  const [activities, setActivities] = useState([]);
  const [showAllHistory, setShowAllHistory] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Blog Posts State
  const [blogPosts, setBlogPosts] = useState([]);
  const [blogLoading, setBlogLoading] = useState(true);

  // New Stats State
  const [diseaseStats, setDiseaseStats] = useState([]);
  const [medicationStats, setMedicationStats] = useState([]);
  const [statsLoading, setStatsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats();
    fetchRecentActivity();
    fetchBlogPosts();
    fetchAnalyticsData();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      // 1. Total Patients
      const { count: patientCount } = await supabase
        .from('patients')
        .select('*', { count: 'exact', head: true });

      // 2. Appointments Today
      const today = new Date().toISOString().split('T')[0];
      const { count: apptCount } = await supabase
        .from('appointments')
        .select('*', { count: 'exact', head: true })
        .eq('appointment_date', today);
      
      // 3. Reports
      const { count: reportsCount } = await supabase
        .from('generated_reports')
        .select('*', { count: 'exact', head: true });

      setStats({
        totalPatients: patientCount || 0,
        appointmentsToday: apptCount || 0,
        activeAlerts: 2, // Hardcoded for demo/MVP
        reportsGenerated: reportsCount || 0
      });

    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAnalyticsData = async () => {
    setStatsLoading(true);
    try {
      // 1. Fetch Diseases (from patients.medical_conditions array)
      const { data: patientsData, error: patientsError } = await supabase
        .from('patients')
        .select('medical_conditions');

      if (!patientsError && patientsData) {
        const diseaseCounts = {};
        patientsData.forEach(patient => {
          if (patient.medical_conditions && Array.isArray(patient.medical_conditions)) {
            patient.medical_conditions.forEach(condition => {
              // Normalize string: trim and lowercase for counting
              const normalized = condition.trim();
              if (normalized) {
                 diseaseCounts[normalized] = (diseaseCounts[normalized] || 0) + 1;
              }
            });
          }
        });

        // Convert to array and sort
        const sortedDiseases = Object.entries(diseaseCounts)
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5); // Top 5
          
        setDiseaseStats(sortedDiseases);
      }

      // 2. Fetch Medications (from prescriptions table)
      const { data: prescriptionsData, error: rxError } = await supabase
        .from('prescriptions')
        .select('medication_name');

      if (!rxError && prescriptionsData) {
        const medCounts = {};
        prescriptionsData.forEach(rx => {
          const name = rx.medication_name;
          if (name) {
             const normalized = name.trim();
             medCounts[normalized] = (medCounts[normalized] || 0) + 1;
          }
        });

        const sortedMeds = Object.entries(medCounts)
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5); // Top 5

        setMedicationStats(sortedMeds);
      }

    } catch (err) {
      console.error("Error fetching analytics:", err);
    } finally {
      setStatsLoading(false);
    }
  };

  const fetchRecentActivity = async () => {
    setHistoryLoading(true);
    try {
      // Get recent patients
      const { data: recentPatients } = await supabase
        .from('patients')
        .select('id, name, created_at')
        .order('created_at', { ascending: false })
        .limit(5);

      // Get recent appointments (Join with patients)
      const { data: recentAppts } = await supabase
        .from('appointments')
        .select('id, patient_id, appointment_date, created_at, status, patients(name)')
        .order('created_at', { ascending: false })
        .limit(5);

      // Get recent reports (Join with patients)
      const { data: recentReports } = await supabase
        .from('generated_reports')
        .select('id, patient_id, report_type, created_at, patients(name)')
        .order('created_at', { ascending: false })
        .limit(5);

      const combined = [
        ...(recentPatients?.map(p => ({
          type: 'patient',
          title: 'Nuevo paciente registrado',
          patientName: p.name,
          patientId: p.id,
          detail: null, // detail is now rendered via patientName
          date: p.created_at,
          color: 'blue'
        })) || []),
        ...(recentAppts?.map(a => ({
          type: 'appointment',
          title: 'Turno programado',
          patientName: a.patients?.name || 'Desconocido',
          patientId: a.patient_id,
          detail: `Fecha: ${a.appointment_date}`,
          date: a.created_at,
          color: 'emerald'
        })) || []),
        ...(recentReports?.map(r => ({
          type: 'report',
          title: 'Reporte generado',
          patientName: r.patients?.name || 'Desconocido',
          patientId: r.patient_id,
          detail: r.report_type,
          date: r.created_at,
          color: 'violet'
        })) || [])
      ].sort((a, b) => new Date(b.date) - new Date(a.date));

      setActivities(combined);
    } catch (error) {
      console.error("Error fetching activity", error);
    } finally {
      setHistoryLoading(false);
    }
  };

  const fetchBlogPosts = async () => {
    try {
      setBlogLoading(true);
      const { data, error } = await supabase
        .from('blog_posts')
        .select('id, title, excerpt, slug, published_at, featured_image')
        .eq('status', 'published')
        .order('published_at', { ascending: false })
        .limit(3);

      if (error) throw error;
      setBlogPosts(data || []);
    } catch (error) {
      console.error('Error fetching blog posts:', error);
    } finally {
      setBlogLoading(false);
    }
  };

  const navigateToProtocols = () => {
    const event = new CustomEvent('navigate-to-tab', { detail: 'protocols' });
    window.dispatchEvent(event);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const COLORS = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444'];

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-8 pb-12"
    >
      <motion.div variants={item}>
        <WelcomeMessage />
        <div className="mt-6">
           <NewsTicker />
        </div>
      </motion.div>

      {/* New Widgets Row - Includes Clock, Contingency Radar, Weather, Quote */}
      <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 h-auto lg:h-72">
        <ClockWidget />
        <ContingencyRadarWidget />
        <WeatherWidget />
        <QuoteWidget />
      </motion.div>

      {/* Main Stats Grid */}
      <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardWidget
          title="Pacientes Totales"
          value={stats.totalPatients}
          icon={Users}
          trend="+12% vs mes anterior"
          color="blue"
          loading={loading}
        />
        <DashboardWidget
          title="Turnos Hoy"
          value={stats.appointmentsToday}
          icon={CalendarIcon}
          trend="4 pendientes"
          color="emerald"
          loading={loading}
        />
        <DashboardWidget
          title="Alertas Activas"
          value={stats.activeAlerts}
          icon={AlertCircle}
          trend="Requiere atención"
          color="rose"
          loading={loading}
        />
        <div 
          onClick={navigateToProtocols}
          className="cursor-pointer group relative rounded-2xl overflow-hidden transition-all duration-300 flex flex-col shadow-sm hover:shadow-md border border-slate-200/60 min-h-[140px] bg-white"
        >
          <div className="px-4 py-2.5 flex items-center justify-between bg-red-600">
             <div className="flex items-center gap-2 text-white">
                <ClipboardList className="w-4 h-4 opacity-90" />
                <span className="text-xs font-bold uppercase tracking-wider">Protocolos</span>
             </div>
             <ArrowRight className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <div className="flex-1 p-4 flex flex-col justify-center">
             <div className="text-xl font-bold text-slate-800 leading-tight">
               Guías Quirúrgicas
             </div>
             <p className="text-xs text-slate-500 mt-1">
               Mamaria y Oncológica
             </p>
             <div className="mt-2 text-xs font-medium text-red-600 bg-red-50 px-2 py-1 rounded inline-block w-fit">
               Acceso Rápido
             </div>
          </div>
        </div>
      </motion.div>

      {/* ANALYTICS SECTION - Diseases & Medications */}
      <motion.div variants={item} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Diseases Chart & List */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex flex-col">
           <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2 text-lg">
              <Activity className="w-5 h-5 text-rose-500" />
              Enfermedades Prevalentes
           </h3>
           
           <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Chart */}
              <div className="h-64 w-full">
                {statsLoading ? (
                  <div className="h-full flex items-center justify-center bg-slate-50 rounded-xl">
                    <span className="text-slate-400 text-sm">Cargando...</span>
                  </div>
                ) : diseaseStats.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={diseaseStats} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="name" hide />
                      <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                      <Tooltip 
                        cursor={{fill: 'transparent'}}
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      />
                      <Bar dataKey="count" shape={<CustomBar />} barSize={40}>
                        {diseaseStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center bg-slate-50 rounded-xl">
                    <span className="text-slate-400 text-sm italic">Sin datos suficientes</span>
                  </div>
                )}
              </div>

              {/* List */}
              <div className="space-y-4">
                 {statsLoading ? (
                   [1,2,3].map(i => <div key={i} className="h-10 bg-slate-50 rounded-lg animate-pulse" />)
                 ) : diseaseStats.length > 0 ? (
                   diseaseStats.map((stat, i) => (
                     <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                        <div className="flex items-center gap-3">
                           <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                           <span className="text-sm font-medium text-slate-700 capitalize truncate max-w-[120px]" title={stat.name}>{stat.name}</span>
                        </div>
                        <Badge variant="secondary" className="bg-white shadow-sm text-slate-600 font-mono">
                           {stat.count}
                        </Badge>
                     </div>
                   ))
                 ) : (
                    <p className="text-sm text-slate-400 text-center py-4">No hay registros de condiciones médicas.</p>
                 )}
              </div>
           </div>
        </div>

        {/* Medications Chart & List */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex flex-col">
           <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2 text-lg">
              <Pill className="w-5 h-5 text-blue-500" />
              Medicamentos más Recetados
           </h3>
           
           <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Chart */}
              <div className="h-64 w-full">
                {statsLoading ? (
                  <div className="h-full flex items-center justify-center bg-slate-50 rounded-xl">
                    <span className="text-slate-400 text-sm">Cargando...</span>
                  </div>
                ) : medicationStats.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={medicationStats} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="name" hide />
                      <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                      <Tooltip 
                        cursor={{fill: 'transparent'}}
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      />
                      <Bar dataKey="count" shape={<CustomBar />} barSize={40}>
                        {medicationStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center bg-slate-50 rounded-xl">
                    <span className="text-slate-400 text-sm italic">Sin datos de recetas</span>
                  </div>
                )}
              </div>

              {/* List */}
              <div className="space-y-4">
                 {statsLoading ? (
                   [1,2,3].map(i => <div key={i} className="h-10 bg-slate-50 rounded-lg animate-pulse" />)
                 ) : medicationStats.length > 0 ? (
                   medicationStats.map((stat, i) => (
                     <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                        <div className="flex items-center gap-3">
                           <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                           <span className="text-sm font-medium text-slate-700 capitalize truncate max-w-[120px]" title={stat.name}>{stat.name}</span>
                        </div>
                        <Badge variant="secondary" className="bg-white shadow-sm text-slate-600 font-mono">
                           {stat.count}
                        </Badge>
                     </div>
                   ))
                 ) : (
                    <p className="text-sm text-slate-400 text-center py-4">No hay recetas emitidas aún.</p>
                 )}
              </div>
           </div>
        </div>

      </motion.div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div variants={item} className="lg:col-span-2 space-y-6">
           <HeroImage />
        </motion.div>

        <motion.div variants={item} className="space-y-6">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 h-full flex flex-col">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-500" />
              Actividad Reciente
            </h3>
            
            <div className="space-y-6 flex-grow">
              {activities.slice(0, 3).map((act, i) => (
                <div key={i} className="flex gap-4 items-start relative pb-6 last:pb-0 border-l-2 border-slate-100 pl-6 last:border-0">
                  <div className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white border-2 border-${act.color}-200 flex items-center justify-center`}>
                    <div className={`w-1.5 h-1.5 rounded-full bg-${act.color}-500`} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">
                      {act.title}
                    </p>
                    <div className="text-xs text-slate-500 mt-0.5">
                       {act.type === 'patient' ? (
                          <PatientLink patientId={act.patientId} name={act.patientName} />
                       ) : (
                          <>
                             <PatientLink patientId={act.patientId} name={act.patientName} />
                             {act.detail && <span className="block mt-0.5 opacity-80">{act.detail}</span>}
                          </>
                       )}
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {timeAgo(act.date)}
                    </p>
                  </div>
                </div>
              ))}
              {activities.length === 0 && !historyLoading && (
                 <p className="text-sm text-slate-400 italic">No hay actividad reciente.</p>
              )}
            </div>
            
            <button 
              onClick={() => setShowAllHistory(true)}
              className="w-full mt-6 py-3 px-4 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors"
            >
              Ver todo el historial
            </button>
          </div>
        </motion.div>
      </div>

      {/* Blog Section */}
      <motion.div variants={item} className="pt-4">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-bold text-slate-800 text-xl flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            Novedades Médicas
          </h3>
          <a href="/blog" target="_blank" className="group text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1 transition-colors">
            Ver todas las publicaciones
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           {blogLoading ? (
             // Skeletons
             [1,2,3].map(i => (
                <div key={i} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 h-80 animate-pulse">
                   <div className="w-full h-40 bg-slate-100 rounded-xl mb-4"></div>
                   <div className="h-4 bg-slate-100 rounded w-3/4 mb-2"></div>
                   <div className="h-4 bg-slate-100 rounded w-1/2"></div>
                </div>
             ))
           ) : blogPosts.length > 0 ? (
             blogPosts.map(post => (
               <div key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full group">
                  <div className="h-48 overflow-hidden relative bg-slate-50">
                    {post.featured_image ? (
                       <img src={post.featured_image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    ) : (
                       <div className="w-full h-full flex items-center justify-center text-slate-300 bg-slate-50">
                          <BookOpen className="w-10 h-10 opacity-20" />
                       </div>
                    )}
                    <div className="absolute top-3 left-3">
                      <Badge variant="secondary" className="bg-white/90 backdrop-blur-sm text-slate-700 shadow-sm font-normal text-xs hover:bg-white">
                        <Clock className="w-3 h-3 mr-1" />
                        {new Date(post.published_at).toLocaleDateString()}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-5 flex flex-col flex-1">
                     <h4 className="font-bold text-lg text-slate-800 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors leading-tight">
                        {post.title}
                     </h4>
                     <p className="text-sm text-slate-500 line-clamp-3 mb-5 flex-1 leading-relaxed">
                        {post.excerpt}
                     </p>
                     <a 
                        href={`/blog?post=${post.slug}`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-sm font-semibold text-blue-600 hover:text-blue-700 gap-1 mt-auto group/link"
                     >
                        Leer artículo <ArrowRight className="w-3.5 h-3.5 group-hover/link:translate-x-1 transition-transform" />
                     </a>
                  </div>
               </div>
             ))
           ) : (
             <div className="col-span-3 text-center py-16 bg-white rounded-2xl border border-slate-100 border-dashed">
                <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-3">
                   <BookOpen className="w-6 h-6 text-slate-300" />
                </div>
                <h4 className="text-slate-900 font-medium">Sin novedades</h4>
                <p className="text-slate-400 text-sm">No hay publicaciones recientes en el blog.</p>
             </div>
           )}
        </div>
      </motion.div>

      {/* Full History Modal */}
      <Dialog open={showAllHistory} onOpenChange={setShowAllHistory}>
        <DialogContent className="max-w-2xl bg-white rounded-3xl border-slate-100 shadow-2xl h-[80vh] flex flex-col">
           <DialogHeader className="border-b border-slate-100 pb-4">
              <DialogTitle className="flex items-center gap-2 text-xl font-bold text-slate-800">
                 <Activity className="w-5 h-5 text-blue-600" />
                 Historial de Actividad Completo
              </DialogTitle>
              <DialogDescription>
                 Registro detallado de todas las acciones recientes en la plataforma.
              </DialogDescription>
           </DialogHeader>
           
           <div className="flex-1 overflow-hidden py-4">
               {historyLoading ? (
                  <div className="flex items-center justify-center h-full text-slate-400">
                     Cargando...
                  </div>
               ) : (
                 <div className="h-full overflow-y-auto pr-2 space-y-6 pl-2">
                    {activities.map((act, i) => (
                      <div key={i} className="flex gap-4 items-start relative pb-6 border-l-2 border-slate-100 pl-6 last:border-0 last:pb-0">
                        <div className={`absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-white border-2 border-${act.color}-200 flex items-center justify-center`}>
                          <div className={`w-1.5 h-1.5 rounded-full bg-${act.color}-500`} />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                             <p className="text-sm font-bold text-slate-800">
                               {act.title}
                             </p>
                             <Badge variant="outline" className="text-[10px] bg-slate-50">
                               {new Date(act.date).toLocaleDateString()}
                             </Badge>
                          </div>
                          
                          <div className="text-sm text-slate-600 mt-0.5">
                             {act.type === 'patient' ? (
                                <span>Registrado: <PatientLink patientId={act.patientId} name={act.patientName} /></span>
                             ) : (
                                <div className="flex flex-col">
                                   <span>Paciente: <PatientLink patientId={act.patientId} name={act.patientName} /></span>
                                   {act.detail && <span className="text-slate-500 italic text-xs">{act.detail}</span>}
                                </div>
                             )}
                          </div>

                          <p className="text-xs text-slate-400 mt-2 flex items-center gap-1 font-mono">
                            <Clock className="w-3 h-3" />
                            {new Date(act.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            <span className="mx-1">•</span>
                            {timeAgo(act.date)}
                          </p>
                        </div>
                      </div>
                    ))}
                 </div>
               )}
           </div>

           <div className="pt-4 border-t border-slate-100 flex justify-end">
              <Button onClick={() => setShowAllHistory(false)} variant="outline">
                Cerrar
              </Button>
           </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};

export default MainDashboard;
