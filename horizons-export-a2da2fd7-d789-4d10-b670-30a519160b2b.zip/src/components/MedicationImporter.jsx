
import React, { useState, useRef } from 'react';
import { Upload, Database, FileSpreadsheet, CheckCircle2, AlertCircle, RefreshCw, X } from 'lucide-react';
import * as XLSX from 'xlsx';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Progress } from '@/components/ui/progress';

const MedicationImporter = () => {
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [previewData, setPreviewData] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState('idle'); // idle, uploading, success, error
  const [stats, setStats] = useState({ total: 0, inserted: 0, errors: 0 });

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (!selectedFile.name.endsWith('.xlsx') && !selectedFile.name.endsWith('.xls')) {
        toast({
          title: "Formato incorrecto",
          description: "Por favor subí un archivo Excel (.xlsx o .xls)",
          variant: "destructive"
        });
        return;
      }
      setFile(selectedFile);
      readExcel(selectedFile);
      setUploadStatus('idle');
      setUploadProgress(0);
    }
  };

  const readExcel = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(sheet);
        
        // Basic validation of columns
        if (jsonData.length > 0) {
          const headers = Object.keys(jsonData[0]).map(h => h.toLowerCase());
          // Flexible matching for typical medication headers
          const hasName = headers.some(h => h.includes('nombre') || h.includes('medicamento') || h.includes('name'));
          
          if (!hasName) {
            toast({
              title: "Columnas no reconocidas",
              description: "El Excel debe tener al menos una columna de 'Nombre' o 'Medicamento'.",
              variant: "destructive"
            });
            setFile(null);
            setPreviewData([]);
            return;
          }
          setPreviewData(jsonData.slice(0, 5)); // Preview first 5 rows
          setStats({ ...stats, total: jsonData.length });
        }
      } catch (error) {
        console.error("Error reading excel:", error);
        toast({
          title: "Error de lectura",
          description: "No se pudo procesar el archivo Excel.",
          variant: "destructive"
        });
      }
    };
    reader.readAsBinaryString(file);
  };

  const mapRowToMedication = (row) => {
    // Helper to find value case-insensitively
    const getValue = (keys) => {
      const rowKeys = Object.keys(row);
      for (const key of keys) {
        const foundKey = rowKeys.find(k => k.toLowerCase().includes(key.toLowerCase()));
        if (foundKey) return row[foundKey];
      }
      return '';
    };

    return {
      name: getValue(['nombre', 'medicamento', 'name', 'producto']) || 'Sin Nombre',
      active_ingredients: getValue(['droga', 'principio', 'activo', 'ingredients', 'generico']),
      presentation: getValue(['presentacion', 'dosage', 'dosis', 'forma', 'concentracion']),
      laboratory: getValue(['laboratorio', 'lab', 'marca', 'fabricante']),
      category: getValue(['categoria', 'tipo', 'clase', 'rubro']),
      created_at: new Date().toISOString()
    };
  };

  const handleUpload = async () => {
    if (!file) return;

    setIsProcessing(true);
    setUploadStatus('uploading');
    setUploadProgress(0);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = e.target.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(sheet);

        let insertedCount = 0;
        let errorCount = 0;
        const total = jsonData.length;
        const batchSize = 50;

        for (let i = 0; i < total; i += batchSize) {
          const batch = jsonData.slice(i, i + batchSize).map(mapRowToMedication);
          
          const { error } = await supabase
            .from('medications')
            .insert(batch);

          if (error) {
            console.error('Batch error:', error);
            errorCount += batch.length;
          } else {
            insertedCount += batch.length;
          }

          const progress = Math.round(((i + batch.length) / total) * 100);
          setUploadProgress(progress);
        }

        setStats({ total, inserted: insertedCount, errors: errorCount });
        setUploadStatus(errorCount === 0 ? 'success' : 'partial'); // partial if some failed
        
        toast({
          title: "Importación Finalizada",
          description: `Se importaron ${insertedCount} medicamentos correctamente.`,
          className: "bg-green-50 border-green-200 text-green-800"
        });

      } catch (error) {
        console.error('Import error:', error);
        setUploadStatus('error');
        toast({
          title: "Error Crítico",
          description: "Falló el proceso de importación.",
          variant: "destructive"
        });
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsBinaryString(file);
  };

  const resetImporter = () => {
    setFile(null);
    setPreviewData([]);
    setUploadStatus('idle');
    setUploadProgress(0);
    setStats({ total: 0, inserted: 0, errors: 0 });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Importador de Medicamentos</h1>
            <p className="text-slate-500 text-sm">Cargá masivamente tu vademécum desde archivos Excel.</p>
          </div>
        </div>
        <Button variant="outline" onClick={resetImporter} disabled={isProcessing}>
          <RefreshCw className={`w-4 h-4 mr-2 ${isProcessing ? 'animate-spin' : ''}`} />
          Reiniciar
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload Area */}
        <div className="space-y-6">
          <div 
            className={`
              border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all bg-white
              ${file ? 'border-emerald-200 bg-emerald-50/30' : 'border-slate-300 hover:border-emerald-400 hover:bg-slate-50'}
            `}
          >
            {file ? (
              <div className="flex flex-col items-center animate-in fade-in zoom-in duration-300">
                <FileSpreadsheet className="w-16 h-16 text-emerald-500 mb-4" />
                <h3 className="text-lg font-bold text-slate-800 mb-1">{file.name}</h3>
                <p className="text-sm text-slate-500 mb-6">{(file.size / 1024).toFixed(2)} KB</p>
                
                {uploadStatus === 'idle' && (
                  <div className="flex gap-3">
                    <Button variant="outline" onClick={resetImporter} className="border-red-200 text-red-600 hover:bg-red-50">
                      <X className="w-4 h-4 mr-2" /> Cancelar
                    </Button>
                    <Button onClick={handleUpload} className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20">
                      <Database className="w-4 h-4 mr-2" /> Iniciar Importación
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                   <Upload className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-bold text-slate-700 mb-2">Arrastrá tu archivo aquí</h3>
                <p className="text-sm text-slate-500 mb-6 max-w-xs mx-auto">
                  Soporta archivos .xlsx y .xls. Asegurate de que tenga columnas como "Nombre", "Droga", "Presentación".
                </p>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".xlsx, .xls"
                  className="hidden"
                />
                <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="border-emerald-200 text-emerald-700 hover:bg-emerald-50">
                  Seleccionar Archivo
                </Button>
              </>
            )}

            {uploadStatus !== 'idle' && (
              <div className="w-full mt-6 space-y-2">
                <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1">
                  <span>Progreso</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2 bg-slate-100" indicatorClassName="bg-emerald-500" />
                <p className="text-xs text-slate-400 mt-2">
                  {uploadStatus === 'uploading' && 'Procesando e insertando datos...'}
                  {uploadStatus === 'success' && '¡Importación completada con éxito!'}
                  {uploadStatus === 'error' && 'Hubo un error durante la importación.'}
                </p>
              </div>
            )}
          </div>

          {/* Guidelines */}
          <div className="bg-blue-50 p-5 rounded-xl border border-blue-100 text-sm text-blue-800">
            <h4 className="font-bold flex items-center gap-2 mb-2">
              <AlertCircle className="w-4 h-4" /> Estructura Recomendada
            </h4>
            <ul className="list-disc list-inside space-y-1 text-blue-700/80 pl-1">
              <li>Columna <strong>Nombre</strong> (Obligatoria): Nombre comercial del medicamento.</li>
              <li>Columna <strong>Droga/Principio Activo</strong>: Componentes genéricos.</li>
              <li>Columna <strong>Presentación/Dosis</strong>: Ej. "Comp 500mg".</li>
              <li>Columna <strong>Laboratorio</strong>: Fabricante.</li>
            </ul>
          </div>
        </div>

        {/* Results / Preview */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden flex flex-col h-full">
          <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <h3 className="font-bold text-slate-700">
              {uploadStatus === 'success' ? 'Resumen de Importación' : 'Vista Previa (Primeras 5 filas)'}
            </h3>
            {stats.total > 0 && (
              <span className="text-xs bg-slate-200 text-slate-600 px-2 py-1 rounded-full font-medium">
                Total: {stats.total} registros
              </span>
            )}
          </div>
          
          <div className="flex-1 p-4 overflow-auto min-h-[300px]">
            {uploadStatus === 'success' ? (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center animate-bounce">
                  <CheckCircle2 className="w-10 h-10 text-green-600" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-slate-800">¡Todo Listo!</h2>
                  <p className="text-slate-500">Se han añadido los medicamentos a la base de datos.</p>
                </div>
                <div className="grid grid-cols-2 gap-4 w-full max-w-xs mt-4">
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <div className="text-2xl font-bold text-emerald-600">{stats.inserted}</div>
                    <div className="text-xs text-slate-500 uppercase font-bold">Insertados</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <div className="text-2xl font-bold text-red-500">{stats.errors}</div>
                    <div className="text-xs text-slate-500 uppercase font-bold">Errores</div>
                  </div>
                </div>
              </div>
            ) : previewData.length > 0 ? (
              <div className="space-y-3">
                {previewData.map((row, idx) => {
                  const mapped = mapRowToMedication(row);
                  return (
                    <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs space-y-1">
                      <div className="flex justify-between font-bold text-slate-700">
                        <span>{mapped.name || 'Sin Nombre'}</span>
                        <span className="text-slate-400 font-normal">{idx + 1}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-slate-500">
                        <div><span className="font-semibold">Droga:</span> {mapped.active_ingredients || '-'}</div>
                        <div><span className="font-semibold">Lab:</span> {mapped.laboratory || '-'}</div>
                        <div><span className="font-semibold">Pres:</span> {mapped.presentation || '-'}</div>
                      </div>
                    </div>
                  );
                })}
                <div className="text-center text-xs text-slate-400 italic pt-2">
                  ... y {stats.total - 5} registros más
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 text-sm">
                <FileSpreadsheet className="w-10 h-10 mb-2 opacity-20" />
                <p>No hay datos para mostrar aún.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MedicationImporter;
