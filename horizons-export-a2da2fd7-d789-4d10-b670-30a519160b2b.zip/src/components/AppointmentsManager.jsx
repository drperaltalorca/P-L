
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, MessageSquare } from 'lucide-react';
import MedicalCalendar from '@/components/MedicalCalendar';
import DoctorCommunication from '@/components/DoctorCommunication';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const AppointmentsManager = () => {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -translate-y-1/2 translate-x-1/4 pointer-events-none" />
        <div className="relative z-10">
          <h1 className="text-3xl font-bold mb-2">Gestión de Turnos y Comunicación</h1>
          <p className="text-violet-100">Agenda interactiva, cirugías y canal directo entre doctores.</p>
        </div>
      </div>

      <Tabs defaultValue="calendar" className="space-y-6">
        <TabsList className="bg-white p-1 rounded-xl border border-slate-100 w-fit">
          <TabsTrigger value="calendar" className="gap-2 px-6">
             <Calendar className="w-4 h-4" /> Calendario & Cirugías
          </TabsTrigger>
          <TabsTrigger value="communication" className="gap-2 px-6">
             <MessageSquare className="w-4 h-4" /> Consultas & Chat Dr.
          </TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="animate-in fade-in-50">
           <MedicalCalendar />
        </TabsContent>

        <TabsContent value="communication" className="animate-in fade-in-50">
           <DoctorCommunication />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AppointmentsManager;
