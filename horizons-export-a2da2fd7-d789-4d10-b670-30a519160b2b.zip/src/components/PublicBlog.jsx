
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Helmet } from 'react-helmet';
import { 
  Calendar, 
  Clock, 
  ArrowLeft, 
  Search, 
  ChevronRight, 
  Share2,
  User,
  Loader2,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const PublicBlog = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPost, setSelectedPost] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Initial load and URL handling
  useEffect(() => {
    // Check for permalink via query param
    const params = new URLSearchParams(window.location.search);
    const slug = params.get('post');
    
    if (slug) {
      fetchPostBySlug(slug);
    } else {
      fetchPosts();
    }

    // Listen for browser back/forward buttons
    const handlePopState = () => {
      const currentParams = new URLSearchParams(window.location.search);
      const currentSlug = currentParams.get('post');
      if (currentSlug) {
        fetchPostBySlug(currentSlug); 
      } else {
        setSelectedPost(null);
        if (posts.length === 0) fetchPosts();
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []); // Run once on mount

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('status', 'published')
        .order('published_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPostBySlug = async (slug) => {
    try {
      setLoading(true);
      
      // First check if we already have it in our list to save a request
      const cachedPost = posts.find(p => p.slug === slug);
      if (cachedPost) {
        setSelectedPost(cachedPost);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('slug', slug)
        .eq('status', 'published')
        .maybeSingle(); 
        
      if (error) throw error;
      
      if (data) {
        setSelectedPost(data);
      } else {
        console.warn('Post not found:', slug);
        setSelectedPost(null);
        const newUrl = new URL(window.location);
        newUrl.searchParams.delete('post');
        window.history.replaceState({}, '', newUrl);
        if (posts.length === 0) fetchPosts();
      }
    } catch (error) {
      console.error('Error fetching post by slug:', error);
      setSelectedPost(null);
      if (posts.length === 0) fetchPosts();
    } finally {
      setLoading(false);
    }
  };

  const filteredPosts = posts.filter(post => 
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (post.excerpt && post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handlePostClick = (post) => {
    setSelectedPost(post);
    // Update URL without reload to allow sharing if user copies link
    const newUrl = new URL(window.location);
    newUrl.searchParams.set('post', post.slug);
    window.history.pushState({}, '', newUrl);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    setSelectedPost(null);
    // Remove query param
    const newUrl = new URL(window.location);
    newUrl.searchParams.delete('post');
    window.history.pushState({}, '', newUrl);
    
    // If we came directly to a post and don't have the list loaded, load it now
    if (posts.length === 0) {
      fetchPosts();
    }
  };

  const handleSpecificPostClick = (slug) => {
    // This will trigger fetchPostBySlug due to the URL change
    const newUrl = new URL(window.location);
    newUrl.searchParams.set('post', slug);
    window.history.pushState({}, '', newUrl);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    fetchPostBySlug(slug); // Manually trigger fetch in case history.pushState doesn't trigger effect
  };

  if (loading && !posts.length && !selectedPost) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (selectedPost) {
    return <BlogPostView post={selectedPost} onBack={handleBack} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Helmet>
        <title>Blog Médico | Artículos y Novedades</title>
        <meta name="description" content="Lee nuestros últimos artículos sobre salud, medicina y bienestar." />
      </Helmet>

      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.reload()}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
              M
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-800">Blog Médico</span>
          </div>
          <Button variant="ghost" asChild>
             <a href="/" className="text-slate-600 hover:text-blue-600">Volver al Portal</a>
          </Button>
        </div>
      </header>

      {/* Hero / Search */}
      <div className="bg-blue-600 py-16 px-4 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80')] bg-cover bg-center"></div>
        <div className="relative z-10 max-w-2xl mx-auto space-y-6">
          <h1 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight">
            Novedades y Artículos de Salud
          </h1>
          <p className="text-blue-100 text-lg">
            Información confiable y actualizada para tu bienestar.
          </p>
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <Input 
              type="text" 
              placeholder="Buscar artículos..." 
              className="pl-10 h-12 rounded-full border-0 shadow-lg text-slate-900 bg-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          {/* New button for specific post */}
          <Button 
            variant="secondary" 
            onClick={() => handleSpecificPostClick('el-gran-salto-los-isrs-explicados-con-pistas-de-hot-wheels')}
            className="mt-6 bg-white text-blue-600 hover:bg-blue-50 hover:text-blue-700 transition-colors gap-2"
          >
            <ExternalLink className="w-4 h-4" /> Leer: El Gran Salto
          </Button>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-5xl mx-auto px-4 py-12">
        {loading && posts.length === 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white rounded-2xl h-96 animate-pulse shadow-sm border border-slate-100">
                <div className="h-48 bg-slate-200 rounded-t-2xl"></div>
                <div className="p-6 space-y-4">
                  <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                  <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map(post => (
              <article 
                key={post.id} 
                className="group bg-white rounded-2xl shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-slate-100 overflow-hidden flex flex-col cursor-pointer"
                onClick={() => handlePostClick(post)}
              >
                <div className="h-48 overflow-hidden relative bg-slate-100">
                   {post.featured_image ? (
                     <img 
                       src={post.featured_image} 
                       alt={post.title} 
                       className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500" 
                     />
                   ) : (
                     <div className="w-full h-full flex items-center justify-center text-slate-300">
                       <span className="text-4xl font-light">Aa</span>
                     </div>
                   )}
                   <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500 mb-3">
                    <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded-full">
                      Artículo
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(post.published_at || post.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-slate-800 mb-3 line-clamp-2 group-hover:text-blue-600 transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-slate-600 text-sm line-clamp-3 mb-4 flex-1">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center text-blue-600 text-sm font-semibold group-hover:translate-x-1 transition-transform">
                    Leer más <ChevronRight className="w-4 h-4 ml-1" />
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
             <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-slate-400" />
             </div>
             <h3 className="text-xl font-bold text-slate-900">No se encontraron artículos</h3>
             <p className="text-slate-500 mt-2">Intenta con otra búsqueda o vuelve más tarde.</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-12 mt-12">
        <div className="max-w-5xl mx-auto px-4 text-center">
           <p className="text-slate-500 text-sm">© {new Date().getFullYear()} Portal Médico. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  );
};

const BlogPostView = ({ post, onBack }) => {
  if (!post) return null;

  return (
    <div className="min-h-screen bg-white">
      <Helmet>
        <title>{post.title} | Blog Médico</title>
        {post.excerpt && <meta name="description" content={post.excerpt} />}
      </Helmet>

      {/* Reading Progress Bar (Simple) */}
      <div className="fixed top-0 left-0 w-full h-1 bg-slate-100 z-50">
        <div className="h-full bg-blue-600 w-full origin-left animate-[grow_1s_ease-out]"></div>
      </div>

      {/* Nav */}
      <nav className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-slate-100 z-40 px-4 h-16 flex items-center">
        <div className="max-w-3xl mx-auto w-full flex items-center justify-between">
          <Button variant="ghost" onClick={onBack} className="gap-2 text-slate-600 hover:text-slate-900 -ml-4">
            <ArrowLeft className="w-4 h-4" /> Volver
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" size="icon" className="text-slate-500 hover:text-blue-600">
               <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </nav>

      <article className="max-w-3xl mx-auto px-4 py-8 md:py-12">
        {/* Header */}
        <header className="mb-8 md:mb-12 space-y-6">
           <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500">
             <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full font-medium text-xs">
               Novedades
             </span>
             <span className="flex items-center gap-1">
               <Calendar className="w-4 h-4" />
               {new Date(post.published_at || post.created_at).toLocaleDateString(undefined, {
                 weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
               })}
             </span>
             <span className="flex items-center gap-1">
               <Clock className="w-4 h-4" />
               5 min de lectura
             </span>
           </div>
           
           <h1 className="text-3xl md:text-5xl font-extrabold text-slate-900 leading-tight">
             {post.title}
           </h1>

           {post.excerpt && (
             <p className="text-xl text-slate-600 leading-relaxed font-light">
               {post.excerpt}
             </p>
           )}

           <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
             <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center">
               <User className="w-5 h-5 text-slate-500" />
             </div>
             <div>
               <div className="font-bold text-slate-900 text-sm">Equipo Médico</div>
               <div className="text-xs text-slate-500">Editor Jefe</div>
             </div>
           </div>
        </header>

        {/* Featured Image */}
        {post.featured_image && (
          <div className="mb-12 rounded-2xl overflow-hidden shadow-lg aspect-video relative">
            <img 
              src={post.featured_image} 
              alt={post.title} 
              className="w-full h-full object-cover"
            />
          </div>
        )}

        {/* Content Body */}
        <div className="prose prose-lg prose-slate prose-blue mx-auto max-w-none prose-img:rounded-xl prose-img:shadow-lg prose-video:aspect-video prose-headings:font-bold">
          <div 
            className="whitespace-pre-wrap leading-relaxed"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
        </div>

      </article>
    </div>
  );
};

export default PublicBlog;
