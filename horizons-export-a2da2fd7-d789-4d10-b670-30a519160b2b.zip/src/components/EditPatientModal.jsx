
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, Upload, X, Plus, Trash2, Save, User, ListPlus, ShieldCheck, CreditCard } from "lucide-react";
import FormField from '@/components/FormField';
import SelectField from '@/components/SelectField';
import TextAreaField from '@/components/TextAreaField';

const EditPatientModal = ({ patient, isOpen, onClose, onUpdate }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("identification");
  
  // Photo State
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);

  // Form State
  const [formData, setFormData] = useState({});
  const [customFields, setCustomFields] = useState([]);

  // Initialize form data when patient changes
  useEffect(() => {
    if (patient && isOpen) {
      // Merge extended_data with top-level fields to ensure we have everything
      const extended = patient.extended_data || {};
      
      setFormData({
        ...extended,
        name: patient.name, // Ensure top-level name takes precedence
        sex: extended.sex || (patient.gender === 'Masculino' ? 'male' : patient.gender === 'Femenino' ? 'female' : 'other'),
        // Keep other fields if they exist in extended, otherwise default to empty
        historyNumber: extended.historyNumber || '',
        socialSecurityNumber: extended.socialSecurityNumber || '',
        openingDate: extended.openingDate || '',
        medicalProvider: extended.medicalProvider || '',
        healthInsurance: extended.healthInsurance || '', // New field
        affiliateNumber: extended.affiliateNumber || '', // New field
        birthDate: extended.birthDate || '',
        address: extended.address || '',
        phone: extended.phone || '',
        maritalStatus: extended.maritalStatus || '',
        education: extended.education || '',
        profession: extended.profession || '',
        employmentStatus: extended.employmentStatus || '',
        laborRisks: extended.laborRisks || '',
        riskFactors: extended.riskFactors || '',
        toxicHabits: extended.toxicHabits || '',
        drugAllergies: extended.drugAllergies || '',
        personalHistory: extended.personalHistory || '',
        surgicalInterventions: extended.surgicalInterventions || '',
        immunizationStatus: extended.immunizationStatus || '',
        chronicMedications: extended.chronicMedications || '',
        bloodPressure: extended.bloodPressure || '',
        weight: extended.weight || '',
        height: extended.height || '',
        gynecologicalControl: extended.gynecologicalControl || '',
        lastBreastControl: extended.lastBreastControl || '',
      });

      // Load custom fields if they exist
      if (extended.custom_fields && Array.isArray(extended.custom_fields)) {
        setCustomFields(extended.custom_fields);
      } else {
        setCustomFields([]);
      }

      setPhotoPreview(patient.photo_url);
      setPhotoFile(null);
    }
  }, [patient, isOpen]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
  };

  // Custom Fields Logic
  const addCustomField = () => {
    setCustomFields([...customFields, { key: '', value: '' }]);
  };

  const removeCustomField = (index) => {
    const newFields = [...customFields];
    newFields.splice(index, 1);
    setCustomFields(newFields);
  };

  const updateCustomField = (index, field, value) => {
    const newFields = [...customFields];
    newFields[index][field] = value;
    setCustomFields(newFields);
  };

  const uploadPhoto = async (file) => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('patient-photos')
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('patient-photos')
      .getPublicUrl(filePath);

    return data.publicUrl;
  };

  const handleSave = async () => {
    // Validation
    if (!formData.name || !formData.socialSecurityNumber) {
      toast({
        title: "Faltan datos obligatorios",
        description: "El Nombre y el DNI son requeridos.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      let photoUrl = photoPreview;
      
      // Upload new photo if selected
      if (photoFile) {
        photoUrl = await uploadPhoto(photoFile);
      } else if (!photoPreview && patient.photo_url) {
         // Logic to remove photo if needed, or just set to null
         photoUrl = null;
      }

      // Calculate new age
      // Current year needs to be 2025 as per current date constraint
      const birthDate = new Date(formData.birthDate);
      const age = formData.birthDate 
        ? 2025 - birthDate.getFullYear() 
        : patient.age;

      // Prepare updates
      const genderMap = {
        'male': 'Masculino',
        'female': 'Femenino',
        'other': 'Otro'
      };

      const finalCustomFields = customFields.filter(f => f.key.trim() !== '');

      const updates = {
        name: formData.name,
        gender: genderMap[formData.sex] || 'Otro',
        age: age,
        photo_url: photoUrl,
        // Update medical_conditions array based on text field changes (simple sync)
        medical_conditions: formData.personalHistory ? [formData.personalHistory] : [],
        medications: formData.chronicMedications ? [formData.chronicMedications] : [],
        
        // Full data dump to extended_data
        extended_data: {
          ...formData,
          custom_fields: finalCustomFields
        }
      };

      const { error } = await supabase
        .from('patients')
        .update(updates)
        .eq('id', patient.id);

      if (error) throw error;

      toast({
        title: "Paciente actualizado",
        description: "Los cambios se han guardado correctamente.",
        className: "bg-green-50 border-green-200 text-green-800",
      });

      onUpdate(); // Refresh list
      onClose();

    } catch (error) {
      console.error('Error updating patient:', error);
      toast({
        title: "Error al guardar",
        description: error.message || "No se pudieron guardar los cambios.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sexOptions = [
    { value: 'male', label: 'Masculino' },
    { value: 'female', label: 'Femenino' },
    { value: 'other', label: 'Otro' }
  ];

  const maritalStatusOptions = [
    { value: 'single', label: 'Soltero/a' },
    { value: 'married', label: 'Casado/a' },
    { value: 'divorced', label: 'Divorciado/a' },
    { value: 'widowed', label: 'Viudo/a' }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col p-0 gap-0 bg-white">
        <DialogHeader className="p-6 pb-2 bg-white border-b border-slate-100 rounded-t-2xl">
          <DialogTitle className="text-xl font-bold text-slate-800">Editar Paciente</DialogTitle>
          <DialogDescription>Modificá los datos del paciente y guardá los cambios.</DialogDescription>
        </DialogHeader>

        {/* Replaced ScrollArea with a div for scrolling */}
        <div className="flex-1 overflow-y-auto px-6 py-4 bg-white">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5 mb-6 p-1 bg-slate-200/50 rounded-xl">
              <TabsTrigger value="identification" className="rounded-lg text-xs md:text-sm">Identificación</TabsTrigger>
              <TabsTrigger value="demographics" className="rounded-lg text-xs md:text-sm">Demografía</TabsTrigger>
              <TabsTrigger value="clinical" className="rounded-lg text-xs md:text-sm">Clínica</TabsTrigger>
              <TabsTrigger value="measurements" className="rounded-lg text-xs md:text-sm">Mediciones</TabsTrigger>
              <TabsTrigger value="custom" className="rounded-lg text-xs md:text-sm">Extras</TabsTrigger>
            </TabsList>

            {/* IDENTIFICATION TAB */}
            <TabsContent value="identification" className="space-y-6 animate-in fade-in-50 duration-300">
              <div className="flex flex-col md:flex-row gap-6">
                 {/* Photo Section */}
                 <div className="flex flex-col items-center space-y-3 p-4 bg-white rounded-2xl border border-slate-200 shadow-sm w-full md:w-1/3 h-fit">
                    <div className="relative group w-32 h-32">
                      <div className="w-32 h-32 rounded-full overflow-hidden bg-slate-100 border-4 border-white shadow-md">
                        {photoPreview ? (
                          <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-400">
                            <User className="w-12 h-12" />
                          </div>
                        )}
                      </div>
                      <label className="absolute bottom-0 right-0 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full cursor-pointer shadow-lg transition-all hover:scale-110">
                        <Upload className="w-4 h-4" />
                        <input type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
                      </label>
                      {photoPreview && (
                        <button 
                          onClick={removePhoto}
                          className="absolute top-0 right-0 p-1.5 bg-red-100 text-red-600 rounded-full hover:bg-red-200 transition-colors shadow-sm"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <span className="text-xs text-slate-400">Click en el ícono azul para cambiar foto</span>
                 </div>

                 {/* Basic Inputs */}
                 <div className="flex-1 grid grid-cols-1 gap-4">
                    <FormField
                      label="Nombre Completo *"
                      value={formData.name || ''}
                      onChange={(v) => handleInputChange('name', v)}
                      placeholder="Nombre Apellido"
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        label="DNI / Documento *"
                        value={formData.socialSecurityNumber || ''}
                        onChange={(v) => handleInputChange('socialSecurityNumber', v)}
                      />
                      <FormField
                        label="N° Historia Clínica"
                        value={formData.historyNumber || ''}
                        onChange={(v) => handleInputChange('historyNumber', v)}
                      />
                    </div>
                    
                    {/* New Insurance Inputs in Modal */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 grid grid-cols-2 gap-4">
                      <div className="col-span-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" /> Datos de Cobertura
                      </div>
                      <FormField
                        label="Obra Social"
                        value={formData.healthInsurance || ''}
                        onChange={(v) => handleInputChange('healthInsurance', v)}
                        placeholder="Ej. OSDE"
                      />
                      <FormField
                        label="N° Afiliado"
                        value={formData.affiliateNumber || ''}
                        onChange={(v) => handleInputChange('affiliateNumber', v)}
                        placeholder="N° Credencial"
                      />
                    </div>

                    <FormField
                      label="Médico Responsable"
                      value={formData.medicalProvider || ''}
                      onChange={(v) => handleInputChange('medicalProvider', v)}
                    />
                 </div>
              </div>
            </TabsContent>

            {/* DEMOGRAPHICS TAB */}
            <TabsContent value="demographics" className="space-y-4 animate-in fade-in-50 duration-300">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-5">
                <FormField
                  label="Fecha de Nacimiento"
                  type="date"
                  value={formData.birthDate || ''}
                  onChange={(v) => handleInputChange('birthDate', v)}
                />
                <SelectField
                  label="Sexo"
                  value={formData.sex || ''}
                  onChange={(v) => handleInputChange('sex', v)}
                  options={sexOptions}
                />
                <FormField
                  label="Dirección"
                  value={formData.address || ''}
                  onChange={(v) => handleInputChange('address', v)}
                  className="md:col-span-2"
                />
                <FormField
                  label="Teléfono"
                  value={formData.phone || ''}
                  onChange={(v) => handleInputChange('phone', v)}
                />
                <SelectField
                  label="Estado Civil"
                  value={formData.maritalStatus || ''}
                  onChange={(v) => handleInputChange('maritalStatus', v)}
                  options={maritalStatusOptions}
                />
                <FormField
                  label="Ocupación / Profesión"
                  value={formData.profession || ''}
                  onChange={(v) => handleInputChange('profession', v)}
                />
                <FormField
                  label="Educación"
                  value={formData.education || ''}
                  onChange={(v) => handleInputChange('education', v)}
                />
              </div>
            </TabsContent>

            {/* CLINICAL TAB */}
            <TabsContent value="clinical" className="space-y-4 animate-in fade-in-50 duration-300">
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-5">
                  <TextAreaField
                    label="Antecedentes Personales / Condiciones"
                    value={formData.personalHistory || ''}
                    onChange={(v) => handleInputChange('personalHistory', v)}
                    className="md:col-span-2"
                  />
                  <TextAreaField
                    label="Alergias (Medicamentos/Otros)"
                    value={formData.drugAllergies || ''}
                    onChange={(v) => handleInputChange('drugAllergies', v)}
                    highlight
                  />
                  <TextAreaField
                    label="Medicación Crónica"
                    value={formData.chronicMedications || ''}
                    onChange={(v) => handleInputChange('chronicMedications', v)}
                  />
                  <TextAreaField
                    label="Factores de Riesgo"
                    value={formData.riskFactors || ''}
                    onChange={(v) => handleInputChange('riskFactors', v)}
                  />
                  <TextAreaField
                    label="Hábitos (Tabaco, Alcohol)"
                    value={formData.toxicHabits || ''}
                    onChange={(v) => handleInputChange('toxicHabits', v)}
                  />
                  <TextAreaField
                    label="Cirugías Previas"
                    value={formData.surgicalInterventions || ''}
                    onChange={(v) => handleInputChange('surgicalInterventions', v)}
                  />
               </div>
            </TabsContent>

            {/* MEASUREMENTS TAB */}
            <TabsContent value="measurements" className="space-y-4 animate-in fade-in-50 duration-300">
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-5">
                 <div className="grid grid-cols-2 gap-4">
                    <FormField
                      label="Peso (kg)"
                      value={formData.weight || ''}
                      onChange={(v) => handleInputChange('weight', v)}
                    />
                    <FormField
                      label="Altura (cm)"
                      value={formData.height || ''}
                      onChange={(v) => handleInputChange('height', v)}
                    />
                 </div>
                 <FormField
                    label="Presión Arterial"
                    value={formData.bloodPressure || ''}
                    onChange={(v) => handleInputChange('bloodPressure', v)}
                 />
                 <FormField
                    label="Control Ginecológico"
                    value={formData.gynecologicalControl || ''}
                    onChange={(v) => handleInputChange('gynecologicalControl', v)}
                 />
                 <FormField
                    label="Control Mamario (Eco + Mamo)"
                    value={formData.lastBreastControl || ''}
                    onChange={(v) => handleInputChange('lastBreastControl', v)}
                 />
               </div>
            </TabsContent>

            {/* CUSTOM FIELDS TAB */}
            <TabsContent value="custom" className="space-y-4 animate-in fade-in-50 duration-300">
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 min-h-[300px]">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-sm font-medium text-slate-500">Campos Personalizados</h3>
                    <Button onClick={addCustomField} size="sm" variant="outline" className="border-dashed border-blue-300 text-blue-600 bg-blue-50 hover:bg-blue-100">
                      <Plus className="w-4 h-4 mr-1" /> Agregar Campo
                    </Button>
                  </div>
                  
                  {customFields.length === 0 ? (
                    <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                      <ListPlus className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-sm text-slate-400">No hay campos personalizados.</p>
                      <p className="text-xs text-slate-400">Agregá información extra específica para este paciente.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {customFields.map((field, index) => (
                        <div key={index} className="flex gap-3 items-start animate-in slide-in-from-left-5 duration-200">
                          <div className="w-1/3">
                            <input
                              type="text"
                              placeholder="Nombre del campo"
                              value={field.key}
                              onChange={(e) => updateCustomField(index, 'key', e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-lg p-2.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                            />
                          </div>
                          <div className="flex-1">
                            <input
                              type="text"
                              placeholder="Valor"
                              value={field.value}
                              onChange={(e) => updateCustomField(index, 'value', e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-lg p-2.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                            />
                          </div>
                          <button 
                            onClick={() => removeCustomField(index)}
                            className="p-2.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
               </div>
            </TabsContent>
          </Tabs>
        </div>

        <DialogFooter className="p-6 bg-white border-t border-slate-100 flex-col sm:flex-row gap-3 rounded-b-2xl">
          <Button variant="outline" onClick={onClose} disabled={loading} className="w-full sm:w-auto">
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={loading} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Guardando...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" /> Guardar Cambios
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditPatientModal;
