
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { 
  Plus, 
  Search, 
  FileText, 
  Edit3, 
  Trash2, 
  Globe, 
  Save, 
  ArrowLeft, 
  Image as ImageIcon,
  MoreVertical,
  Calendar,
  CheckCircle2,
  Clock,
  Eye,
  ExternalLink,
  Upload,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Link } from 'react-router-dom';
import RichTextEditor from '@/components/RichTextEditor';

const BlogManager = () => {
  const [view, setView] = useState('list'); // 'list' | 'editor'
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPost, setCurrentPost] = useState(null);
  const { toast } = useToast();

  // Fetch posts on mount
  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      toast({
        title: "Error al cargar posts",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNew = () => {
    setCurrentPost({
      title: '',
      slug: '',
      content: '', // HTML Content
      excerpt: '',
      status: 'draft',
      featured_image: ''
    });
    setView('editor');
  };

  const handleEdit = (post) => {
    setCurrentPost(post);
    setView('editor');
  };

  const handleDelete = async (id) => {
    try {
      const { error } = await supabase
        .from('blog_posts')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Post eliminado",
        description: "El artículo ha sido eliminado correctamente."
      });
      fetchPosts();
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el post.",
        variant: "destructive"
      });
    }
  };

  const handleSave = async (postData) => {
    try {
      // Basic validation
      if (!postData.title) {
        toast({ title: "El título es obligatorio", variant: "destructive" });
        return;
      }

      // Auto-generate slug if empty
      let slug = postData.slug;
      if (!slug) {
        slug = postData.title
          .toLowerCase()
          .trim()
          .replace(/[^\w\s-]/g, '')
          .replace(/[\s_-]+/g, '-')
          .replace(/^-+|-+$/g, '');
      }

      const payload = {
        ...postData,
        slug,
        updated_at: new Date().toISOString(),
      };

      if (postData.status === 'published' && !postData.published_at) {
        payload.published_at = new Date().toISOString();
      }

      let error;
      if (postData.id) {
        // Update
        const { error: updateError } = await supabase
          .from('blog_posts')
          .update(payload)
          .eq('id', postData.id);
        error = updateError;
      } else {
        // Insert
        const { error: insertError } = await supabase
          .from('blog_posts')
          .insert([payload]);
        error = insertError;
      }

      if (error) throw error;

      toast({
        title: "Guardado exitoso",
        description: `El post "${postData.title}" ha sido guardado.`
      });
      
      setView('list');
      fetchPosts();

    } catch (error) {
      toast({
        title: "Error al guardar",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  // Filter posts
  const filteredPosts = posts.filter(post => 
    post.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.status?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (view === 'editor') {
    return (
      <BlogEditor 
        initialData={currentPost} 
        onSave={handleSave} 
        onCancel={() => setView('list')} 
      />
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Globe className="w-6 h-6 text-blue-600" />
            Gestor de Blog
          </h1>
          <p className="text-slate-500">Administra tus artículos y publicaciones médicas</p>
        </div>
        <div className="flex items-center gap-2">
           <Button variant="outline" asChild className="gap-2">
             <a href="/blog" target="_blank" rel="noopener noreferrer">
               <ExternalLink className="w-4 h-4" /> Ver Blog Público
             </a>
           </Button>
           <Button onClick={handleCreateNew} className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
            <Plus className="w-4 h-4" />
            Nuevo Artículo
           </Button>
        </div>
      </div>

      {/* Filters & Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="md:col-span-3 border-slate-200 shadow-sm">
          <div className="p-4 flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar por título o estado..."
                className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="text-sm text-slate-500">
              {filteredPosts.length} posts encontrados
            </div>
          </div>
        </Card>
        
        <Card className="border-slate-200 shadow-sm bg-blue-50">
          <div className="p-4 flex flex-col justify-center h-full">
            <span className="text-xs font-semibold text-blue-600 uppercase tracking-wider">Publicados</span>
            <div className="text-2xl font-bold text-blue-900">
              {posts.filter(p => p.status === 'published').length}
            </div>
          </div>
        </Card>
      </div>

      {/* Posts List */}
      <div className="grid grid-cols-1 gap-4">
        {loading ? (
          <div className="text-center py-12 text-slate-400">Cargando artículos...</div>
        ) : filteredPosts.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-slate-200 border-dashed">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-slate-900">No hay posts todavía</h3>
            <p className="text-slate-500 mb-4">Comienza escribiendo tu primer artículo médico</p>
            <Button variant="outline" onClick={handleCreateNew}>Crear Post</Button>
          </div>
        ) : (
          filteredPosts.map((post) => (
            <div 
              key={post.id} 
              className="group bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row gap-6 items-start md:items-center"
            >
              {/* Thumbnail */}
              <div className="w-full md:w-48 h-32 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0 relative">
                {post.featured_image ? (
                  <img src={post.featured_image} alt={post.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-300">
                    <ImageIcon className="w-8 h-8" />
                  </div>
                )}
                <div className={`absolute top-2 left-2 px-2 py-1 rounded text-xs font-medium backdrop-blur-md 
                  ${post.status === 'published' ? 'bg-green-500/90 text-white' : 'bg-slate-500/90 text-white'}`}>
                  {post.status === 'published' ? 'Publicado' : 'Borrador'}
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 space-y-2">
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  {post.title}
                </h3>
                <p className="text-slate-500 text-sm line-clamp-2">
                  {post.excerpt || "Sin extracto..."}
                </p>
                <div className="flex items-center gap-4 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(post.created_at).toLocaleDateString()}
                  </span>
                  {post.published_at && (
                    <span className="flex items-center gap-1 text-green-600">
                      <Globe className="w-3 h-3" />
                      Online desde {new Date(post.published_at).toLocaleDateString()}
                    </span>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 w-full md:w-auto mt-4 md:mt-0 border-t md:border-t-0 pt-4 md:pt-0">
                <Button variant="ghost" size="sm" onClick={() => handleEdit(post)} className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  <Edit3 className="w-4 h-4 mr-2" /> Editar
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700 hover:bg-red-50">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta acción no se puede deshacer. Esto eliminará permanentemente el artículo "{post.title}".
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDelete(post.id)} className="bg-red-600 hover:bg-red-700">
                        Eliminar
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// Editor Sub-component
const BlogEditor = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState(initialData);
  const [previewMode, setPreviewMode] = useState(false);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleContentChange = (newContent) => {
    setFormData(prev => ({ ...prev, content: newContent }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleImageUpload = async (e) => {
    try {
      setUploading(true);
      const file = e.target.files[0];
      if (!file) return;

      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
      const filePath = `${fileName}`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('blog-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Get Public URL
      const { data: { publicUrl } } = supabase.storage
        .from('blog-images')
        .getPublicUrl(filePath);

      setFormData(prev => ({ ...prev, featured_image: publicUrl }));
      
      toast({
        title: "Imagen subida",
        description: "La imagen de portada se ha cargado correctamente.",
      });

    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: "Error al subir imagen",
        description: "Verifica que la imagen no sea demasiado grande.",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto animate-in slide-in-from-bottom-4 duration-500">
      <form onSubmit={handleSubmit}>
        {/* Editor Toolbar */}
        <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200 p-4 mb-6 flex justify-between items-center rounded-b-xl shadow-sm">
          <div className="flex items-center gap-4">
            <Button type="button" variant="ghost" onClick={onCancel} className="text-slate-500">
              <ArrowLeft className="w-4 h-4 mr-2" /> Volver
            </Button>
            <div className="h-6 w-px bg-slate-200"></div>
            <span className="text-sm font-medium text-slate-600">
              {formData.id ? 'Editando Post' : 'Nuevo Post'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setPreviewMode(!previewMode)}
              className={previewMode ? "bg-blue-50 border-blue-200 text-blue-700" : ""}
            >
              <Eye className="w-4 h-4 mr-2" />
              {previewMode ? 'Editar' : 'Vista Previa'}
            </Button>
            <Button 
              type="submit" 
              className={`gap-2 ${formData.status === 'published' ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}`}
            >
              <Save className="w-4 h-4" />
              {formData.status === 'published' ? 'Actualizar & Publicar' : 'Guardar Borrador'}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-6">
            
            {previewMode ? (
              <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm min-h-[600px] prose prose-slate max-w-none">
                {formData.featured_image && (
                   <img src={formData.featured_image} alt="Cover" className="w-full h-64 object-cover rounded-xl mb-6" />
                )}
                <h1 className="text-4xl font-bold text-slate-900 mb-4">{formData.title || "Sin título"}</h1>
                <div 
                  className="whitespace-pre-wrap text-slate-700 leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: formData.content || "Sin contenido..." }}
                />
              </div>
            ) : (
              <>
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
                  <div>
                    <input
                      type="text"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      placeholder="Título del artículo"
                      className="w-full text-3xl font-bold border-none p-0 focus:ring-0 placeholder:text-slate-300"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">Slug (URL amigable)</label>
                    <input
                      type="text"
                      name="slug"
                      value={formData.slug}
                      onChange={handleChange}
                      placeholder="titulo-del-articulo"
                      className="w-full text-sm text-slate-600 bg-slate-50 rounded px-2 py-1 mt-1 border border-slate-200 focus:border-blue-300 focus:outline-none"
                    />
                  </div>
                </div>

                <RichTextEditor 
                  initialContent={formData.content}
                  onChange={handleContentChange}
                />
              </>
            )}
          </div>

          {/* Sidebar Settings */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Publicación</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Estado</label>
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    className="w-full p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="draft">Borrador</option>
                    <option value="published">Publicado</option>
                    <option value="archived">Archivado</option>
                  </select>
                </div>
                
                <div className="pt-4 border-t border-slate-100">
                  <div className="flex justify-between items-center text-sm mb-2">
                    <span className="text-slate-500">Visibilidad:</span>
                    <span className="font-medium text-slate-900">
                      {formData.status === 'published' ? 'Público' : 'Privado'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-500">Fecha:</span>
                    <span className="font-medium text-slate-900">Inmediata</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Imagen Destacada</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-video bg-slate-100 rounded-lg overflow-hidden border border-slate-200 flex items-center justify-center relative group">
                  {formData.featured_image ? (
                    <img src={formData.featured_image} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-400">
                      <ImageIcon className="w-10 h-10 mb-2" />
                      <span className="text-xs">Sin imagen</span>
                    </div>
                  )}
                  
                  {/* Overlay for uploading */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <label className="cursor-pointer bg-white text-slate-900 px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-slate-100 transition-colors">
                      {uploading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4" />
                      )}
                      {uploading ? 'Subiendo...' : 'Subir Imagen'}
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleImageUpload}
                        disabled={uploading}
                      />
                    </label>
                  </div>
                </div>
                
                {/* Fallback URL input */}
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">O usar URL externa</label>
                  <input
                    type="text"
                    name="featured_image"
                    value={formData.featured_image}
                    onChange={handleChange}
                    placeholder="https://..."
                    className="w-full p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs text-slate-600"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Extracto</CardTitle>
              </CardHeader>
              <CardContent>
                <textarea
                  name="excerpt"
                  value={formData.excerpt}
                  onChange={handleChange}
                  rows={4}
                  placeholder="Breve resumen para mostrar en listas..."
                  className="w-full p-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm resize-none"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
};

export default BlogManager;
