
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon, 
  Stethoscope, Activity, Clock, User, Bell, Save, X, Mail, MessageSquare,
  CreditCard, Upload, MapPin, FileText, CheckCircle2, AlertCircle, List,
  Link as LinkIcon, Sparkles, ExternalLink, ShieldAlert, UserPlus, Info,
  Search, Users
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import FormField from '@/components/FormField';
import SelectField from '@/components/SelectField';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const DAYS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
const MONTHS = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

const MedicalCalendar = () => {
  const { toast } = useToast();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Autocomplete State
  const [patientSearchOpen, setPatientSearchOpen] = useState(false);
  const [patientSuggestions, setPatientSuggestions] = useState([]);
  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const [prediction, setPrediction] = useState(null);

  // New Patient Creation State
  const [isCreatingPatient, setIsCreatingPatient] = useState(false);
  const [newPatientData, setNewPatientData] = useState({
    dni: '',
    age: '',
    gender: 'Otro'
  });

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [modalView, setModalView] = useState('summary'); // 'summary' | 'type_selection' | 'form'
  const [eventType, setEventType] = useState(null); // 'consultation' | 'surgery'
  
  // Form State
  const [formData, setFormData] = useState({
    patientName: '',
    patientEmail: '',
    patientWhatsapp: '',
    healthInsurance: '',
    insuranceNumber: '',
    time: '09:00',
    reason: '',
    location: '', // For surgery
    surgeon: 'Dr. Peralta Lorca', // For surgery
    notes: '',
    reminders: {
      whatsapp: true,
      telegram: false,
      sms: false
    }
  });

  // Payment Proof File State
  const [paymentFile, setPaymentFile] = useState(null);
  const [paymentPreview, setPaymentPreview] = useState(null);

  useEffect(() => {
    fetchAppointments();
  }, [currentDate]);

  // Search patients for autocomplete
  useEffect(() => {
    const searchPatients = async () => {
      if (!formData.patientName || formData.patientName.length < 2) {
        setPatientSuggestions([]);
        return;
      }
      
      // If we already selected a patient and the name matches, don't search again
      if (selectedPatientId && patientSuggestions.find(p => p.name === formData.patientName)) return;

      const { data } = await supabase
        .from('patients')
        .select('id, name, extended_data')
        .ilike('name', `%${formData.patientName}%`)
        .limit(5);

      if (data) setPatientSuggestions(data);
    };

    const timer = setTimeout(searchPatients, 300);
    return () => clearTimeout(timer);
  }, [formData.patientName]);

  const fetchAppointments = async () => {
    setLoading(true);
    const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString();
    const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString();

    const { data, error } = await supabase
      .from('appointments')
      .select('*, patients(id, name)')
      .gte('appointment_date', startOfMonth)
      .lte('appointment_date', endOfMonth)
      .order('appointment_time', { ascending: true });

    if (!error) setAppointments(data || []);
    setLoading(false);
  };

  const handlePatientSelect = async (patient) => {
    setSelectedPatientId(patient.id);
    setFormData(prev => ({
      ...prev,
      patientName: patient.name,
      patientEmail: patient.extended_data?.contact_info?.email || patient.email || '',
      patientWhatsapp: patient.extended_data?.contact_info?.phone || patient.phone || '',
      healthInsurance: patient.extended_data?.healthInsurance || '',
      insuranceNumber: patient.extended_data?.affiliateNumber || ''
    }));
    setPatientSearchOpen(false);
    setIsCreatingPatient(false); // Disable create mode if selecting existing

    // Predict next appointment based on history
    predictNextAppointment(patient.id);
  };

  const predictNextAppointment = async (patientId) => {
    try {
      const { data: history } = await supabase
        .from('appointments')
        .select('appointment_date, reason')
        .eq('patient_id', patientId)
        .order('appointment_date', { ascending: false })
        .limit(3);

      if (history && history.length > 0) {
        const lastAppt = new Date(history[0].appointment_date);
        const today = new Date();
        const diffDays = Math.ceil((today - lastAppt) / (1000 * 60 * 60 * 24));
        
        let predictedReason = "Control de Rutina";
        if (history[0].reason && history[0].reason.toLowerCase().includes('cirugía')) {
          predictedReason = "Control Post-Quirúrgico";
        }

        setPrediction({
          reason: predictedReason,
          lastDate: history[0].appointment_date,
          daysSince: diffDays
        });
      } else {
        setPrediction(null);
      }
    } catch (err) {
      console.error("Error predicting appointment:", err);
    }
  };

  const applyPrediction = () => {
    if (prediction) {
      setFormData(prev => ({
        ...prev,
        reason: prediction.reason
      }));
      toast({
        title: "Predicción Aplicada",
        description: "Se ha completado el motivo basado en el historial.",
        className: "bg-indigo-50 border-indigo-200 text-indigo-800"
      });
    }
  };

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleDateClick = (day) => {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedDate(date);
    setModalView('summary');
    setEventType(null);
    resetForm();
    setIsModalOpen(true);
  };

  const resetForm = () => {
    setFormData({
      patientName: '',
      patientEmail: '',
      patientWhatsapp: '',
      healthInsurance: '',
      insuranceNumber: '',
      time: '09:00',
      reason: '',
      location: '', 
      surgeon: 'Dr. Peralta Lorca',
      notes: '',
      reminders: { whatsapp: true, telegram: false, sms: false }
    });
    setPaymentFile(null);
    setPaymentPreview(null);
    setSelectedPatientId(null);
    setPrediction(null);
    setIsCreatingPatient(false);
    setNewPatientData({ dni: '', age: '', gender: 'Otro' });
  };

  const handleNewAppointmentClick = () => {
    setModalView('type_selection');
  };

  const handleTypeSelect = (type) => {
    setEventType(type);
    setModalView('form');
  };

  const handleBack = () => {
    if (modalView === 'form') {
      setModalView('type_selection');
      setEventType(null);
    } else if (modalView === 'type_selection') {
      setModalView('summary');
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPaymentFile(file);
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => setPaymentPreview(reader.result);
        reader.readAsDataURL(file);
      } else {
        setPaymentPreview(null);
      }
    }
  };

  const uploadPaymentProof = async (file) => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `payment_${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('patient-documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('patient-documents')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading payment proof:', error);
      throw error;
    }
  };

  const handleSave = async () => {
    // Basic validation
    if (!formData.patientName || !formData.time || !formData.reason) {
      toast({
        title: "Datos incompletos",
        description: "Por favor complete Nombre, Hora y Motivo.",
        variant: "destructive"
      });
      return;
    }

    // Specific validation for surgery
    if (eventType === 'surgery' && !formData.location) {
      toast({
        title: "Falta Ubicación",
        description: "Para cirugías, es necesario especificar el lugar.",
        variant: "destructive"
      });
      return;
    }

    // Validation for new patient creation
    if (isCreatingPatient) {
      if (!newPatientData.age || !newPatientData.dni) {
        toast({
          title: "Datos del Nuevo Paciente",
          description: "Para crear un paciente, se requiere Edad y DNI.",
          variant: "destructive"
        });
        return;
      }
    }

    setIsSubmitting(true);

    try {
      let finalPatientId = selectedPatientId;

      // 1. Create Patient if requested
      if (isCreatingPatient && !selectedPatientId) {
        const { data: newPatient, error: createError } = await supabase
          .from('patients')
          .insert({
            name: formData.patientName,
            age: parseInt(newPatientData.age),
            gender: newPatientData.gender,
            extended_data: {
              socialSecurityNumber: newPatientData.dni,
              contact_info: {
                email: formData.patientEmail,
                phone: formData.patientWhatsapp
              },
              healthInsurance: formData.healthInsurance,
              affiliateNumber: formData.insuranceNumber
            }
          })
          .select()
          .single();

        if (createError) throw createError;
        finalPatientId = newPatient.id;
        toast({ title: "Paciente Creado", description: `Se ha registrado a ${newPatient.name} en el sistema.` });
      }

      // 2. Upload Payment
      let paymentUrl = null;
      if (paymentFile) {
        paymentUrl = await uploadPaymentProof(paymentFile);
      }

      // 3. Prepare Notes
      let finalNotes = formData.notes || '';
      
      // If guest mode (no ID), add name to notes to preserve it
      if (!finalPatientId) {
        finalNotes = `[PACIENTE NO REGISTRADO: ${formData.patientName}] ${finalNotes}`;
      }

      if (eventType === 'surgery') {
         finalNotes = `[CIRUGÍA] Lugar: ${formData.location} | Cirujano: ${formData.surgeon} | ${finalNotes}`;
      }

      // 4. Create Appointment
      const { error } = await supabase.from('appointments').insert({
        patient_id: finalPatientId, // Can be null for Guest
        appointment_date: selectedDate.toISOString().split('T')[0],
        appointment_time: formData.time,
        reason: formData.reason,
        status: 'scheduled',
        type: eventType,
        notification_preferences: formData.reminders,
        patient_email: formData.patientEmail,
        patient_whatsapp: formData.patientWhatsapp,
        health_insurance: formData.healthInsurance,
        insurance_number: formData.insuranceNumber,
        payment_proof_url: paymentUrl,
        notes: finalNotes
      });

      if (error) throw error;

      toast({
        title: eventType === 'surgery' ? "Cirugía Programada" : "Turno Agendado",
        description: `Confirmado para el ${selectedDate.toLocaleDateString()}`,
        className: "bg-green-50 border-green-200 text-green-800"
      });

      setIsModalOpen(false);
      fetchAppointments();

    } catch (err) {
      console.error("Error saving appointment:", err);
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyPublicLink = () => {
    const url = `${window.location.origin}/book-appointment`;
    navigator.clipboard.writeText(url);
    toast({
      title: "Link Copiado",
      description: "Enlace de autogestión copiado al portapapeles.",
    });
  };

  const openPatientHistory = (patientId) => {
    if (!patientId) return;
    const event = new CustomEvent('open-patient-profile', { 
      detail: { patientId } 
    });
    window.dispatchEvent(event);
    setIsModalOpen(false);
  };

  // Calendar Grid Logic
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  
  const renderCalendarDays = () => {
    const days = [];
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="h-32 bg-slate-50/30 border border-slate-100" />);
    }
    
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toISOString().split('T')[0];
      const dayEvents = appointments.filter(a => a.appointment_date === dateStr);
      const isToday = new Date().toDateString() === new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toDateString();

      days.push(
        <div 
          key={day} 
          onClick={() => handleDateClick(day)}
          className={`
            h-32 border border-slate-100 p-2 transition-all hover:bg-slate-50 cursor-pointer relative group overflow-hidden
            ${isToday ? 'bg-blue-50/30' : 'bg-white'}
          `}
        >
          <span className={`
            text-sm font-semibold w-7 h-7 flex items-center justify-center rounded-full mb-1
            ${isToday ? 'bg-blue-600 text-white' : 'text-slate-700'}
          `}>
            {day}
          </span>
          
          <div className="space-y-1 overflow-y-auto max-h-[85px] pr-1 scrollbar-hide">
            {dayEvents.map((evt, idx) => {
              // Extract name if guest
              let displayName = evt.patients?.name;
              if (!displayName && evt.notes && evt.notes.includes('[PACIENTE NO REGISTRADO:')) {
                 const match = evt.notes.match(/\[PACIENTE NO REGISTRADO: (.*?)\]/);
                 if (match) displayName = match[1];
              }
              if (!displayName) displayName = "Turno Ocupado";

              return (
                <div 
                  key={idx} 
                  className={`
                    text-[10px] px-1.5 py-1 rounded border truncate flex items-center gap-1 mb-1
                    ${evt.type === 'surgery' 
                      ? 'bg-red-50 text-red-700 border-red-100' 
                      : 'bg-blue-50 text-blue-700 border-blue-100'}
                  `}
                >
                  <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${evt.type === 'surgery' ? 'bg-red-500' : 'bg-blue-500'}`} />
                  <span className="font-bold">{evt.appointment_time.slice(0,5)}</span>
                  <span className="truncate ml-1">{displayName}</span>
                </div>
              );
            })}
          </div>

          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Plus className="w-4 h-4 text-slate-400" />
          </div>
        </div>
      );
    }
    return days;
  };

  const getSelectedDayEvents = () => {
    if (!selectedDate) return [];
    const dateStr = selectedDate.toISOString().split('T')[0];
    return appointments.filter(a => a.appointment_date === dateStr);
  };

  const clinicOptions = [
    { value: '', label: 'Seleccionar Clínica...' },
    { value: 'Policlínica San Rafael', label: 'Policlínica San Rafael' },
    { value: 'Hospital Español del sur Mendocino', label: 'Hospital Español del sur Mendocino' },
    { value: 'Clínica Ciudad', label: 'Clínica Ciudad' }
  ];

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
      {/* Calendar Header */}
      <div className="p-6 flex flex-col md:flex-row items-center justify-between border-b border-slate-100 gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-100 text-indigo-600 rounded-xl">
             <CalendarIcon className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 capitalize">
            {MONTHS[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <Button variant="outline" className="text-indigo-600 border-indigo-100 bg-indigo-50 hover:bg-indigo-100 hidden md:flex" onClick={copyPublicLink}>
             <LinkIcon className="w-4 h-4 mr-2" /> Link Autogestión
          </Button>
          <div className="h-6 w-px bg-slate-200 hidden md:block mx-2" />
          <Button variant="outline" size="icon" onClick={handlePrevMonth}>
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <Button variant="outline" onClick={() => setCurrentDate(new Date())}>
            Hoy
          </Button>
          <Button variant="outline" size="icon" onClick={handleNextMonth}>
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 bg-slate-50 border-b border-slate-100">
        {DAYS.map(day => (
          <div key={day} className="py-3 text-center text-sm font-bold text-slate-500 uppercase tracking-wider">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7">
        {renderCalendarDays()}
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {modalView === 'summary' && `Agenda: ${selectedDate?.toLocaleDateString()}`}
              {modalView === 'type_selection' && 'Seleccione Tipo de Evento'}
              {modalView === 'form' && (eventType === 'surgery' ? 'Programar Cirugía' : 'Agendar Turno')}
            </DialogTitle>
          </DialogHeader>

          {modalView === 'summary' && (
            <div className="space-y-4 py-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Turnos Programados</h3>
                <Button onClick={handleNewAppointmentClick} size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                  <Plus className="w-4 h-4 mr-2" /> Agregar Nuevo
                </Button>
              </div>

              <ScrollArea className="h-[300px] pr-4">
                {getSelectedDayEvents().length > 0 ? (
                  <div className="space-y-3">
                    {getSelectedDayEvents().map((evt) => {
                       // Name extraction helper
                       let displayName = evt.patients?.name;
                       if (!displayName && evt.notes && evt.notes.includes('[PACIENTE NO REGISTRADO:')) {
                           const match = evt.notes.match(/\[PACIENTE NO REGISTRADO: (.*?)\]/);
                           if (match) displayName = match[1];
                       }
                       if (!displayName) displayName = "Paciente sin registrar";

                       return (
                        <div 
                          key={evt.id} 
                          className={`
                            p-4 rounded-xl border flex items-start gap-3 transition-colors
                            ${evt.type === 'surgery' 
                              ? 'bg-red-50/50 border-red-100 hover:bg-red-50' 
                              : 'bg-blue-50/50 border-blue-100 hover:bg-blue-50'}
                          `}
                        >
                          <div className={`
                            mt-1 p-2 rounded-lg shrink-0
                            ${evt.type === 'surgery' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}
                          `}>
                            {evt.type === 'surgery' ? <Activity className="w-4 h-4" /> : <Stethoscope className="w-4 h-4" />}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start">
                              <h4 
                                className={`font-bold truncate text-base flex items-center gap-2 ${evt.patients?.id ? 'text-blue-700 hover:underline cursor-pointer' : 'text-slate-800'}`}
                                onClick={() => evt.patients?.id && openPatientHistory(evt.patients.id)}
                              >
                                {displayName}
                                {evt.patients?.id && <ExternalLink className="w-3.5 h-3.5 opacity-50" />}
                              </h4>
                              <span className="text-xs font-mono font-bold px-2 py-1 bg-white rounded border border-slate-200 text-slate-600">
                                {evt.appointment_time.slice(0,5)}
                              </span>
                            </div>
                            
                            <p className="text-sm text-slate-600 mt-1 truncate">{evt.reason}</p>
                            {evt.notes && <p className="text-xs text-slate-500 mt-1 line-clamp-2 italic">{evt.notes.replace(/\[.*?\]/g, '').trim()}</p>}
                            
                            <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                              {evt.health_insurance && (
                                <span className="flex items-center gap-1">
                                  <CreditCard className="w-3 h-3" /> {evt.health_insurance}
                                </span>
                              )}
                              {evt.payment_proof_url && (
                                <span className="flex items-center gap-1 text-green-600 bg-green-50 px-1.5 py-0.5 rounded border border-green-100">
                                  <CheckCircle2 className="w-3 h-3" /> Seña Pagada
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                       );
                    })}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-slate-400 py-10">
                    <List className="w-12 h-12 mb-3 opacity-20" />
                    <p>No hay turnos programados para este día.</p>
                  </div>
                )}
              </ScrollArea>
            </div>
          )}

          {modalView === 'type_selection' && (
            <div className="grid grid-cols-2 gap-4 py-6">
              <button 
                onClick={() => handleTypeSelect('consultation')}
                className="flex flex-col items-center justify-center p-6 gap-3 rounded-xl border-2 border-blue-100 bg-blue-50/50 hover:bg-blue-100 hover:border-blue-300 transition-all group"
              >
                <Stethoscope className="w-10 h-10 text-blue-500 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-blue-700">Consulta Médica</span>
              </button>
              
              <button 
                onClick={() => handleTypeSelect('surgery')}
                className="flex flex-col items-center justify-center p-6 gap-3 rounded-xl border-2 border-red-100 bg-red-50/50 hover:bg-red-100 hover:border-red-300 transition-all group"
              >
                <Activity className="w-10 h-10 text-red-500 group-hover:scale-110 transition-transform" />
                <span className="font-bold text-red-700">Cirugía</span>
              </button>
            </div>
          )}

          {modalView === 'form' && (
            <div className="space-y-5 py-2 animate-in slide-in-from-right-4">
              
              <div className="flex flex-wrap gap-4 items-end bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="space-y-1">
                   <Label className="text-xs text-slate-500 uppercase">Fecha</Label>
                   <div className="px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-700 font-semibold flex items-center gap-2">
                     <CalendarIcon className="w-4 h-4 text-slate-400" />
                     {selectedDate?.toLocaleDateString()}
                   </div>
                </div>
                <div className="space-y-1 flex-1">
                   <Label className="text-xs text-slate-500 uppercase">Hora</Label>
                   <Input 
                      type="time" 
                      value={formData.time} 
                      onChange={(e) => setFormData({...formData, time: e.target.value})}
                      className="bg-white"
                   />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label>Nombre del Paciente <span className="text-red-500">*</span></Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-4 h-4 text-slate-400 z-10" />
                    <Popover open={patientSearchOpen} onOpenChange={setPatientSearchOpen} modal={true}>
                      <PopoverTrigger asChild>
                        <Input 
                          placeholder="Buscar o escribir nombre..." 
                          className="pl-10"
                          value={formData.patientName}
                          onChange={(e) => {
                            setFormData({...formData, patientName: e.target.value});
                            if(e.target.value.length >= 2) setPatientSearchOpen(true);
                            if(selectedPatientId && e.target.value !== formData.patientName) setSelectedPatientId(null);
                          }}
                          onFocus={() => {
                             if(formData.patientName.length >= 2) setPatientSearchOpen(true);
                          }}
                        />
                      </PopoverTrigger>
                      <PopoverContent className="p-0 w-[400px]" align="start">
                        <Command>
                          <CommandList>
                            <CommandEmpty>No hay coincidencias. Puede crear uno nuevo.</CommandEmpty>
                            <CommandGroup heading="Pacientes Registrados">
                              {patientSuggestions.map((patient) => (
                                <CommandItem
                                  key={patient.id}
                                  onSelect={() => handlePatientSelect(patient)}
                                  className="cursor-pointer"
                                >
                                  <User className="mr-2 h-4 w-4" />
                                  <span>{patient.name}</span>
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  {/* Logic: If name entered but no ID selected, offer to create new or use as guest */}
                  {!selectedPatientId && formData.patientName && (
                    <div className="mt-2 flex items-center gap-4 animate-in fade-in">
                       <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="new-patient-check" 
                            checked={isCreatingPatient}
                            onCheckedChange={setIsCreatingPatient}
                          />
                          <Label htmlFor="new-patient-check" className="text-sm font-medium text-blue-600 cursor-pointer flex items-center gap-1">
                             <UserPlus className="w-3.5 h-3.5" />
                             Crear ficha completa ahora
                          </Label>
                       </div>
                       {!isCreatingPatient && (
                          <span className="text-xs text-slate-400 flex items-center gap-1">
                            <Info className="w-3 h-3" /> Se guardará como invitado
                          </span>
                       )}
                    </div>
                  )}

                  {isCreatingPatient && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="bg-blue-50/50 p-3 rounded-lg border border-blue-100 mt-2 grid grid-cols-3 gap-3"
                    >
                      <div className="space-y-1">
                        <Label className="text-xs">DNI *</Label>
                        <Input 
                          className="bg-white h-8 text-xs" 
                          placeholder="12345678"
                          value={newPatientData.dni}
                          onChange={(e) => setNewPatientData({...newPatientData, dni: e.target.value})}
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Edad *</Label>
                        <Input 
                          type="number"
                          className="bg-white h-8 text-xs" 
                          placeholder="30"
                          value={newPatientData.age}
                          onChange={(e) => setNewPatientData({...newPatientData, age: e.target.value})}
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Sexo</Label>
                        <select 
                          className="w-full h-8 text-xs rounded-md border border-input bg-background px-2 py-1"
                          value={newPatientData.gender}
                          onChange={(e) => setNewPatientData({...newPatientData, gender: e.target.value})}
                        >
                          <option value="Masculino">Masculino</option>
                          <option value="Femenino">Femenino</option>
                          <option value="Otro">Otro</option>
                        </select>
                      </div>
                    </motion.div>
                  )}

                  {prediction && !isCreatingPatient && selectedPatientId && (
                    <motion.div 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-xs flex items-center gap-2 p-2 mt-1 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-100 cursor-pointer hover:bg-indigo-100"
                      onClick={applyPrediction}
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>
                        Sugerencia: <strong> {prediction.reason}</strong>
                      </span>
                    </motion.div>
                  )}
                </div>

                <FormField
                  label="Email"
                  type="email"
                  icon={<Mail className="w-4 h-4" />}
                  placeholder="paciente@ejemplo.com"
                  value={formData.patientEmail}
                  onChange={(v) => setFormData({...formData, patientEmail: v})}
                />
                <FormField
                  label="WhatsApp"
                  type="tel"
                  icon={<MessageSquare className="w-4 h-4" />}
                  placeholder="+54 9..."
                  value={formData.patientWhatsapp}
                  onChange={(v) => setFormData({...formData, patientWhatsapp: v})}
                />
              </div>

              {eventType === 'surgery' && (
                <div className="bg-red-50/50 p-4 rounded-xl border border-red-100 space-y-4 animate-in fade-in-50">
                   <div className="flex items-center gap-2 border-b border-red-200 pb-2 mb-2">
                      <ShieldAlert className="w-4 h-4 text-red-600" />
                      <h4 className="font-bold text-red-900 text-sm">Detalles Quirúrgicos</h4>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <SelectField
                        label="Lugar / Clínica *"
                        placeholder="Seleccione la clínica..."
                        value={formData.location}
                        onChange={(v) => setFormData({...formData, location: v})}
                        options={clinicOptions}
                        className="bg-white"
                      />
                      <FormField
                        label="Cirujano Principal"
                        placeholder="Dr. Responsable"
                        value={formData.surgeon}
                        onChange={(v) => setFormData({...formData, surgeon: v})}
                        className="bg-white"
                      />
                   </div>
                </div>
              )}

              <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100 space-y-3">
                <Label className="flex items-center gap-2 text-blue-800 font-bold border-b border-blue-100 pb-2">
                  <FileText className="w-4 h-4" /> Datos de Cobertura
                </Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    label="Obra Social"
                    placeholder="Ej. OSDE"
                    value={formData.healthInsurance}
                    onChange={(v) => setFormData({...formData, healthInsurance: v})}
                    className="bg-white"
                  />
                  <FormField
                    label="N° Carnet / Afiliado"
                    placeholder="0000000000"
                    value={formData.insuranceNumber}
                    onChange={(v) => setFormData({...formData, insuranceNumber: v})}
                    className="bg-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>{eventType === 'surgery' ? 'Procedimiento Quirúrgico' : 'Motivo de Consulta'} <span className="text-red-500">*</span></Label>
                <Input 
                  placeholder={eventType === 'surgery' ? "Ej: Mastectomía Radical" : "Ej: Consulta control anual"}
                  value={formData.reason}
                  onChange={(e) => setFormData({...formData, reason: e.target.value})}
                />
              </div>

              <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-4 rounded-xl border border-amber-200/60 space-y-3">
                 <div className="flex items-start gap-3">
                    <div className="p-2 bg-amber-100 text-amber-600 rounded-lg shrink-0">
                       <CreditCard className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                       <h4 className="font-bold text-amber-900 text-sm mb-1">Pago / Seña</h4>
                       <p className="text-xs text-amber-800/80 mb-2">
                         Se requiere un depósito para confirmar.
                       </p>
                    </div>
                 </div>
                 <div className="pt-2">
                    <Label className="text-xs font-semibold text-amber-800 mb-2 block">Comprobante de Depósito</Label>
                    <div className="flex items-center gap-3">
                       <div className="relative">
                          <input 
                            type="file" 
                            id="payment-upload" 
                            className="hidden" 
                            accept="image/*,.pdf"
                            onChange={handleFileChange}
                          />
                          <label 
                            htmlFor="payment-upload"
                            className="flex items-center gap-2 px-3 py-2 bg-white border border-amber-200 rounded-lg text-xs font-medium text-amber-700 cursor-pointer hover:bg-amber-50 transition-colors shadow-sm"
                          >
                             <Upload className="w-3 h-3" />
                             {paymentFile ? 'Cambiar Archivo' : 'Subir Comprobante'}
                          </label>
                       </div>
                       {paymentFile && (
                          <div className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded border border-green-100">
                             <CheckCircle2 className="w-3 h-3" />
                             <span className="truncate max-w-[150px]">{paymentFile.name}</span>
                          </div>
                       )}
                    </div>
                 </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-3">
                 <Label className="flex items-center gap-2 text-slate-600 text-xs uppercase tracking-wider font-bold">
                    <Bell className="w-3 h-3" /> Recordatorios
                 </Label>
                 <div className="flex flex-wrap gap-4">
                    <div className="flex items-center space-x-2">
                       <Checkbox 
                         id="wa" 
                         checked={formData.reminders.whatsapp}
                         onCheckedChange={(c) => setFormData(prev => ({...prev, reminders: {...prev.reminders, whatsapp: c}}))}
                       />
                       <Label htmlFor="wa" className="cursor-pointer text-sm">WhatsApp</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                       <Checkbox 
                         id="sms" 
                         checked={formData.reminders.sms}
                         onCheckedChange={(c) => setFormData(prev => ({...prev, reminders: {...prev.reminders, sms: c}}))}
                       />
                       <Label htmlFor="sms" className="cursor-pointer text-sm">SMS</Label>
                    </div>
                 </div>
              </div>
            </div>
          )}

          <DialogFooter className="mt-2">
            {modalView !== 'summary' && (
              <Button variant="ghost" onClick={handleBack} disabled={isSubmitting}>
                Atrás
              </Button>
            )}
            
            {modalView === 'summary' && (
              <Button variant="outline" onClick={() => setIsModalOpen(false)}>
                Cerrar
              </Button>
            )}

            {modalView === 'form' && (
              <Button 
                onClick={handleSave}
                disabled={isSubmitting}
                className={eventType === 'surgery' ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'}
              >
                <Save className="w-4 h-4 mr-2" /> 
                {isSubmitting ? 'Guardando...' : `Guardar ${eventType === 'surgery' ? 'Cirugía' : 'Turno'}`}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MedicalCalendar;
