
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { LockKeyhole, Mail, AlertCircle, Loader2, Stethoscope, CheckCircle2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const LOGO_URL = "https://horizons-cdn.hostinger.com/a2da2fd7-d789-4d10-b670-30a519160b2b/6d05420aa8885edfe961d61427d0e3be.jpg";

const LoginPage = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [email, setEmail] = useState('drperaltalorca@gmail.com');
  const [password, setPassword] = useState('polka15AGO');
  const [isInitializing, setIsInitializing] = useState(true);
  const [setupStatus, setSetupStatus] = useState('Verificando credenciales...');

  // Auto-register/Update the admin user on first load
  useEffect(() => {
    const initAdminUser = async () => {
      // We remove the sessionStorage check to FORCE update the password every time the page loads
      // This ensures that if the password was wrong before, it gets fixed now.
      
      try {
        setSetupStatus('Sincronizando credenciales seguras...');
        
        const { data, error } = await supabase.functions.invoke('create-admin-user', {
          body: { 
            email: 'drperaltalorca@gmail.com', 
            password: 'polka15AGO' 
          }
        });

        if (error) {
          console.error('Edge function error:', error);
          // If edge function fails, we still let them try to login, maybe user exists
        } else {
          console.log('Admin user sync result:', data);
        }
        
      } catch (err) {
        console.error('Error initializing admin user:', err);
      } finally {
        setIsInitializing(false);
      }
    };

    initAdminUser();
  }, []);

  const handleEmailLogin = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const cleanEmail = email.toLowerCase().trim();

    if (cleanEmail !== 'drperaltalorca@gmail.com') {
      setError('Acceso denegado. Este sistema es exclusivo para el Dr. Peralta Lorca.');
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password: password,
      });

      if (error) throw error;
      
      // Success is handled by AuthContext automatically redirecting/updating state
      
    } catch (error) {
      console.error("Login error:", error);
      if (error.message.includes('Invalid login credentials')) {
        setError('Credenciales incorrectas. Por favor espere un momento y reintente, el sistema está actualizando su acceso.');
      } else if (error.message.includes('Email not confirmed')) {
        setError('El email no ha sido confirmado. El sistema debería haberlo confirmado automáticamente.');
      } else {
        setError(`Error de conexión: ${error.message}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-100 to-blue-50 p-4">
      <Card className="w-full max-w-md shadow-xl border-slate-200">
        <CardHeader className="text-center space-y-2">
          {/* P+L Logo */}
          <div className="mx-auto bg-black p-2 rounded-xl w-fit mb-4">
            <img 
              src={LOGO_URL} 
              alt="P+L Logo" 
              className="h-16 w-auto object-contain rounded-lg" 
            />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900">Portal Médico Privado</CardTitle>
          <CardDescription>
            Acceso exclusivo Dr. Peralta Lorca
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="animate-in fade-in slide-in-from-top-2 border-red-200 bg-red-50 text-red-800">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-900 font-semibold">Error de acceso</AlertTitle>
              <AlertDescription className="text-red-700">{error}</AlertDescription>
            </Alert>
          )}

          {isInitializing ? (
            <div className="flex flex-col items-center justify-center py-12 space-y-4 text-slate-500">
              <Loader2 className="w-10 h-10 animate-spin text-blue-600" />
              <div className="text-center">
                <p className="font-medium text-slate-700">Iniciando sistema seguro</p>
                <p className="text-xs text-slate-400 mt-1">{setupStatus}</p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleEmailLogin} className="space-y-4 animate-in fade-in duration-500">
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-slate-700 block">
                  Usuario Autorizado
                </label>
                <div className="relative group">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="drperaltalorca@gmail.com"
                    required
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-slate-50"
                    readOnly 
                  />
                  <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="text-sm font-medium text-slate-700 block">
                  Clave de Acceso
                </label>
                <div className="relative group">
                  <LockKeyhole className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
                  <input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Ingrese su contraseña"
                    required
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <Button 
                type="submit"
                className="w-full h-12 text-base font-medium bg-blue-600 hover:bg-blue-700 text-white transition-all shadow-sm active:scale-[0.98]"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin mr-2" />
                    Verificando...
                  </>
                ) : (
                  'Ingresar al Sistema'
                )}
              </Button>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex justify-center text-xs text-slate-400 border-t pt-4">
          <p>Sistema protegido. Uso exclusivo profesional.</p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default LoginPage;
