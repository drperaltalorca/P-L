
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Pill, Search, Plus, FileText, User, Calendar, ArrowRight, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PrescriptionForm from './PrescriptionForm';
import PrescriptionDocument from './PrescriptionDocument';

const GlobalPrescriptionsView = () => {
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New Prescription Modal State
  const [isNewRxOpen, setIsNewRxOpen] = useState(false);
  const [patientSearch, setPatientSearch] = useState('');
  const [foundPatients, setFoundPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [isSearchingPatients, setIsSearchingPatients] = useState(false);

  // Document Viewer State
  const [viewDocument, setViewDocument] = useState(null);
  const [viewPatient, setViewPatient] = useState(null);

  useEffect(() => {
    fetchGlobalPrescriptions();
  }, []);

  const fetchGlobalPrescriptions = async () => {
    setLoading(true);
    try {
      // We need to fetch prescriptions and join with patients to show names
      // Note: Supabase JS simple join syntax
      const { data, error } = await supabase
        .from('prescriptions')
        .select(`
          *,
          patients (
            id,
            name,
            age,
            extended_data
          )
        `)
        .order('prescribed_date', { ascending: false })
        .limit(50);

      if (error) throw error;
      setPrescriptions(data);
    } catch (err) {
      console.error('Error fetching prescriptions:', err);
    } finally {
      setLoading(false);
    }
  };

  // Search Patients for New Rx
  useEffect(() => {
    const searchPatients = async () => {
      if (patientSearch.length < 2) {
        setFoundPatients([]);
        return;
      }
      setIsSearchingPatients(true);
      try {
        const { data } = await supabase
          .from('patients')
          .select('id, name, extended_data')
          .ilike('name', `%${patientSearch}%`)
          .limit(5);
        setFoundPatients(data || []);
      } catch (e) {
        console.error(e);
      } finally {
        setIsSearchingPatients(false);
      }
    };
    
    const timeoutId = setTimeout(searchPatients, 400);
    return () => clearTimeout(timeoutId);
  }, [patientSearch]);

  const handlePatientSelect = (patient) => {
    setSelectedPatient(patient);
    // Don't close modal yet, switch view inside modal or keep modal open to show form
  };

  const handleCreateSuccess = () => {
    setIsNewRxOpen(false);
    setSelectedPatient(null);
    setPatientSearch('');
    fetchGlobalPrescriptions(); // Refresh list
  };

  const openDocumentViewer = (rx) => {
    setViewDocument(rx);
    setViewPatient(rx.patients); // The joined patient data
  };

  // Filter local list
  const filteredPrescriptions = prescriptions.filter(p => 
    p.medication_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.patients?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-purple-100 text-purple-600 rounded-xl">
            <Pill className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Gestión de Recetas</h1>
            <p className="text-slate-500 text-sm">Historial global y generación de nuevas prescripciones.</p>
          </div>
        </div>
        <Button 
          onClick={() => setIsNewRxOpen(true)}
          className="bg-purple-600 hover:bg-purple-700 text-white rounded-xl shadow-lg shadow-purple-500/20"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nueva Receta
        </Button>
      </div>

      {/* Filters */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input 
          type="text" 
          placeholder="Buscar por paciente o medicamento..." 
          className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          {filteredPrescriptions.length === 0 ? (
            <div className="p-12 text-center text-slate-500">
              <Pill className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>No se encontraron recetas.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-4 font-semibold text-slate-600">Fecha</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Paciente</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Medicamento</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Indicación</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredPrescriptions.map((rx) => (
                    <motion.tr 
                      key={rx.id} 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-slate-50/50 transition-colors"
                    >
                      <td className="px-6 py-4 text-slate-500">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          {new Date(rx.prescribed_date).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-800">{rx.patients?.name || 'Desconocido'}</div>
                        <div className="text-xs text-slate-400">{rx.patients?.extended_data?.socialSecurityNumber || 'Sin DNI'}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-700">{rx.medication_name}</div>
                        <div className="text-xs text-slate-500">{rx.active_ingredients}</div>
                      </td>
                      <td className="px-6 py-4 text-slate-600">
                        {rx.frequency} • {rx.duration}
                      </td>
                      <td className="px-6 py-4">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-purple-600 hover:bg-purple-50"
                          onClick={() => openDocumentViewer(rx)}
                        >
                          <FileText className="w-4 h-4 mr-2" />
                          Ver Receta
                        </Button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* CREATE RX MODAL */}
      <Dialog open={isNewRxOpen} onOpenChange={(open) => {
         if (!open) {
           setSelectedPatient(null);
           setPatientSearch('');
         }
         setIsNewRxOpen(open);
      }}>
        <DialogContent className="max-w-2xl bg-white">
          <DialogHeader>
            <DialogTitle>{selectedPatient ? 'Nueva Receta para:' : 'Seleccionar Paciente'}</DialogTitle>
          </DialogHeader>
          
          {!selectedPatient ? (
            <div className="space-y-4 py-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  autoFocus
                  type="text" 
                  placeholder="Buscar paciente por nombre..." 
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                  value={patientSearch}
                  onChange={(e) => setPatientSearch(e.target.value)}
                />
              </div>
              
              <div className="max-h-[300px] overflow-y-auto space-y-2">
                {isSearchingPatients && <div className="text-center py-2 text-slate-400 text-sm">Buscando...</div>}
                
                {foundPatients.map(p => (
                  <div 
                    key={p.id}
                    onClick={() => handlePatientSelect(p)}
                    className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:border-purple-200 hover:bg-purple-50 cursor-pointer transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 group-hover:bg-purple-200 group-hover:text-purple-700">
                        <User className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">{p.name}</div>
                        <div className="text-xs text-slate-500">{p.extended_data?.socialSecurityNumber}</div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-purple-600" />
                  </div>
                ))}
                
                {patientSearch.length >= 2 && foundPatients.length === 0 && !isSearchingPatients && (
                   <div className="text-center py-4 text-slate-400 text-sm">No se encontraron pacientes.</div>
                )}
              </div>
            </div>
          ) : (
            <div className="py-2">
               <div className="flex items-center gap-2 mb-4 p-3 bg-purple-50 rounded-lg text-purple-800 text-sm">
                 <User className="w-4 h-4" />
                 <span className="font-semibold">{selectedPatient.name}</span>
                 <span className="text-purple-600/70">| {selectedPatient.extended_data?.socialSecurityNumber}</span>
                 <button onClick={() => setSelectedPatient(null)} className="ml-auto text-xs underline hover:text-purple-900">Cambiar</button>
               </div>
               
               <PrescriptionForm 
                 patientId={selectedPatient.id} 
                 onSuccess={handleCreateSuccess}
                 onCancel={() => setIsNewRxOpen(false)}
                 className="border-0 shadow-none p-0"
               />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* DOCUMENT VIEWER MODAL */}
      {viewDocument && viewPatient && (
        <PrescriptionDocument 
          open={!!viewDocument}
          onOpenChange={(open) => !open && setViewDocument(null)}
          prescription={viewDocument}
          patient={viewPatient}
        />
      )}
    </div>
  );
};

export default GlobalPrescriptionsView;
