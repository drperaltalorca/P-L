import React from 'react';
import { ChevronDown } from 'lucide-react';

const SelectField = ({ label, value, onChange, options, className = '', icon }) => {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <label className="block text-sm font-medium text-slate-600 ml-1">
        {label}
      </label>
      <div className="relative group">
        {icon && (
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors pointer-events-none z-10">
            {icon}
          </div>
        )}
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className={`
            w-full bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-xl 
            focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 block p-3 appearance-none
            transition-all duration-200 ease-in-out cursor-pointer
            ${icon ? 'pl-10' : 'pl-4'}
            pr-10
          `}
        >
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
          <ChevronDown className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};

export default SelectField;