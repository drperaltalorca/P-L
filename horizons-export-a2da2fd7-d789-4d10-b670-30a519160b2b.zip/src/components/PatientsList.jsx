
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Activity, 
  Pill, 
  User, 
  Clock,
  Search,
  AlertCircle,
  FileText,
  Pencil
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import EditPatientModal from '@/components/EditPatientModal';
import PatientLink from '@/components/PatientLink';

const PatientsList = ({ onSelectPatient }) => {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Edit Modal State
  const [editingPatient, setEditingPatient] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('patients')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPatients(data);
    } catch (err) {
      console.error('Error fetching patients:', err);
      setError('No se pudieron cargar los pacientes. Por favor, intente nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleEditClick = (e, patient) => {
    e.stopPropagation(); // Prevent card click
    setEditingPatient(patient);
    setIsEditModalOpen(true);
  };

  const handleEditClose = () => {
    setIsEditModalOpen(false);
    setEditingPatient(null);
  };

  const handlePatientUpdate = () => {
    fetchPatients(); // Reload list
  };

  const filteredPatients = patients.filter(patient => 
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.medical_conditions?.some(c => c.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center bg-white rounded-3xl shadow-sm border border-red-100">
        <div className="p-4 bg-red-50 text-red-500 rounded-full mb-4">
          <AlertCircle className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-2">Error de Carga</h3>
        <p className="text-slate-500 mb-6">{error}</p>
        <Button onClick={fetchPatients} variant="outline" className="border-red-200 text-red-600 hover:bg-red-50">
          Intentar Nuevamente
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 backdrop-blur-xl p-6 rounded-2xl shadow-sm border border-white/50">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl shadow-lg shadow-purple-500/20 text-white">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700">
              Listado de Pacientes
            </h1>
            <p className="text-slate-500 text-sm">
              Vista general de historias clínicas y seguimientos
            </p>
          </div>
        </div>
        
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por nombre o condición..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all outline-none text-sm"
          />
        </div>
      </div>

      {/* Loading State */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 h-80 animate-pulse">
              <div className="h-6 w-1/3 bg-slate-100 rounded mb-4"></div>
              <div className="space-y-3">
                <div className="h-4 w-full bg-slate-50 rounded"></div>
                <div className="h-4 w-5/6 bg-slate-50 rounded"></div>
                <div className="h-20 w-full bg-slate-50 rounded mt-6"></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
        >
          {filteredPatients.length > 0 ? (
            filteredPatients.map((patient) => (
              <motion.div
                key={patient.id}
                variants={item}
                className="group bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      {patient.photo_url ? (
                        <div className="w-12 h-12 rounded-2xl bg-slate-100 overflow-hidden group-hover:shadow-md transition-shadow">
                          <img src={patient.photo_url} alt={patient.name} className="w-full h-full object-cover" />
                        </div>
                      ) : (
                        <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-600 font-bold text-lg group-hover:bg-purple-50 group-hover:text-purple-600 transition-colors">
                          {patient.name.charAt(0)}
                        </div>
                      )}
                      <div>
                        <h3 className="font-bold text-lg text-slate-800 group-hover:text-purple-700 transition-colors truncate max-w-[150px]">
                          <PatientLink patientId={patient.id} name={patient.name} className="hover:no-underline" />
                        </h3>
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <span className="flex items-center gap-1">
                            <User className="w-3 h-3" /> {patient.gender}
                          </span>
                          <span>•</span>
                          <span>{patient.age} años</span>
                        </div>
                      </div>
                    </div>
                    
                    {/* Actions Corner */}
                    <div className="flex items-center gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={(e) => handleEditClick(e, patient)}
                        className="h-8 w-8 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-full"
                        title="Editar Paciente"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <div className="text-xs text-slate-400 flex items-center gap-1 bg-slate-50 px-2 py-1 rounded-lg shrink-0">
                        <Clock className="w-3 h-3" />
                        {new Date(patient.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    {/* Conditions */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                        <Activity className="w-3 h-3" />
                        Condiciones
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {patient.medical_conditions?.length > 0 ? (
                          patient.medical_conditions.map((condition, idx) => (
                            <span key={idx} className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-600 text-xs font-medium border border-rose-100">
                              {condition}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-slate-400 italic">Sin registros</span>
                        )}
                      </div>
                    </div>

                    {/* Medications */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                        <Pill className="w-3 h-3" />
                        Medicamentos
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {patient.medications?.length > 0 ? (
                          patient.medications.map((med, idx) => (
                            <span key={idx} className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-600 text-xs font-medium border border-blue-100">
                              {med}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-slate-400 italic">Ninguno</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mt-auto">
                   <Button 
                    onClick={() => onSelectPatient(patient)}
                    className="col-span-2 w-full bg-slate-50 hover:bg-slate-100 text-slate-700 hover:text-blue-600 border border-slate-100 group-hover:border-blue-200 transition-all rounded-xl"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Ver Historia Clínica
                  </Button>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="col-span-full flex flex-col items-center justify-center p-12 text-slate-400">
              <Search className="w-12 h-12 mb-3 opacity-20" />
              <p>No se encontraron pacientes que coincidan con la búsqueda.</p>
            </div>
          )}
        </motion.div>
      )}
      
      {/* Edit Modal */}
      <EditPatientModal 
        isOpen={isEditModalOpen} 
        onClose={handleEditClose} 
        patient={editingPatient}
        onUpdate={handlePatientUpdate}
      />
    </div>
  );
};

export default PatientsList;
