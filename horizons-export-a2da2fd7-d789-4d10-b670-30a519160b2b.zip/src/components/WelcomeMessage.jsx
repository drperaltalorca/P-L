
import React from 'react';
import { motion } from 'framer-motion';

const WelcomeMessage = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-8 rounded-3xl shadow-xl overflow-hidden relative"
    >
      {/* Background pattern */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <svg className="w-full h-full" fill="none" viewBox="0 0 100 100">
          <pattern id="pattern-circles" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1" fill="currentColor" />
          </pattern>
          <rect x="0" y="0" width="100%" height="100%" fill="url(#pattern-circles)" />
        </svg>
      </div>

      <div className="relative z-10">
        <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight">
          DIAGNÓSTICO POR IMÁGENES
        </h1>
        <ul className="list-inside list-disc text-lg md:text-xl font-medium space-y-2">
          <li>www.diagnosticomedico.com.ar</li>
          <li>Español</li>
          <li>Olascoaga</li>
        </ul>
      </div>
    </motion.div>
  );
};

export default WelcomeMessage;
