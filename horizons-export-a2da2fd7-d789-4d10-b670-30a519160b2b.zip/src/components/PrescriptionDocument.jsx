
import React from 'react';
import { FileText, Calendar, User, Clock, Pill, Printer, MapPin, Phone, ShieldCheck, Scale } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';

const LOGO_URL = "https://horizons-cdn.hostinger.com/a2da2fd7-d789-4d10-b670-30a519160b2b/6d05420aa8885edfe961d61427d0e3be.jpg";

const PrescriptionDocument = ({ prescription, patient, open, onOpenChange }) => {
  if (!prescription || !patient) return null;

  const handlePrint = () => {
    // Add a small delay to ensure rendering is complete before print dialog
    setTimeout(() => {
      window.print();
    }, 100);
  };

  // Helper to format the commercial name safely
  const commercialName = prescription.medication_name || 'Medicamento Genérico';

  // Determine Obra Social data (prefer prescription snapshot, fallback to patient current data)
  const obraSocial = prescription.medical_provider || patient.extended_data?.healthInsurance || 'Particular';
  const nroObraSocial = prescription.medical_provider_number || patient.extended_data?.affiliateNumber || '---';
  
  // Current doctor/coverage
  const coverageDoctor = patient.extended_data?.medicalProvider || '---';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl h-[95vh] overflow-y-auto bg-white p-0 gap-0 shadow-2xl focus:outline-none">
        {/* Toolbar */}
        <div className="sticky top-0 z-50 flex justify-between items-center px-6 py-4 bg-white border-b border-slate-200 print:hidden shadow-sm">
          <div className="flex items-center gap-3">
             <div className="bg-blue-600 text-white p-2 rounded-lg">
                <FileText className="w-5 h-5" />
             </div>
             <div>
                <DialogTitle className="text-lg font-bold text-slate-800">Vista Previa de Receta</DialogTitle>
                <p className="text-xs text-slate-500">Formato A4 Profesional</p>
             </div>
          </div>
          <Button onClick={handlePrint} className="gap-2 bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20">
            <Printer className="w-4 h-4" />
            Imprimir / Descargar PDF
          </Button>
        </div>

        {/* Scrollable Preview Area */}
        {/* We use a specific ID wrapper for the print target */}
        <div className="flex justify-center p-8 min-h-full bg-slate-100 print:p-0 print:m-0 print:bg-white print:block">
          
          {/* A4 Paper Container - 210mm x 297mm */}
          <div 
            id="prescription-content" 
            className="bg-white w-[210mm] min-h-[297mm] relative shadow-xl print:shadow-none flex flex-col mx-auto overflow-hidden"
          >
            {/* --- Watermarks & Backgrounds --- */}
            
            {/* Top Right Gradient Blob */}
            <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-to-br from-blue-50/40 to-indigo-50/40 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none print:opacity-20" />
            
            {/* Bottom Left Gradient Blob */}
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-teal-50/40 to-blue-50/40 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4 pointer-events-none print:opacity-20" />
            
            {/* Center Brand Icon Watermark */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.02] print:opacity-[0.03]">
               <ShieldCheck className="w-[400px] h-[400px] text-slate-900" />
            </div>

            {/* --- HEADER --- */}
            <header className="relative z-10 px-12 pt-14 pb-8 flex justify-between items-start border-b border-slate-100">
               <div className="flex items-center gap-6">
                  {/* Doctor/Clinic Logo Area */}
                  <div className="w-24 h-24 flex items-center justify-center bg-black rounded-xl p-2 shadow-lg shadow-black/10">
                     <img 
                       src={LOGO_URL} 
                       alt="Rx Logo" 
                       className="w-full h-full object-contain" 
                     />
                  </div>
                  
                  {/* Doctor Info */}
                  <div>
                    <h1 className="text-3xl font-bold text-slate-900 tracking-tight leading-none mb-2">Dr. Pablo M. Peralta Lorca</h1>
                    <div className="flex items-center gap-2 mb-3">
                      <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border border-blue-100 print:bg-slate-100 print:text-slate-900 print:border-slate-300">Mastología</span>
                      <span className="bg-slate-50 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border border-slate-100 print:bg-slate-100 print:border-slate-300">Clínica Médica</span>
                      <span className="bg-slate-50 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border border-slate-100 print:bg-slate-100 print:border-slate-300">Dolor</span>
                    </div>
                    
                    <div className="flex flex-col gap-1 text-xs text-slate-500 font-medium pl-0.5">
                      <span className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-blue-500 print:text-slate-800" /> Calle CW Lencinas 66, Piso 1, San Rafael
                      </span>
                      <span className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-blue-500 print:text-slate-800" /> +54 (260) 464.0945
                      </span>
                    </div>
                  </div>
               </div>

               {/* Date Box */}
               <div className="text-right pt-2">
                 <div className="bg-slate-50 px-5 py-3 rounded-xl border border-slate-200 inline-block text-center min-w-[140px] print:border-slate-300">
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Fecha</span>
                    <span className="block text-xl font-bold text-slate-800 font-mono">
                      {new Date(prescription.prescribed_date).toLocaleDateString('es-AR')}
                    </span>
                 </div>
               </div>
            </header>

            {/* --- MAIN CONTENT --- */}
            <main className="flex-grow relative z-10 px-12 py-10 flex flex-col gap-10">
              
              {/* Patient Info Card */}
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-slate-200 shadow-sm relative overflow-hidden group print:bg-white print:border-slate-300 print:shadow-none">
                <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-blue-500 print:bg-slate-800" />
                
                {/* Top Row: Name, Age, DNI, Coverage */}
                <div className="flex justify-between items-start mb-6">
                  {/* Name Column */}
                  <div className="space-y-1.5 pl-2 max-w-[40%]">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5" /> Paciente
                    </label>
                    <p className="text-2xl font-bold text-slate-800 leading-tight">{patient.name}</p>
                  </div>

                  {/* Age Column */}
                  <div className="space-y-1 text-right min-w-[80px]">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Edad</label>
                      <p className="text-lg font-medium text-slate-700">{patient.age} años</p>
                   </div>

                   {/* DNI Column */}
                   <div className="space-y-1 text-right min-w-[100px]">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">DNI</label>
                      <p className="text-lg font-medium text-slate-700 font-mono">
                        {patient.extended_data?.socialSecurityNumber || '---'}
                      </p>
                   </div>

                   {/* Medical Provider / Coverage Column */}
                   <div className="space-y-1 text-right max-w-[200px]">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Cobertura</label>
                      <p className="text-lg font-medium text-slate-700 truncate" title={coverageDoctor}>
                        {coverageDoctor}
                      </p>
                   </div>
                </div>

                {/* Bottom Row: Obra Social & Affiliate Number */}
                <div className="pt-4 border-t border-slate-100 flex items-center gap-12 pl-2 print:border-slate-200">
                   <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">OBRA SOCIAL</label>
                      <p className="text-base font-bold text-slate-800 uppercase tracking-wide">
                        {obraSocial}
                      </p>
                   </div>
                   
                   <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">NÚMERO DE OBRA SOCIAL</label>
                      <p className="text-base font-bold text-slate-800 font-mono tracking-wide">
                        {nroObraSocial}
                      </p>
                   </div>
                </div>

              </div>

              {/* Prescription Details (Rx) */}
              <div className="flex-grow space-y-8 px-4">
                 
                 {/* Medication Item */}
                 <div className="relative pl-6 border-l-2 border-slate-200 py-2 print:border-slate-800 print:border-l-4">
                    {/* Bullet Point */}
                    <div className="absolute -left-[9px] top-3 w-4 h-4 bg-white border-4 border-blue-500 rounded-full print:border-slate-800" />
                    
                    <div className="mb-6 space-y-4">
                      {/* Commercial Name & Lab */}
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 leading-tight uppercase tracking-tight">
                          {commercialName}
                        </h3>
                        {prescription.laboratory && (
                           <p className="text-lg font-bold text-slate-400 uppercase tracking-widest">
                             {prescription.laboratory}
                           </p>
                        )}
                      </div>

                      {/* Generic Name & Dosage */}
                      <div className="bg-slate-50 border border-slate-100 rounded-lg p-3 inline-block print:border-slate-300">
                        <p className="text-xl text-slate-700 font-medium">
                          <span className="font-bold">Droga: </span>
                          <span className="italic">{prescription.active_ingredients || '---'}</span>
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-4 mb-8">
                      {/* Dosage Badge */}
                      <div className="flex items-center gap-3 px-4 py-3 bg-slate-50 rounded-xl border border-slate-100 min-w-[180px] print:border-slate-300">
                         <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center print:bg-slate-100 print:text-slate-900">
                           <Scale className="w-4 h-4" />
                         </div>
                         <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Dosis</span>
                            <span className="font-bold text-slate-700">{prescription.dosage || 'S/D'}</span>
                         </div>
                      </div>

                      {/* Frequency Badge */}
                      <div className="flex items-center gap-3 px-4 py-3 bg-slate-50 rounded-xl border border-slate-100 min-w-[180px] print:border-slate-300">
                         <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center print:bg-slate-100 print:text-slate-900">
                           <Clock className="w-4 h-4" />
                         </div>
                         <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Frecuencia</span>
                            <span className="font-bold text-slate-700">{prescription.frequency}</span>
                         </div>
                      </div>

                      {/* Duration Badge */}
                      <div className="flex items-center gap-3 px-4 py-3 bg-slate-50 rounded-xl border border-slate-100 min-w-[180px] print:border-slate-300">
                         <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center print:bg-slate-100 print:text-slate-900">
                           <Calendar className="w-4 h-4" />
                         </div>
                         <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Duración</span>
                            <span className="font-bold text-slate-700">{prescription.duration}</span>
                         </div>
                      </div>
                    </div>

                    {/* Instructions Box */}
                    {prescription.instructions && (
                      <div className="bg-blue-50/60 p-6 rounded-2xl border border-blue-100/50 text-slate-700 print:bg-white print:border-slate-300">
                        <span className="flex items-center gap-2 text-xs font-bold text-blue-600 uppercase tracking-wider mb-2 print:text-slate-800">
                           <Pill className="w-3.5 h-3.5" /> Indicaciones
                        </span>
                        <p className="text-base leading-relaxed font-medium opacity-90 whitespace-pre-line">
                          {prescription.instructions}
                        </p>
                      </div>
                    )}
                 </div>

              </div>
            </main>

            {/* --- FOOTER --- */}
            <footer className="relative z-10 px-12 pb-12 pt-4 mt-auto">
               <div className="flex justify-between items-end border-t-2 border-slate-100 pt-8 print:border-slate-300">
                  
                  {/* Legal Text */}
                  <div className="max-w-[50%] space-y-2">
                     <div className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-emerald-500 print:text-slate-800" />
                        <span className="text-xs font-bold text-slate-600 uppercase tracking-wide">Receta Válida</span>
                     </div>
                     <p className="text-[10px] text-slate-400 leading-relaxed text-justify">
                        Esta prescripción tiene una validez de 30 días corridos a partir de su fecha de emisión. 
                        Válida para farmacias en todo el territorio nacional según Ley 25.506 de Firma Digital.
                        Centro Médico Integral.
                     </p>
                  </div>

                  {/* Signature Block */}
                  <div className="text-center relative min-w-[240px]">
                     <div className="absolute bottom-full left-0 right-0 h-24 mb-1 flex items-end justify-center">
                        <span className="font-dancing-script text-4xl text-blue-900 opacity-80 rotate-[-4deg] block pb-2 drop-shadow-sm print:text-black">
                           Pablo Peralta
                        </span>
                     </div>
                     
                     <div className="border-t border-slate-800 pt-3">
                        <p className="text-base font-bold text-slate-900">Dr. Pablo Peralta Lorca</p>
                        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-0.5">MP 13652</p>
                        <p className="text-[10px] text-slate-400 font-medium">Especialista en Mastología y Clínica</p>
                     </div>
                  </div>
               </div>

               {/* Bottom Color Bar */}
               <div className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 print:hidden" />
               <div className="absolute bottom-0 left-0 right-0 h-1 bg-black hidden print:block" />
            </footer>

          </div>
        </div>
        
        {/* CSS for Print & Fonts */}
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap');
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700;900&display=swap');
          
          .font-dancing-script {
            font-family: 'Dancing Script', cursive;
          }

          @media print {
            @page {
              size: A4;
              margin: 0;
            }

            /* 1. Hide the entire document body initially using visibility */
            /* We use visibility instead of display:none to preserve layout if needed, 
               but primarily to avoid detaching certain React portals or breaking scripts */
            body {
              visibility: hidden;
              background-color: white !important;
            }

            /* 2. Target our specific print content container */
            #prescription-content {
              visibility: visible !important;
              position: absolute !important;
              left: 0 !important;
              top: 0 !important;
              
              /* Force dimensions to fill the print page */
              width: 100% !important;
              margin: 0 !important;
              padding: 0 !important;
              
              /* Ensure it's on top of everything */
              z-index: 99999 !important;
              
              /* Ensure background is white and opaque */
              background-color: white !important;
            }

            /* 3. Ensure all children of the prescription are visible */
            #prescription-content * {
              visibility: visible !important;
            }
            
            /* 4. Hide standard UI elements that shouldn't print */
            .print\\:hidden, 
            [role="presentation"], 
            .sticky.top-0,
            button,
            [role="dialog"] > button {
              display: none !important;
            }

            /* 5. Force background graphics to print */
            * {
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
          }
        `}</style>
      </DialogContent>
    </Dialog>
  );
};

export default PrescriptionDocument;
