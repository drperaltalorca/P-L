
// This component is now redundant as MedicationsDatabase is removed from App.jsx, but cannot be deleted.
// Leaving as is, but it's no longer actively used by the application flow.
import React from 'react';
import { cn } from '@/lib/utils';

// --- Pill Render Component ---
export const PillPreview = ({ type = 'tablet-round', color1 = '#fff', color2 = '#fff', imprint, className }) => {
  
  // Base styles for pill shadow and lighting
  const lightingEffect = "shadow-[inset_-2px_-2px_6px_rgba(0,0,0,0.1),inset_2px_2px_6px_rgba(255,255,255,0.7),0_4px_6px_rgba(0,0,0,0.1)]";
  const softgelEffect = "shadow-[inset_-2px_-2px_8px_rgba(0,0,0,0.2),inset_4px_4px_10px_rgba(255,255,255,0.8),0_4px_8px_rgba(0,0,0,0.1)] opacity-90 backdrop-blur-sm border border-white/20";

  const renderShape = () => {
    switch(type) {
      case 'capsule-2': // Dual color capsule
        return (
          <div className={cn("w-16 h-8 rounded-full flex overflow-hidden relative rotate-12", lightingEffect, className)}>
            <div className="w-1/2 h-full" style={{ backgroundColor: color1 }}></div>
            <div className="w-1/2 h-full" style={{ backgroundColor: color2 }}></div>
            {/* Specular highlight */}
            <div className="absolute top-1 left-2 w-10 h-2 bg-white/40 rounded-full blur-[1px]"></div>
          </div>
        );
      
      case 'capsule': // Single color capsule
        return (
          <div 
            className={cn("w-16 h-8 rounded-full relative rotate-12", lightingEffect, className)}
            style={{ backgroundColor: color1 }}
          >
            <div className="absolute top-1 left-2 w-10 h-2 bg-white/40 rounded-full blur-[1px]"></div>
          </div>
        );

      case 'softgel': // Transparent softgel
        return (
           <div 
            className={cn("w-14 h-9 rounded-[40%] relative rotate-[-10deg]", softgelEffect, className)}
            style={{ backgroundColor: color1 }}
          >
            <div className="absolute top-2 left-3 w-6 h-3 bg-white/60 rounded-full blur-[2px]"></div>
          </div>
        );

      case 'tablet-oblong': // Long tablet
        return (
          <div 
            className={cn("w-16 h-8 rounded-xl relative flex items-center justify-center", lightingEffect, className)}
            style={{ backgroundColor: color1 }}
          >
             {imprint && <span className="text-[10px] font-bold text-black/20 transform rotate-0">{imprint}</span>}
          </div>
        );

      case 'tablet-scored': // Round with line
        return (
          <div 
            className={cn("w-12 h-12 rounded-full relative flex items-center justify-center", lightingEffect, className)}
            style={{ backgroundColor: color1 }}
          >
            <div className="w-[1px] h-full bg-black/10 absolute top-0 left-1/2 -translate-x-1/2"></div>
            {imprint && <span className="text-[9px] font-bold text-black/20 absolute bottom-2">{imprint}</span>}
          </div>
        );

      default: // Round tablet
        return (
          <div 
            className={cn("w-12 h-12 rounded-full relative flex items-center justify-center", lightingEffect, className)}
            style={{ backgroundColor: color1 }}
          >
             {imprint && <span className="text-[10px] font-bold text-black/20">{imprint}</span>}
          </div>
        );
    }
  };

  return (
    <div className="w-24 h-24 flex items-center justify-center bg-slate-50/50 rounded-xl border border-slate-100/50">
      {renderShape()}
    </div>
  );
};


// --- Box Render Component ---
export const BoxPreview = ({ laboratory, name, presentation, visuals }) => {
  const { color = '#3b82f6', accent = '#fff', style = 'modern' } = visuals?.box || {};

  return (
    <div className="relative group w-full h-full min-h-[140px] perspective-[1000px]">
      {/* 3D Box Face */}
      <div 
        className="w-full h-full rounded-lg shadow-lg relative overflow-hidden transition-transform duration-500 ease-out group-hover:rotate-y-6 group-hover:rotate-x-2"
        style={{ 
          background: `linear-gradient(135deg, white 0%, #f8fafc 100%)`,
          borderLeft: `8px solid ${color}` 
        }}
      >
        {/* Brand Stripe/Design */}
        <div 
          className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none" 
          style={{ 
             background: style === 'gradient' 
               ? `linear-gradient(45deg, ${color}, transparent)` 
               : `radial-gradient(circle at top right, ${color}, transparent 60%)`
          }} 
        />
        
        {/* Accent Shape */}
        <div 
          className="absolute -top-10 -right-10 w-32 h-32 rounded-full opacity-20 blur-xl"
          style={{ backgroundColor: color }}
        />

        <div className="p-4 relative z-10 flex flex-col h-full justify-between">
          {/* Top: Lab */}
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              {laboratory}
            </span>
             {/* Fake hologram/verification seal */}
             <div className="w-4 h-4 rounded-full bg-gradient-to-tr from-yellow-300 to-amber-500 shadow-sm opacity-60"></div>
          </div>

          {/* Middle: Name */}
          <div className="my-2">
            <h3 className="font-extrabold text-xl leading-tight text-slate-800" style={{ color: style === 'minimal' ? '#334155' : color }}>
              {name}
            </h3>
            {/* Decorative line */}
            <div className="h-1 w-12 mt-1 rounded-full" style={{ backgroundColor: accent }}></div>
          </div>

          {/* Bottom: Info */}
          <div>
             <p className="text-[10px] text-slate-500 font-medium leading-tight line-clamp-2">
              {presentation}
            </p>
            <div className="mt-2 flex gap-1">
               <div className="h-1.5 w-1.5 rounded-full bg-slate-200"></div>
               <div className="h-1.5 w-1.5 rounded-full bg-slate-200"></div>
               <div className="h-1.5 w-8 rounded-full bg-slate-200"></div>
            </div>
          </div>
        </div>

        {/* Side panel simulation for 3D effect */}
        <div 
          className="absolute top-0 right-0 w-2 h-full bg-slate-200/50 origin-right transform rotate-y-90 translate-x-full opacity-0 group-hover:opacity-100 transition-opacity"
        ></div>
      </div>
    </div>
  );
};
