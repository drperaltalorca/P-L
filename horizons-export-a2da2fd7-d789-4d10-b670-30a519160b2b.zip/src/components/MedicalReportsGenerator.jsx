
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  Printer, 
  Search, 
  User, 
  Calendar, 
  Download, 
  History, 
  PenTool, 
  FileCheck,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import FormField from '@/components/FormField';
import SelectField from '@/components/SelectField';
import TextAreaField from '@/components/TextAreaField';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const LOGO_URL = "https://horizons-cdn.hostinger.com/a2da2fd7-d789-4d10-b670-30a519160b2b/6d05420aa8885edfe961d61427d0e3be.jpg";

const MedicalReportsGenerator = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('generator'); // 'generator', 'history'
  const [loading, setLoading] = useState(false);
  const [patientSearch, setPatientSearch] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [reportHistory, setReportHistory] = useState([]);
  
  // Report Configuration
  const [reportConfig, setReportConfig] = useState({
    type: 'general',
    dateStart: new Date(new Date().setMonth(new Date().getMonth() - 6)).toISOString().split('T')[0],
    dateEnd: new Date().toISOString().split('T')[0],
    customNotes: '',
    doctorSignature: ''
  });

  // Data for Report
  const [reportData, setReportData] = useState(null);

  const printRef = useRef();

  useEffect(() => {
    if (selectedPatient) {
      fetchReportData();
      fetchHistory();
    }
  }, [selectedPatient, reportConfig.dateStart, reportConfig.dateEnd]);

  // Search Patients
  const handleSearch = async (term) => {
    setPatientSearch(term);
    if (term.length < 2) {
      setSearchResults([]);
      return;
    }

    const { data, error } = await supabase
      .from('patients')
      .select('id, name, age, photo_url')
      .ilike('name', `%${term}%`)
      .limit(5);

    if (!error) setSearchResults(data);
  };

  const selectPatient = (patient) => {
    setSelectedPatient(patient);
    setSearchResults([]);
    setPatientSearch('');
  };

  // Fetch Data for Report
  const fetchReportData = async () => {
    if (!selectedPatient) return;
    setLoading(true);

    try {
      // Fetch full patient details
      const { data: patient } = await supabase
        .from('patients')
        .select('*')
        .eq('id', selectedPatient.id)
        .single();

      // Fetch Clinical History in range
      const { data: history } = await supabase
        .from('clinical_history')
        .select('*')
        .eq('patient_id', selectedPatient.id)
        .gte('visit_date', reportConfig.dateStart)
        .lte('visit_date', reportConfig.dateEnd)
        .order('visit_date', { ascending: false });

      // Fetch Active Prescriptions
      const { data: prescriptions } = await supabase
        .from('prescriptions')
        .select('*')
        .eq('patient_id', selectedPatient.id)
        .eq('status', 'Active');

      setReportData({
        patient,
        history: history || [],
        prescriptions: prescriptions || [],
        generatedAt: new Date().toISOString()
      });

    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Error al cargar datos del reporte", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const fetchHistory = async () => {
    const { data } = await supabase
      .from('generated_reports')
      .select('*')
      .eq('patient_id', selectedPatient.id)
      .order('created_at', { ascending: false });
    
    setReportHistory(data || []);
  };

  const handlePrint = async () => {
    window.print();
    
    // Save to history automatically on print
    if (selectedPatient && reportData) {
      try {
        await supabase.from('generated_reports').insert([{
          patient_id: selectedPatient.id,
          report_type: reportConfig.type,
          report_date: new Date(),
          date_range_start: reportConfig.dateStart,
          date_range_end: reportConfig.dateEnd,
          content_snapshot: reportData, // Saving the data snapshot
          custom_notes: reportConfig.customNotes,
          doctor_signature: reportConfig.doctorSignature
        }]);
        fetchHistory();
        toast({ title: "Guardado", description: "El reporte se guardó en el historial." });
      } catch (err) {
        console.error("Error saving report history:", err);
      }
    }
  };

  // Template Renderers
  const renderTemplate = () => {
    if (!reportData) return null;
    const { patient, history, prescriptions } = reportData;

    const Header = () => (
      <div className="border-b-2 border-slate-800 pb-6 mb-8 flex justify-between items-start">
        <div className="flex gap-6 items-start">
           {/* Logo Integration */}
           <div className="w-16 h-16 bg-black rounded-lg p-1.5 flex items-center justify-center shrink-0">
             <img src={LOGO_URL} alt="P+L" className="w-full h-full object-contain" />
           </div>
           <div>
             <h1 className="text-3xl font-bold text-slate-900 uppercase tracking-wide">
               {reportConfig.type === 'referral' ? 'Carta de Derivación' : 
                reportConfig.type === 'prescription' ? 'Resumen de Prescripciones' :
                reportConfig.type === 'clinical' ? 'Resumen Clínico' : 'Informe Médico General'}
             </h1>
             <p className="text-slate-500 mt-2">Clínica Médica Integral</p>
             <p className="text-slate-500 text-sm">Fecha de Emisión: {new Date().toLocaleDateString()}</p>
           </div>
        </div>
        <div className="text-right pt-2">
          <h3 className="font-bold text-slate-800 text-lg">Dr/a. {reportConfig.doctorSignature || '[Firma Pendiente]'}</h3>
          <p className="text-slate-500 text-sm">Medicina General</p>
        </div>
      </div>
    );

    const PatientInfo = () => (
      <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 mb-8 text-sm">
        <h3 className="font-bold text-slate-900 mb-4 uppercase text-xs tracking-wider border-b border-slate-200 pb-2">Datos del Paciente</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <span className="block text-slate-500 text-xs uppercase">Nombre</span>
            <span className="font-semibold text-slate-900 text-base">{patient.name}</span>
          </div>
          <div>
            <span className="block text-slate-500 text-xs uppercase">ID/Historia</span>
            <span className="font-mono text-slate-900">{patient.id.slice(0, 8)}</span>
          </div>
          <div>
            <span className="block text-slate-500 text-xs uppercase">Edad / Sexo</span>
            <span className="text-slate-900">{patient.age} años / {patient.gender}</span>
          </div>
          <div>
            <span className="block text-slate-500 text-xs uppercase">Condiciones</span>
            <span className="text-slate-900">{patient.medical_conditions?.join(', ') || 'Ninguna'}</span>
          </div>
        </div>
      </div>
    );

    const VitalsSummary = () => {
      if (!history.length || !history[0].vital_signs) return null;
      const latest = history[0].vital_signs;
      return (
        <div className="mb-8">
           <h3 className="font-bold text-slate-900 mb-3 uppercase text-xs tracking-wider border-b border-slate-200 pb-2">Últimos Signos Vitales ({new Date(history[0].visit_date).toLocaleDateString()})</h3>
           <div className="grid grid-cols-4 gap-4 text-center">
             <div className="p-3 bg-white border border-slate-200 rounded-lg">
               <span className="block text-xs text-slate-500 uppercase">Presión</span>
               <span className="font-bold text-slate-900">{latest.bp || '--'}</span>
             </div>
             <div className="p-3 bg-white border border-slate-200 rounded-lg">
               <span className="block text-xs text-slate-500 uppercase">Frec. Card.</span>
               <span className="font-bold text-slate-900">{latest.hr || '--'} bpm</span>
             </div>
             <div className="p-3 bg-white border border-slate-200 rounded-lg">
               <span className="block text-xs text-slate-500 uppercase">Peso</span>
               <span className="font-bold text-slate-900">{latest.weight || '--'} kg</span>
             </div>
             <div className="p-3 bg-white border border-slate-200 rounded-lg">
               <span className="block text-xs text-slate-500 uppercase">Temp</span>
               <span className="font-bold text-slate-900">{latest.temp || '--'} °C</span>
             </div>
           </div>
        </div>
      );
    }

    const ClinicalNotes = () => (
      <div className="mb-8">
        <h3 className="font-bold text-slate-900 mb-3 uppercase text-xs tracking-wider border-b border-slate-200 pb-2">Historial Clínico ({reportConfig.dateStart} - {reportConfig.dateEnd})</h3>
        {history.length === 0 ? (
          <p className="text-slate-500 italic text-sm">No se registraron visitas en este período.</p>
        ) : (
          <div className="space-y-4">
            {history.map(record => (
              <div key={record.id} className="mb-4">
                <div className="flex items-center gap-2 mb-1">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span className="font-bold text-sm text-slate-900">{new Date(record.visit_date).toLocaleDateString()}</span>
                  <span className="text-xs px-2 py-0.5 bg-slate-100 rounded-full text-slate-600 uppercase">{record.visit_type}</span>
                </div>
                <div className="ml-5 text-sm text-slate-700">
                  <p><span className="font-medium">Diagnóstico:</span> {record.diagnosis || 'Sin diagnóstico'}</p>
                  {reportConfig.type !== 'referral' && <p className="mt-1 text-slate-600">{record.clinical_notes}</p>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );

    const Prescriptions = () => (
      <div className="mb-8">
        <h3 className="font-bold text-slate-900 mb-3 uppercase text-xs tracking-wider border-b border-slate-200 pb-2">Medicación Activa</h3>
        {prescriptions.length === 0 ? (
          <p className="text-slate-500 italic text-sm">Sin medicación activa registrada.</p>
        ) : (
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="p-2 font-medium">Medicamento</th>
                <th className="p-2 font-medium">Dosis/Frecuencia</th>
                <th className="p-2 font-medium">Duración</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {prescriptions.map(p => (
                <tr key={p.id}>
                  <td className="p-2 font-medium text-slate-900">{p.medication_name}</td>
                  <td className="p-2 text-slate-600">{p.frequency}</td>
                  <td className="p-2 text-slate-600">{p.duration}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    );

    const CustomSection = () => (
      reportConfig.customNotes && (
        <div className="mb-8">
          <h3 className="font-bold text-slate-900 mb-3 uppercase text-xs tracking-wider border-b border-slate-200 pb-2">Observaciones Adicionales</h3>
          <div className="text-sm text-slate-800 whitespace-pre-wrap leading-relaxed p-4 bg-yellow-50/50 rounded-lg border border-yellow-100">
            {reportConfig.customNotes}
          </div>
        </div>
      )
    );

    const Signature = () => (
      <div className="mt-16 flex justify-end">
        <div className="text-center w-64">
          {reportConfig.doctorSignature ? (
             <div className="font-script text-3xl text-indigo-900 mb-2" style={{fontFamily: 'cursive'}}>
               {reportConfig.doctorSignature}
             </div>
          ) : (
            <div className="h-12 border-b border-slate-300 mb-2"></div>
          )}
          <p className="text-sm font-bold text-slate-900 border-t border-slate-300 pt-2">Firma del Profesional</p>
          <p className="text-xs text-slate-500">M.P. _________________</p>
        </div>
      </div>
    );

    // Template Structures
    return (
      <div className="max-w-[210mm] mx-auto bg-white p-12 min-h-[297mm] shadow-none print:shadow-none">
        <Header />
        
        {reportConfig.type === 'referral' ? (
          <div className="space-y-8">
            <div className="text-sm text-slate-900 space-y-1">
              <p className="font-bold">A QUIEN CORRESPONDA:</p>
              <p>Se deriva al paciente detallado a continuación para evaluación y tratamiento.</p>
            </div>
            <PatientInfo />
            <CustomSection /> {/* Reason for referral usually goes here */}
            <ClinicalNotes />
            <Prescriptions />
          </div>
        ) : reportConfig.type === 'prescription' ? (
          <div className="space-y-8">
            <PatientInfo />
            <Prescriptions />
            <CustomSection />
          </div>
        ) : (
          <div className="space-y-6">
            <PatientInfo />
            <VitalsSummary />
            <ClinicalNotes />
            <Prescriptions />
            <CustomSection />
          </div>
        )}

        <Signature />
        
        <div className="mt-12 pt-6 border-t border-slate-100 text-center text-xs text-slate-400 print:fixed print:bottom-4 print:left-0 print:w-full">
          Generado electrónicamente el {new Date().toLocaleString()} • Página 1 de 1
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white/60 backdrop-blur-xl p-6 rounded-2xl shadow-sm border border-white/50 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 no-print">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl shadow-lg shadow-cyan-500/20 text-white">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Generador de Informes</h1>
            <p className="text-slate-500 text-sm">Crea, previsualiza y exporta documentación médica oficial</p>
          </div>
        </div>

        {selectedPatient && (
          <div className="flex bg-slate-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('generator')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'generator' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'}`}
            >
              Nuevo Informe
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'history' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'}`}
            >
              Historial ({reportHistory.length})
            </button>
          </div>
        )}
      </div>

      {!selectedPatient ? (
        <div className="bg-white rounded-3xl p-12 text-center shadow-sm border border-slate-100 max-w-2xl mx-auto mt-12">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Search className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Seleccionar Paciente</h2>
          <p className="text-slate-500 mb-8">Buscá un paciente por nombre para comenzar a generar informes.</p>
          
          <div className="relative max-w-md mx-auto">
            <input
              type="text"
              placeholder="Buscar paciente..."
              value={patientSearch}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-xl border border-slate-200 shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-lg"
              autoFocus
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            
            {searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-slate-100 overflow-hidden z-20">
                {searchResults.map(patient => (
                  <button
                    key={patient.id}
                    onClick={() => selectPatient(patient)}
                    className="w-full text-left p-4 hover:bg-slate-50 flex items-center gap-3 transition-colors border-b border-slate-50 last:border-0"
                  >
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold">
                      {patient.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{patient.name}</p>
                      <p className="text-xs text-slate-500">ID: {patient.id.slice(0, 8)} • {patient.age} años</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : activeTab === 'generator' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sidebar Controls - Hidden when printing */}
          <div className="lg:col-span-4 space-y-6 no-print">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex items-center justify-between mb-6">
                 <h3 className="font-bold text-slate-900">Configuración</h3>
                 <Button variant="ghost" size="sm" onClick={() => setSelectedPatient(null)} className="text-red-500 hover:text-red-600 hover:bg-red-50 h-8">
                   Cambiar Paciente
                 </Button>
              </div>

              <div className="space-y-4">
                <SelectField
                  label="Tipo de Informe"
                  value={reportConfig.type}
                  onChange={(v) => setReportConfig({...reportConfig, type: v})}
                  options={[
                    { value: 'general', label: 'Informe Médico General' },
                    { value: 'clinical', label: 'Resumen Clínico' },
                    { value: 'prescription', label: 'Resumen de Prescripciones' },
                    { value: 'referral', label: 'Carta de Derivación' }
                  ]}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    label="Desde"
                    type="date"
                    value={reportConfig.dateStart}
                    onChange={(v) => setReportConfig({...reportConfig, dateStart: v})}
                  />
                  <FormField
                    label="Hasta"
                    type="date"
                    value={reportConfig.dateEnd}
                    onChange={(v) => setReportConfig({...reportConfig, dateEnd: v})}
                  />
                </div>

                <TextAreaField
                  label={reportConfig.type === 'referral' ? "Motivo de Derivación" : "Notas Adicionales"}
                  placeholder={reportConfig.type === 'referral' ? "Describa el motivo de la interconsulta..." : "Observaciones, recomendaciones, etc."}
                  value={reportConfig.customNotes}
                  onChange={(v) => setReportConfig({...reportConfig, customNotes: v})}
                  rows={4}
                />

                <FormField
                  label="Firma del Doctor (Texto)"
                  placeholder="Dr. Juan Pérez"
                  icon={<PenTool className="w-4 h-4" />}
                  value={reportConfig.doctorSignature}
                  onChange={(v) => setReportConfig({...reportConfig, doctorSignature: v})}
                />
              </div>

              <div className="pt-6 mt-6 border-t border-slate-100 flex flex-col gap-3">
                <Button 
                  onClick={handlePrint}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white h-12 text-base shadow-xl shadow-slate-900/10"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Imprimir / Guardar PDF
                </Button>
              </div>
            </div>
          </div>

          {/* Preview Area */}
          <div className="lg:col-span-8">
            <div className="bg-slate-500/5 p-8 rounded-3xl border border-slate-200/60 overflow-auto min-h-[800px] flex justify-center">
              <div ref={printRef} className="w-full bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-300 origin-top">
                {renderTemplate()}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* History Tab */
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center">
             <h3 className="font-bold text-slate-900">Historial de Informes de {selectedPatient.name}</h3>
             <Button variant="outline" size="sm" onClick={() => fetchHistory()}>
               <History className="w-4 h-4 mr-2" /> Actualizar
             </Button>
          </div>
          
          {reportHistory.length === 0 ? (
            <div className="p-12 text-center text-slate-400">
              <FileCheck className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>No hay informes generados previamente.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {reportHistory.map((report) => (
                <div key={report.id} className="p-6 hover:bg-slate-50 transition-colors flex items-center justify-between group">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-100 transition-colors">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 capitalize">
                        {report.report_type === 'general' ? 'Informe General' :
                         report.report_type === 'clinical' ? 'Resumen Clínico' :
                         report.report_type === 'referral' ? 'Carta de Derivación' : report.report_type}
                      </h4>
                      <p className="text-sm text-slate-500 flex items-center gap-2 mt-1">
                        <Calendar className="w-3 h-3" />
                        Generado el {new Date(report.created_at).toLocaleDateString()} a las {new Date(report.created_at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                      </p>
                      {report.custom_notes && (
                        <p className="text-xs text-slate-400 mt-2 line-clamp-1 italic">"{report.custom_notes}"</p>
                      )}
                    </div>
                  </div>
                  
                  {/* Since we don't store PDF blob, we can't "Download" exactly what was printed unless we reconstruct it. 
                      For now, showing metadata is enough for history, or we could add a "Re-generate" button that loads config into generator */}
                  <Button 
                    variant="ghost" 
                    onClick={() => {
                      setReportConfig({
                        type: report.report_type,
                        dateStart: report.date_range_start || reportConfig.dateStart,
                        dateEnd: report.date_range_end || reportConfig.dateEnd,
                        customNotes: report.custom_notes || '',
                        doctorSignature: report.doctor_signature || ''
                      });
                      setActiveTab('generator');
                      toast({ title: "Cargado", description: "Configuración del informe cargada en el generador." });
                    }}
                  >
                    Ver / Regenerar
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Print Styles */}
      <style>{`
        @media print {
          @page { margin: 0; size: auto; }
          body { background: white; -webkit-print-color-adjust: exact; }
          .no-print { display: none !important; }
          /* Ensure the preview container takes full width and removes shadows/backgrounds */
          .lg\\:col-span-8 { width: 100% !important; margin: 0 !important; padding: 0 !important; }
          div[class*="bg-slate-500/5"] { background: none !important; border: none !important; padding: 0 !important; }
          div[class*="shadow-2xl"] { box-shadow: none !important; }
        }
      `}</style>
    </div>
  );
};

export default MedicalReportsGenerator;
