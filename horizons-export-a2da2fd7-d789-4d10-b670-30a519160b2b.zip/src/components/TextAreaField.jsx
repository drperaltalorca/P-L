import React from 'react';

const TextAreaField = ({ label, value, onChange, placeholder = '', className = '', icon, highlight = false }) => {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <div className="flex items-center justify-between">
        <label className={`block text-sm font-medium ml-1 ${highlight ? 'text-rose-600' : 'text-slate-600'}`}>
          {label}
        </label>
      </div>
      <div className="relative group">
        {icon && (
          <div className="absolute left-3.5 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors">
            {icon}
          </div>
        )}
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={3}
          className={`
            w-full bg-slate-50 border text-slate-900 text-sm rounded-xl 
            focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 block p-3
            transition-all duration-200 ease-in-out resize-none
            placeholder:text-slate-400
            ${highlight ? 'border-rose-200 focus:ring-rose-500/20 focus:border-rose-500 bg-rose-50/50' : 'border-slate-200'}
            ${icon ? 'pl-10' : 'pl-4'}
          `}
        />
      </div>
    </div>
  );
};

export default TextAreaField;