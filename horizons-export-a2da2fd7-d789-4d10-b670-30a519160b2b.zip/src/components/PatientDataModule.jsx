
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Save, Info, Sparkles, Upload, Image as ImageIcon, X, ScanLine, Loader2, CheckCircle2 } from 'lucide-react';
import IdentificationSection from '@/components/sections/IdentificationSection';
import DemographicsSection from '@/components/sections/DemographicsSection';
import ClinicalHistorySection from '@/components/sections/ClinicalHistorySection';
import MeasurementsSection from '@/components/sections/MeasurementsSection';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const PatientDataModule = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  
  // Photo State (Face)
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);

  // Document State (DNI)
  const [docFile, setDocFile] = useState(null);
  const [docPreview, setDocPreview] = useState(null);
  const [ocrSuccess, setOcrSuccess] = useState(false);

  const [formData, setFormData] = useState({
    // Identification
    historyNumber: '',
    socialSecurityNumber: '',
    openingDate: new Date().toISOString().split('T')[0],
    name: '',
    medicalProvider: '', // This is the Doctor
    healthInsurance: '', // New field: Obra Social
    affiliateNumber: '', // New field: N° Afiliado
    // Demographics
    birthDate: '',
    sex: '',
    address: '',
    phone: '',
    maritalStatus: '',
    education: '',
    profession: '',
    employmentStatus: '',
    laborRisks: '',
    // Clinical History
    riskFactors: '',
    toxicHabits: '',
    drugAllergies: '',
    personalHistory: '',
    surgicalInterventions: '',
    immunizationStatus: '',
    chronicMedications: '',
    // Measurements
    bloodPressure: '',
    weight: '',
    height: '',
    gynecologicalControl: '',
    lastBreastControl: ''
  });

  const updateFormData = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // --- Face Photo Logic ---
  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
  };

  // --- DNI/OCR Logic ---
  const handleDocumentChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // 1. Set Preview
    setDocFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result;
      setDocPreview(base64String);
      // 2. Start OCR Process immediately after selection
      processDocumentOCR(base64String);
    };
    reader.readAsDataURL(file);
  };

  const processDocumentOCR = async (base64String) => {
    setIsScanning(true);
    setOcrSuccess(false);
    
    try {
      // Remove data:image/jpeg;base64, prefix for the API
      const base64Data = base64String.split(',')[1];

      // Invoke the Edge Function
      const { data, error } = await supabase.functions.invoke('analyze-id-card', {
        body: JSON.stringify({ image: base64Data })
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      // --- AUTO-FILL LOGIC ---
      const { name, surname, idNumber, birthDate, gender, address } = data;
      
      // Combine name and surname properly
      const fullName = [name, surname].filter(Boolean).join(' ');
      
      // Map gender to internal values
      let mappedGender = 'other';
      if (gender?.toLowerCase().includes('masc')) mappedGender = 'male';
      if (gender?.toLowerCase().includes('fem')) mappedGender = 'female';

      setFormData(prev => ({
        ...prev,
        name: fullName || prev.name,
        socialSecurityNumber: idNumber || prev.socialSecurityNumber,
        birthDate: birthDate || prev.birthDate,
        address: address || prev.address,
        sex: mappedGender !== 'other' ? mappedGender : prev.sex
      }));

      setOcrSuccess(true);
      toast({
        title: "¡Datos Extraídos!",
        description: "Se han completado automáticamente los campos: Nombre, DNI, Fecha Nac. y Dirección.",
        className: "bg-green-50 border-green-200 text-green-800"
      });

    } catch (err) {
      console.error("OCR Error:", err);
      toast({
        title: "No se pudo leer el documento",
        description: "Intente con una foto más clara o complete los datos manualmente.",
        variant: "destructive"
      });
    } finally {
      setIsScanning(false);
    }
  };

  const removeDoc = () => {
    setDocFile(null);
    setDocPreview(null);
    setOcrSuccess(false);
  };

  const uploadFileToBucket = async (file, bucket) => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from(bucket)
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error(`Error uploading to ${bucket}:`, error);
      throw error;
    }
  };

  // --- Save Logic ---
  const handleSave = async () => {
    if (!formData.name || !formData.socialSecurityNumber) {
      toast({
        title: "Faltan datos",
        description: "Por favor completá al menos el Nombre y el DNI.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Upload Face Photo
      let photoUrl = null;
      if (photoFile) {
        photoUrl = await uploadFileToBucket(photoFile, 'patient-photos');
      }

      // 2. Upload Document Photo
      let documentUrl = null;
      if (docFile) {
        documentUrl = await uploadFileToBucket(docFile, 'patient-documents');
      }

      // 3. Prepare Patient Data
      const patientData = {
        name: formData.name,
        gender: formData.sex === 'male' ? 'Masculino' : formData.sex === 'female' ? 'Femenino' : 'Otro',
        age: formData.birthDate ? new Date().getFullYear() - new Date(formData.birthDate).getFullYear() : 0,
        medical_conditions: formData.personalHistory ? [formData.personalHistory] : [],
        medications: formData.chronicMedications ? [formData.chronicMedications] : [],
        lab_studies: [],
        imaging_studies: [],
        photo_url: photoUrl,
        extended_data: {
          ...formData,
          document_url: documentUrl, // Save link to the document image
          document_scanned_at: new Date().toISOString()
        }
      };

      const { error } = await supabase
        .from('patients')
        .insert([patientData]);

      if (error) throw error;

      toast({
        title: "Paciente Registrado",
        description: "El paciente y su documentación se han guardado correctamente.",
        className: "bg-green-50 border-green-200 text-green-800",
      });

      // Reset
      setFormData({
        historyNumber: '',
        socialSecurityNumber: '',
        openingDate: new Date().toISOString().split('T')[0],
        name: '',
        medicalProvider: '',
        healthInsurance: '',
        affiliateNumber: '',
        birthDate: '',
        sex: '',
        address: '',
        phone: '',
        maritalStatus: '',
        education: '',
        profession: '',
        employmentStatus: '',
        laborRisks: '',
        riskFactors: '',
        toxicHabits: '',
        drugAllergies: '',
        personalHistory: '',
        surgicalInterventions: '',
        immunizationStatus: '',
        chronicMedications: '',
        bloodPressure: '',
        weight: '',
        height: '',
        gynecologicalControl: '',
        lastBreastControl: ''
      });
      removePhoto();
      removeDoc();

    } catch (error) {
      console.error('Error saving patient:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar el registro en la base de datos.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto pb-12">
      {/* Background decoration */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-blue-100 blur-[120px] opacity-50" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-purple-100 blur-[120px] opacity-50" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 bg-white/60 backdrop-blur-xl p-6 rounded-2xl shadow-sm border border-white/50">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl shadow-lg shadow-blue-500/20 text-white">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700">
                Nuevo Paciente
              </h1>
              <p className="text-slate-500 text-sm">
                Registro completo con escaneo inteligente de DNI
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-700 rounded-full text-sm font-medium border border-green-100">
            <Info className="w-4 h-4" />
            <span>Base de Datos Conectada</span>
          </div>
        </div>

        {/* --- OCR & Photo Section --- */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* DNI Scanner Widget */}
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-3xl p-6 shadow-sm border border-indigo-100 relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <ScanLine className="w-32 h-32 text-indigo-600" />
             </div>
             
             <h3 className="text-lg font-bold text-indigo-900 mb-2 flex items-center gap-2">
               <ScanLine className="w-5 h-5" />
               Escanear DNI / Pasaporte
             </h3>
             <p className="text-indigo-600/80 text-sm mb-6 max-w-sm">
               Subí una foto del documento para extraer automáticamente el Nombre, DNI, Fecha de Nacimiento y más.
             </p>

             <div className="flex items-center gap-4">
                <div className="relative">
                   {docPreview ? (
                      <div className="relative w-32 h-20 rounded-xl overflow-hidden border-2 border-indigo-200 shadow-sm bg-white">
                         <img src={docPreview} alt="DNI" className="w-full h-full object-cover" />
                         {isScanning && (
                           <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                              <Loader2 className="w-6 h-6 text-white animate-spin" />
                           </div>
                         )}
                         <button 
                            onClick={removeDoc}
                            className="absolute top-1 right-1 bg-white/90 text-red-500 rounded-full p-0.5 shadow-sm hover:bg-red-50"
                         >
                            <X className="w-3 h-3" />
                         </button>
                      </div>
                   ) : (
                      <label className="flex flex-col items-center justify-center w-32 h-20 rounded-xl border-2 border-dashed border-indigo-300 bg-white/50 hover:bg-white hover:border-indigo-400 cursor-pointer transition-all group/btn">
                         <Upload className="w-6 h-6 text-indigo-400 group-hover/btn:text-indigo-600 mb-1" />
                         <span className="text-[10px] font-semibold text-indigo-400 group-hover/btn:text-indigo-600">SUBIR FOTO</span>
                         <input 
                            type="file" 
                            accept="image/*"
                            capture="environment"
                            onChange={handleDocumentChange}
                            className="hidden"
                         />
                      </label>
                   )}
                </div>

                <div className="flex-1">
                   {isScanning ? (
                      <div className="text-indigo-600 text-sm font-medium animate-pulse flex items-center gap-2">
                         <ScanLine className="w-4 h-4 animate-spin-slow" />
                         Analizando documento...
                      </div>
                   ) : ocrSuccess ? (
                      <div className="text-green-600 text-sm font-medium flex items-center gap-2 bg-green-50 px-3 py-2 rounded-lg border border-green-100">
                         <CheckCircle2 className="w-4 h-4" />
                         Datos completados
                      </div>
                   ) : (
                      <div className="text-xs text-indigo-400">
                         Los datos se completarán automáticamente al subir la foto.
                      </div>
                   )}
                </div>
             </div>
          </div>

          {/* Profile Photo Widget */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
             <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
               <ImageIcon className="w-5 h-5 text-blue-500" />
               Foto de Perfil (Rostro)
             </h3>
             <div className="flex items-center gap-6">
                <div className="relative group">
                  <div className={`
                    w-24 h-24 rounded-full border-2 border-dashed border-slate-300 flex items-center justify-center overflow-hidden bg-slate-50
                    ${!photoPreview ? 'hover:border-blue-400 hover:bg-blue-50' : 'border-none'} transition-all
                  `}>
                    {photoPreview ? (
                      <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <Upload className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <label className="absolute bottom-0 right-0 bg-blue-600 text-white rounded-full p-2 shadow-lg cursor-pointer hover:bg-blue-700 hover:scale-105 transition-all">
                    <Upload className="w-3 h-3" />
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={handlePhotoChange}
                      className="hidden"
                    />
                  </label>
                  {photoPreview && (
                    <button 
                      onClick={removePhoto}
                      className="absolute top-0 right-0 bg-red-100 text-red-600 rounded-full p-1 shadow-sm hover:bg-red-200 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
                
                <div className="flex-1 text-sm text-slate-500">
                  <p>Cargá una foto clara del rostro del paciente para su ficha clínica.</p>
                </div>
             </div>
          </div>

        </div>

        {/* Form Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <div className="space-y-6">
            <IdentificationSection formData={formData} updateFormData={updateFormData} />
            <DemographicsSection formData={formData} updateFormData={updateFormData} />
          </div>
          <div className="space-y-6">
            <ClinicalHistorySection formData={formData} updateFormData={updateFormData} />
            <MeasurementsSection formData={formData} updateFormData={updateFormData} />
          </div>
        </div>

        {/* Action Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="sticky bottom-6 z-10 flex justify-end gap-4 p-4 bg-white/80 backdrop-blur-md rounded-2xl shadow-lg border border-white/50 mx-4 md:mx-0"
        >
           <div className="flex-1 flex items-center text-sm text-slate-500 px-2">
             <Sparkles className="w-4 h-4 mr-2 text-indigo-500" />
             <span>Los datos se guardan de forma segura en la nube.</span>
           </div>
          <Button
            onClick={handleSave}
            disabled={isSubmitting}
            className="rounded-xl px-8 py-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg shadow-blue-500/25 transition-all duration-300 hover:shadow-blue-500/40 hover:scale-[1.02] active:scale-[0.98]"
          >
            {isSubmitting ? (
              <>Guardando...</>
            ) : (
              <>
                <Save className="w-5 h-5 mr-2" />
                Registrar Paciente
              </>
            )}
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default PatientDataModule;
