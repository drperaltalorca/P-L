
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { 
  LayoutDashboard, Users, CalendarDays, Search, BarChart3, 
  FileText, Bell, Home, Loader2, BookOpen, Clock, 
  ClipboardList, Pill, Database, HelpCircle, Radar 
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

// Components
import PatientDataModule from '@/components/PatientDataModule';
import PatientsList from '@/components/PatientsList';
import PatientDetailView from '@/components/PatientDetailView';
import AppointmentsManager from '@/components/AppointmentsManager';
import PublicBookingForm from '@/components/PublicBookingForm';
import PublicBlog from '@/components/PublicBlog'; 
import AdvancedSearch from '@/components/AdvancedSearch';
import ReportsAnalytics from '@/components/ReportsAnalytics';
import MedicalReportsGenerator from '@/components/MedicalReportsGenerator';
import AppointmentReminders from '@/components/AppointmentReminders';
import MainDashboard from '@/components/MainDashboard';
import LoginPage from '@/components/LoginPage';
import UserProfile from '@/components/UserProfile';
import BlogManager from '@/components/BlogManager';
import MedicalCopilot from '@/components/MedicalCopilot';
import SurgeryProtocols from '@/components/SurgeryProtocols';
import GlobalPrescriptionsView from '@/components/GlobalPrescriptionsView';
import MedicationImporter from '@/components/MedicationImporter';
import SupportSection from '@/components/SupportSection';
import WeatherRadarFooter from '@/components/WeatherRadarFooter'; // NEW IMPORT
import { Toaster } from '@/components/ui/toaster';

// Auth
import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext';

const LOGO_URL = "https://horizons-cdn.hostinger.com/a2da2fd7-d789-4d10-b670-30a519160b2b/6d05420aa8885edfe961d61427d0e3be.jpg";

// Protected Route Wrapper
const ProtectedRoute = ({ children }) => {
  const { session, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center space-y-4">
          <Loader2 className="w-10 h-10 animate-spin text-blue-600 mx-auto" />
          <p className="text-slate-500 font-medium">Verificando sesión...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <LoginPage />;
  }

  return (
    <>
      <UserProfile />
      {children}
    </>
  );
};

const ArgentinaClock = () => {
  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const timeOptions = { 
    timeZone: 'America/Argentina/Buenos_Aires',
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit',
    hour12: false
  };

  const dateOptionsFull = {
    timeZone: 'America/Argentina/Buenos_Aires',
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };

  const dateOptionsShort = {
    timeZone: 'America/Argentina/Buenos_Aires',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  };

  const timeString = new Intl.DateTimeFormat('es-AR', timeOptions).format(dateTime);
  
  const fullDateString = new Intl.DateTimeFormat('es-AR', dateOptionsFull).format(dateTime);
  const capitalizedDateString = fullDateString.charAt(0).toUpperCase() + fullDateString.slice(1);
  
  const shortDateString = new Intl.DateTimeFormat('es-AR', dateOptionsShort).format(dateTime);

  return (
    <div className="fixed top-24 right-4 z-40 bg-white/90 backdrop-blur shadow-sm border border-slate-200 px-4 py-2 rounded-lg flex items-center gap-3 text-sm font-medium text-slate-700 hidden lg:flex">
      <div className="flex items-center gap-2 border-r border-slate-200 pr-3">
        <Clock className="w-4 h-4 text-blue-600" />
        <span className="font-mono text-lg font-bold text-slate-900">{timeString}</span>
      </div>
      <div className="text-xs text-slate-500">
        <span className="block text-slate-800 font-semibold whitespace-nowrap">{capitalizedDateString}</span>
        <span className="block font-mono">({shortDateString})</span>
      </div>
    </div>
  );
};

const MobileClock = () => {
  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const timeOptions = { 
    timeZone: 'America/Argentina/Buenos_Aires',
    hour: '2-digit', 
    minute: '2-digit',
    hour12: false
  };

  const dateOptionsShort = {
    timeZone: 'America/Argentina/Buenos_Aires',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  };

  const timeString = new Intl.DateTimeFormat('es-AR', timeOptions).format(dateTime);
  const shortDateString = new Intl.DateTimeFormat('es-AR', dateOptionsShort).format(dateTime);

  return (
    <div className="lg:hidden flex items-center justify-center gap-2 text-xs text-slate-500 py-2 bg-white/50 mb-2 rounded-lg border border-slate-100">
      <Clock className="w-3 h-3" />
      <span className="font-mono font-bold text-slate-700">{timeString}</span>
      <span>•</span>
      <span>{shortDateString}</span>
    </div>
  );
};

function AppContent() {
  const [activeTab, setActiveTab] = useState('home'); 
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [isFetchingPatient, setIsFetchingPatient] = useState(false);
  
  const [publicRouteType, setPublicRouteType] = useState(() => {
    const path = window.location.pathname;
    if (path === '/book-appointment') return 'booking';
    if (path.startsWith('/blog')) return 'blog';
    return null;
  });

  useEffect(() => {
    const handleLocationCheck = () => {
      const path = window.location.pathname;
      if (path === '/book-appointment') setPublicRouteType('booking');
      else if (path.startsWith('/blog')) setPublicRouteType('blog');
    };
    
    window.addEventListener('popstate', handleLocationCheck);
    return () => window.removeEventListener('popstate', handleLocationCheck);
  }, []);

  // Listener for navigation from Dashboard
  useEffect(() => {
    const handleNavigation = (e) => {
      const tab = e.detail;
      if (tab) setActiveTab(tab);
    };
    window.addEventListener('navigate-to-tab', handleNavigation);
    return () => window.removeEventListener('navigate-to-tab', handleNavigation);
  }, []);

  // Global listener for opening patient profiles via ID
  useEffect(() => {
    const handlePatientProfileRequest = async (e) => {
      const { patientId } = e.detail;
      if (!patientId) return;

      setIsFetchingPatient(true);
      try {
        const { data, error } = await supabase
          .from('patients')
          .select('*')
          .eq('id', patientId)
          .single();

        if (error) throw error;
        if (data) {
          setSelectedPatient(data);
          window.scrollTo(0, 0);
        }
      } catch (err) {
        console.error("Error fetching patient for profile:", err);
      } finally {
        setIsFetchingPatient(false);
      }
    };

    window.addEventListener('open-patient-profile', handlePatientProfileRequest);
    return () => window.removeEventListener('open-patient-profile', handlePatientProfileRequest);
  }, []);

  if (publicRouteType === 'booking') {
    return (
      <>
        <PublicBookingForm />
        <Toaster />
      </>
    );
  }

  if (publicRouteType === 'blog') {
    return (
      <>
        <PublicBlog />
        <Toaster />
      </>
    );
  }

  const handleSelectPatient = (patient) => {
    setSelectedPatient(patient);
    window.scrollTo(0, 0);
  };

  const handleBackToList = () => {
    setSelectedPatient(null);
  };

  const handleGoHome = () => {
    setActiveTab('home');
    setSelectedPatient(null);
  };

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-blue-50 py-8 px-4 font-sans relative pb-16">
        <button 
          onClick={handleGoHome} 
          className="fixed top-4 left-4 z-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-xl"
          aria-label="Volver al inicio"
        >
          <div className="bg-black p-2 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 group">
            <img 
              src={LOGO_URL} 
              alt="P+L Logo" 
              className="h-16 w-auto object-contain rounded-lg group-hover:scale-105 transition-transform duration-300" 
            />
          </div>
        </button>

        <ArgentinaClock />
        
        {/* Radar de Contingencias Link */}
        <div className="fixed top-36 right-4 z-40 hidden lg:block">
          <a 
            href="https://www.mendoza.gov.ar/contingencias/radar/radar-sur/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-gradient-to-r from-red-500 to-orange-500 text-white text-sm font-semibold px-4 py-2 rounded-lg shadow-lg hover:from-red-600 hover:to-orange-600 transition-all duration-300 transform hover:scale-105"
          >
            <Radar className="w-5 h-5" />
            <span>Radar Contingencias</span>
          </a>
        </div>

        <div className="max-w-7xl mx-auto pt-20"> 
          <MobileClock />

          {!selectedPatient && !isFetchingPatient && (
            <div className="flex flex-col items-center justify-center mb-8 gap-4">
              
              <div className="bg-white/50 backdrop-blur-sm p-1.5 rounded-2xl border border-white/50 shadow-sm inline-flex flex-wrap justify-center gap-2 md:gap-3">
                <NavButton 
                  active={activeTab === 'home'} 
                  onClick={() => setActiveTab('home')} 
                  icon={<Home className="w-5 h-5" />} 
                  label="Inicio" 
                  color="rose"
                />
                <NavButton 
                  active={activeTab === 'register'} 
                  onClick={() => setActiveTab('register')} 
                  icon={<LayoutDashboard className="w-5 h-5" />} 
                  label="Registro" 
                  color="blue"
                />
                <NavButton 
                  active={activeTab === 'list'} 
                  onClick={() => setActiveTab('list')} 
                  icon={<Users className="w-5 h-5" />} 
                  label="Pacientes" 
                  color="purple"
                />
                <NavButton 
                  active={activeTab === 'search'} 
                  onClick={() => setActiveTab('search')} 
                  icon={<Search className="w-5 h-5" />} 
                  label="Buscar" 
                  color="indigo"
                />
                <NavButton 
                  active={activeTab === 'appointments'} 
                  onClick={() => setActiveTab('appointments')} 
                  icon={<CalendarDays className="w-5 h-5" />} 
                  label="Turnos" 
                  color="violet"
                />
                <NavButton 
                  active={activeTab === 'prescriptions_global'} 
                  onClick={() => setActiveTab('prescriptions_global')} 
                  icon={<Pill className="w-5 h-5" />} 
                  label="Recetas" 
                  color="emerald"
                />
                <NavButton 
                  active={activeTab === 'import_meds'} 
                  onClick={() => setActiveTab('import_meds')} 
                  icon={<Database className="w-5 h-5" />} 
                  label="Importar" 
                  color="green"
                />
                <NavButton 
                  active={activeTab === 'reminders'} 
                  onClick={() => setActiveTab('reminders')} 
                  icon={<Bell className="w-5 h-5" />} 
                  label="Avisos" 
                  color="orange"
                />
                <NavButton 
                  active={activeTab === 'protocols'} 
                  onClick={() => setActiveTab('protocols')} 
                  icon={<ClipboardList className="w-5 h-5" />} 
                  label="Protocolos" 
                  color="red"
                />
                <NavButton 
                  active={activeTab === 'reports'} 
                  onClick={() => setActiveTab('reports')} 
                  icon={<BarChart3 className="w-5 h-5" />} 
                  label="Stats" 
                  color="amber"
                />
                <NavButton 
                  active={activeTab === 'docs'} 
                  onClick={() => setActiveTab('docs')} 
                  icon={<FileText className="w-5 h-5" />} 
                  label="Docs" 
                  color="cyan"
                />
                <NavButton 
                  active={activeTab === 'blog'} 
                  onClick={() => setActiveTab('blog')} 
                  icon={<BookOpen className="w-5 h-5" />} 
                  label="Blog" 
                  color="teal"
                />
                <NavButton 
                  active={activeTab === 'support'} 
                  onClick={() => setActiveTab('support')} 
                  icon={<HelpCircle className="w-5 h-5" />} 
                  label="Soporte" 
                  color="slate"
                />
              </div>
            </div>
          )}

          {isFetchingPatient ? (
             <div className="flex flex-col items-center justify-center h-[50vh] space-y-4">
               <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
               <p className="text-slate-500 font-medium">Cargando perfil del paciente...</p>
             </div>
          ) : (
            <div className="transition-all duration-500 ease-in-out">
              {selectedPatient ? (
                <PatientDetailView 
                  patient={selectedPatient} 
                  onBack={handleBackToList} 
                />
              ) : activeTab === 'home' ? (
                <MainDashboard />
              ) : activeTab === 'register' ? (
                <PatientDataModule />
              ) : activeTab === 'list' ? (
                <PatientsList onSelectPatient={handleSelectPatient} />
              ) : activeTab === 'search' ? (
                <AdvancedSearch onSelectPatient={handleSelectPatient} />
              ) : activeTab === 'prescriptions_global' ? (
                <GlobalPrescriptionsView />
              ) : activeTab === 'import_meds' ? (
                <MedicationImporter />
              ) : activeTab === 'protocols' ? (
                <SurgeryProtocols />
              ) : activeTab === 'appointments' ? (
                <AppointmentsManager />
              ) : activeTab === 'reminders' ? (
                <AppointmentReminders />
              ) : activeTab === 'reports' ? (
                <ReportsAnalytics />
              ) : activeTab === 'docs' ? (
                <MedicalReportsGenerator />
              ) : activeTab === 'support' ? (
                <SupportSection />
              ) : (
                <BlogManager />
              )}
            </div>
          )}
        </div>
        
        <MedicalCopilot />
        <WeatherRadarFooter /> {/* Added the weather radar footer */}
        
        <Toaster />
      </div>
    </ProtectedRoute>
  );
}

function App() {
  return (
    <AuthProvider>
      <Helmet>
        <title>Portal Médico - Gestión Integral de Pacientes</title>
        <meta name="description" content="Sistema moderno de gestión de datos de pacientes para registros médicos, demografía e historial clínico." />
      </Helmet>
      <AppContent />
    </AuthProvider>
  );
}

const NavButton = ({ active, onClick, icon, label, color }) => {
  const activeClasses = {
    rose: 'text-rose-600 shadow-md shadow-rose-500/10 bg-white',
    blue: 'text-blue-600 shadow-md shadow-blue-500/10 bg-white',
    purple: 'text-purple-600 shadow-md shadow-purple-500/10 bg-white',
    indigo: 'text-indigo-600 shadow-md shadow-indigo-500/10 bg-white',
    emerald: 'text-emerald-600 shadow-md shadow-emerald-500/10 bg-white',
    violet: 'text-violet-600 shadow-md shadow-violet-500/10 bg-white',
    amber: 'text-amber-600 shadow-md shadow-amber-500/10 bg-white',
    cyan: 'text-cyan-600 shadow-md shadow-cyan-500/10 bg-white',
    orange: 'text-orange-600 shadow-md shadow-orange-500/10 bg-white',
    teal: 'text-teal-600 shadow-md shadow-teal-500/10 bg-white',
    red: 'text-red-600 shadow-md shadow-red-500/10 bg-white',
    green: 'text-green-600 shadow-md shadow-green-500/10 bg-white',
    slate: 'text-slate-600 shadow-md shadow-slate-500/10 bg-white',
  };

  return (
    <button
      onClick={onClick}
      className={`
        flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-xl transition-all duration-300 min-w-[70px] md:min-w-[80px]
        ${active 
          ? `${activeClasses[color]} scale-105` 
          : 'text-slate-500 hover:text-slate-700 hover:bg-white/50'}
      `}
    >
      {icon}
      <span className="text-[10px] md:text-xs font-semibold leading-tight text-center">{label}</span>
    </button>
  );
};

export default App;
